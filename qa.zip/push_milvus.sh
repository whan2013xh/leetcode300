# 构建镜像
docker build . -f docker/qa_service -t qa_service:v1.1

# 登陆到公司镜像仓库
docker login registry.shdocker.tuya-inc.top

# 将本地镜像打上tag
docker tag qa_service:v1.1 registry.shdocker.tuya-inc.top/ai-platform-public/qa_service:v1.1

# 将本地镜像tag推到公司仓库
docker push registry.shdocker.tuya-inc.top/ai-platform-public/qa_service:v1.1
