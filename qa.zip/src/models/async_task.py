# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-12-21
    FileName   : async_task.py
    Author     : Mustom
    Descreption: 
"""
import peewee
from enum import Enum


from src.models.base_model import BaseModel


class TaskStatus(Enum):
    PENDING = "PENDING"     # 任务正在等待执行或未知，任何未知的任务 ID 都默认处于挂起状态
    STARTED = "STARTED"     # 任务已经开始
    SUCCESS = "SUCCESS"     # 任务执行成功
    FAILURE = "FAILURE"     # 任务执行失败
    RETRY = "RETRY"         # 任务处于重试状态
    REVOKED = "REVOKED"     # 任务被撤销


class AsyncTask(BaseModel):
    gmt_create = peewee.BigIntegerField(null=True, verbose_name="创建时间")
    gmt_modified = peewee.BigIntegerField(null=True, verbose_name="修改时间")
    name = peewee.CharField(unique=True)
    async_id = peewee.CharField(null=False)
    params = peewee.CharField(null=False)
    status = peewee.CharField(default=TaskStatus.PENDING.value, null=False)
    error_message = peewee.CharField(default="", null=False)

    class Meta:
        table_name = "rb_async_task"
