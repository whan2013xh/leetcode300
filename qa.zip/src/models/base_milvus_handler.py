# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-26
    FileName   : base_milvus_handler.py
    Author     : Honghe
    Descreption: 
"""
import math
import numpy as np
from milvus import Milvus, IndexType, MetricType

from src.common.config import config
from src.common.logger import logger

class MilvusHandler:
    def __init__(self, milvus_client, collection_tables):
        self.milvus_client = milvus_client

        for collection_table in collection_tables:
            collection_params = config.get("MILVUS").get(collection_table)
            self.collection_names = collection_params.get("MILVUS_COLLECTION_NAME")
            index_param = collection_params.get("index_param")

            for collection_name in self.collection_names:
                _, ok = self.milvus_client.has_collection(collection_name, timeout=90)
                if not ok:
                    param = {
                        'collection_name': collection_name,
                        'dimension': collection_params['MILVUS_DIMENSION'],
                        'index_file_size': collection_params['MILVUS_INDEX_FILE_SIZE'],
                        'metric_type': MetricType.IP  # inner product
                    }
                    logger.info(f"milvus start create collection {param}")
                    self.milvus_client.create_collection(param, timeout=90)
                    if index_param is None:
                        index_param = {
                            'nlist': 2048
                        }
                    #
                    self.milvus_client.create_index(collection_name, IndexType.IVF_FLAT, index_param)
                    self.milvus_client.flush([collection_name])
            # _, collection_info = self.milvus_client.get_collection_info(collection_name)
            # logger.info("Collection name: %s, dimension: %s, index_file_size: %s, metric_type: %s" % (
            #     collection_info.collection_name,
            #     collection_info.dimension,
            #     collection_info.index_file_size,
            #     collection_info.metric_type
            # ))
            # status, index_info = self.milvus_client.get_index_info(collection_name)
            # logger.info("Index type: %s, params: %s" % (index_info.index_type, index_info.params))

    @staticmethod
    def norm_vectors(reps):
        """
        向量的normalize
        :param reps: torch.tensor
        :return:
        """
        norm_vectors = []
        for rep in reps.cpu().detach().numpy():
            norm_rep = rep / np.linalg.norm(rep, ord=2)
            norm_vectors.append(norm_rep.tolist())

        return norm_vectors

    @staticmethod
    def check_partition(milvus_client, collection_name, partiton_tag=None):
        """
        检查分区是否存在
        :param collection_name:
        :param partiton_tag:
        :return:
        """

        # logger.info(milvus_client.connect())
        # logger.info(milvus_client.connected())
        # logger.info(f"milvus check partition {collection_name}, {partiton_tag},{milvus_client}")
        # logger.info(f"init milvus {milvus_client.list_partitions('mrc_sentence_rank_test')}")
        # print(f"==before milvus {milvus_client.list_partitions('mrc_sentence_rank_test')}")
        status, ok = milvus_client.has_partition(collection_name, partiton_tag, timeout=30)
        logger.info(f"Milvus partition check result {status} is ok:{ok}")
        # print(f"==after milvus {milvus_client.get_collection_info('mrc_sentence_rank_test')}")


        if not status.OK():
            logger.info("Milvus has_partition wrong, message: %s" % status.message)
            return False
        if not ok:
            milvus_client.create_partition(collection_name, partition_tag=partiton_tag, timeout=30)
        return True

    @staticmethod
    def update_vectors(milvus_client, bot_id, collection_name,  ids, vectors,size=10000,retry_times=3):
        """
        更新向量数据，先删除同ID的记录，再插入
        :param collection_name:
        :param bot_id:
        :param ids:
        :param vectors:
        :return:
        """
        # milvus_config = config.get("MILVUS")
        # milvus_client = Milvus(milvus_config['MILVUS_URL'], milvus_config['MILVUS_PORT'])
        bot_id = str(bot_id)
        # bot_id = "237"
        for i in range(retry_times):
            try:
                check_res = MilvusHandler.check_partition(milvus_client, collection_name, bot_id)
                if not check_res:
                    return False
                # 先删除要插入的ids，以防重复
                status = milvus_client.delete_entity_by_id(collection_name, ids, partition_tag=bot_id)
                if not status.OK():
                    logger.info(f"Milvus delete_entity_by_id wrong:,retry {i}, message: status.message" )
                    return False
                enumerate

                # 向索引中插入数据
                status, vec_ids = milvus_client.insert(collection_name, vectors, ids, partition_tag=bot_id)
                if not status.OK():
                    logger.info(f"Milvus insert wrong,retry {i} message: {status.message}" )
                    if i == retry_times - 1:
                        return False
                    else:
                        continue
                logger.info("Add vectors to collection: %s, partition: %s, count: %s, total:%s res:%s" % (collection_name, bot_id, len(vec_ids),len(vec_ids),status.OK()))
                # for i in range(len(ids)):
                # status, vec_ids = milvus_client.insert(collection_name, vectors, ids, partition_tag=bot_id)
                # if not status.OK():
                #     logger.info("Milvus insert wrong, message: %s" % status.message)
                #     return False
                # logger.info("Add vectors to collection: %s, partition: %s, count: %s, ids:%s" % (collection_name, bot_id, len(vec_ids),len(ids)))
                # inserted data to disk
                # res = milvus_client.flush([collection_name])
                # logger.info(f"{collection_name} milvus flush res {res}")
                break
                # milvus_client.close()
            except Exception as e:
                logger.info(f"Milvus insert wrong, message: {e} params {collection_name},bot_id:{bot_id}" )
                if i==retry_times-1:
                    return False
        # milvus_client.compact(collection_name)
        return True

    @staticmethod
    def delete_vectors(milvus_client, bot_id, ids, collection_names=None):
        """
        删除向量数据，支持删除单个环境的数据
        :param bot_id:
        :param ids:
        :param collection_names:
        :return:
        """
        bot_id = str(bot_id)
        collection_names = collection_names
        # milvus_config = config.get("MILVUS")
        # milvus_client = Milvus(milvus_config['MILVUS_URL'], milvus_config['MILVUS_PORT'])
        for collection_name in collection_names:
            status = milvus_client.delete_entity_by_id(collection_name, ids, partition_tag=bot_id)
            milvus_client.flush([collection_name])
            if not status.OK():
                logger.info("Milvus delete_entity_by_id wrong:, message: %s" % status.message)
                return False
            logger.info("Milvus delete_entity_by_id collection_name: %s, partition: %s, count: %s" % (
                collection_name, bot_id, len(ids)))
        # milvus_client.close()
            milvus_client.compact(collection_name)
        return True


