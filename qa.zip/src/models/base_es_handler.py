# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-08-05
    FileName   : base_es_handler.py
    Author     : Honghe
    Descreption: 
"""
from enum import Enum

from elasticsearch import Elasticsearch
from elasticsearch_dsl import analyzer, tokenizer

punctuation = tokenizer("punctuation", type="pattern", pattern="[ .,!?]")

english_analyzer = analyzer('english_analyzer',
    tokenizer=punctuation,
    filter=["lowercase", "stop", "stemmer"]
)

class Langeuage(Enum):
    CHINESE = "zh"
    ENGLISH = "en"
