# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-08-03
    FileName   : zh_faq_es_model.py
    Author     : Honghe
    Descreption: 
"""
from elasticsearch_dsl import Document, Date, Integer, Keyword, Text, Boolean, Object, MetaField

from src.common import config
# from src.models import init_es


class ZhFaqDoc(Document):
    is_pre = Integer()
    query = Text(analyzer="ik_max_word", search_analyzer="ik_smart")
    query_id = Keyword()
    norm_text = Text(analyzer="ik_max_word", search_analyzer="ik_smart")
    keywords = Text(analyzer="whitespace")
    keywords_weight = Object(enabled=False)
    answer = Text(analyzer="ik_max_word", search_analyzer="ik_smart")
    is_standard = Boolean()
    catalogs = Text(analyzer="whitespace")
    labels = Text(analyzer="whitespace")
    knowledge_code = Keyword()
    bot_id = Keyword()
    language = Keyword()
    update_time = Date()
    source = Integer()
    base_code = Keyword()
    answer_id = Keyword()
    uuid = Keyword()

    # class Meta:
    #     dynamic = MetaField('strict')

    class Index:
        name = 'zh_faq'
        doc_type = 'zh_faq_doc'