# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-26
    FileName   : mysql_handler.py
    Author     : Honghe
    Descreption: 
"""
import time
from enum import Enum

import peewee
from peewee import BooleanField, BigIntegerField, IntegerField,CharField

from src.models import db
from src.common import logger
from src.models.base_model import BaseModel


class SyncType(Enum):
    """
    同步状态
    """
    DELETE = 0
    SYNC = 1
    PUBLISH = 2
    SYNCING = 3
    PUBLISHING = 4
    SYNC_FAILED = 5
    PUBLISH_FAILED = 6
    OFFSHELF = -1
    OFFSHELFING = -2
    OFFSHELF_FAILED = -3


class MrcSentences(BaseModel):
    """
    处理meta数据，主要是调用知识库相关接口
    """
    gmt_create = BigIntegerField(null=True, verbose_name="创建时间")
    gmt_modified = BigIntegerField(null=True, verbose_name="修改时间")
    is_publish = BooleanField(default=False)
    status = IntegerField(default=0)
    sync_time = BigIntegerField(null=True)
    channel_id = CharField(default="")
    is_deleted = BooleanField(default=False)
    uuid = CharField(default="")
    base_code = CharField(default="")
    content_id = CharField(default="")
    sentence = CharField(default="")
    language = CharField(default="zh")
    document_id = CharField(default="")

    class Meta:
        table_name = "rb_mrc_sentences"

    @classmethod
    def create_instances(cls, data: list, sync_time):
        length = len(data)
        logger.info(f"start create instances count {len(data)}")
        if length == 0:
            return {"insert_num": len(data)}
        count = 0
        with db.atomic() as transaction:
            try:
                for batch in peewee.chunked(data, 1000):
                    cls.add_time(batch)
                    tmp_length = cls.insert_many(batch).on_conflict(
             update={cls.sync_time:sync_time,cls.is_deleted:0}).execute()
                    count += tmp_length
                    # cls.replace_many(batch).execute()
            except Exception as e:
                transaction.rollback()
                logger.error(f"data create failed {e} args:{e.args[1]}")
                for i in range(length):
                    if data[i].get("uuid") in e.args[1]:
                        logger.info(f"error record {data[i]}")
                return {}

        return {"insert_num": count}

    @classmethod
    def add_time(self, batch: list, value=None):
        value = value if value is not None else int(time.time() * 1000)
        for x in batch:
            x["gmt_create"] = value
            x["gmt_modified"] = value
            # 生成唯一标识
            # x["uuid"] = hash_milvus_id(f"{x.get('sentence')}_{x.get('channel_id')}_{x.get('status')}")
