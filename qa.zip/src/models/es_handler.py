# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-23
    FileName   : ES_handler.py
    Author     : Honghe
    Descreption: 
"""
from elasticsearch import Elasticsearch
from elasticsearch_dsl import analyzer, tokenizer

punctuation = tokenizer("punctuation", type="pattern", pattern="[ .,!?]")
english_analyzer = analyzer('english_analyzer',
    tokenizer="punctuation",
    filter=["lowercase", "stop", "stemmer"]
)

class ESHandler(object):
    def __init__(self, hosts, maxsize=25):
        self.es = Elasticsearch(hosts, maxsize=maxsize)

    def add(self, index, doc_id, doc, doc_type="_doc"):
        '''
        Adds or updates a typed JSON document in a specific index, making it searchable.
        @param doc_id: Document ID;
        @param doc: JSON document;
        '''
        res = self.es.index(index=index, doc_type=doc_type, id=doc_id, body=doc)

        return res

    def delete(self, index, doc_id):
        '''
        Delete a typed JSON document from a specific index based on its id.
        @param doc_id: The document ID
        '''
        res = self.es.delete(index=index, id=doc_id)

        return res

    def delete_by_query(self, index, body, **kwargs):
        """
        Deletes documents matching the provided query.
        :param body:
        :return:
        """
        res = self.es.delete_by_query(index=index, body=body, **kwargs)

        return res

    def get(self, index, doc_id, doc_type="_doc"):
        '''
        Get a typed JSON document from the index based on its id.
        @param doc_id: The document ID
        '''
        res = self.es.get(index=index, doc_type=doc_type, id=doc_id)

        return res

    def mget(self, index, body):
        '''
        Get multiple documents based on an index, type (optional) and ids.
        @param body: Document identifiers; can be either docs (containing full document information)
                    or ids (when index and type is provided in the URL.

        '''
        return self.es.mget(index=index, body=body)

    def search(self, index, body, **kwargs):
        '''
        Execute a search query and get back search hits that match the query.
        @param body: The search definition using the Query DSL
        '''
        res = self.es.search(index=index, body=body, **kwargs)

        return res

    def msearch(self, index, body):
        '''
        Execute several search requests within the same API.
        @param body:The request definitions (metadata-search request definition pairs),
                    separated by newlines
        '''
        res = self.es.msearch(index=index, body=body)

        return res

    def update(self, index, doc_id, body):
        """
        Updates a document with a script or partial document.
        https://elasticsearch-py.readthedocs.io/en/7.9.1/api.html
        :param body:
        :return:
        """
        res = self.es.update(index=index, id=doc_id, body=body)

        return res

    def info(self):
        '''
        Get the basic info from the current cluster.
        '''
        return self.es.info()
