# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-08-03
    FileName   : mrc_es_model.py
    Author     : Honghe
    Descreption: 
"""
from elasticsearch_dsl import Document, Date, Integer, Keyword, Text, Boolean, Object, Long

from src.common import config
# from src.models import init_es


class MrcDoc(Document):
    is_pre = Integer()
    subtitles = Text(analyzer="whitespace")
    keywords = Text(analyzer="whitespace")
    sentences = Keyword()
    base_code = Keyword()
    language = Keyword()
    source = Integer()
    document_id = Keyword()
    title = Text(analyzer="whitespace")
    content = Text(analyzer="whitespace")
    ori_title = Keyword()
    ori_subtitles = Keyword()
    update_time = Date()
    is_deleted = Boolean()
    keywords_weight = Object(enabled=False)
    catalogs = Text(analyzer="whitespace")
    is_hot = Boolean()
    ori_content = Text(analyzer="ik_max_word", search_analyzer="ik_smart")
    doc_labels = Keyword()
    doc_keywords = Keyword()
    ori_catalogs = Keyword()
    bot_id = Keyword()
    content_length = Integer()
    uuid = Keyword()

    class Index:
        name = 'zh_mrc'


# class test_mrc(Document):
#     is_pre = Integer()
#     subtitles = Text(analyzer="whitespace")
#     keywords = Text(analyzer="whitespace")
#     sentences = Keyword()
#
#     class Index:
#         name = 'mrc_docs'


if __name__ == '__main__':
    es_client = init_es(config)
    # res = es_client.get(index='mrc_docs', doc_type="_doc", id="fSiu2HgBJBDkrsVXZKby")
    MrcDoc.init()
    # test = MrcDoc.get(id="9EWdEHsBJBDkrsVXfZLc")
    test = MrcDoc()
    test.is_pre=0
    test.subtitles = "test 1 2 3"
    test.keywords = "1 2 3"
    test.sentences = " test 1 2 3 4"
    res = test.save()
    from elasticsearch_dsl import Search,Q
    # es_client.delete_by_query()
    # s= Search(using=es_client, index=MrcDoc.Index().name)
    # s.query("match", is_pre=1)
    # response = s.execute()
    params = {"is_pre": 1,"_source": "sentences"}
    # 多字段查询
    # match是单字段查询，fields可以设置要查的多个字段，query是设置查询的值，可以设置查询的多个值，但是必须是一样的
    q = Q("multi_match", query=1, fields=["is_pre"])
    response = Search(using=es_client, index=MrcDoc.Index().name).source("sentences").query(q).execute()
    print(response.to_dict())
    # for hit in response:
    #     print(hit.sentences)
    print("")




