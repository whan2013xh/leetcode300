# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-26
    FileName   : mrc_milvus_handler.py
    Author     : Honghe
    Descreption: 
"""
import enum
from src.common.config import config
from src.models.base_milvus_handler import MilvusHandler


class MrcMilvusHandler(MilvusHandler):
    def __init__(self, language="zh"):
        self.language = language
        self.milvus_type = "MRC"
        self.collection_params = config.get("MILVUS").get(self.milvus_type)
        super().__init__(self.collection_params)
