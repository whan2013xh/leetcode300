# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-08-03
    FileName   : en_faq_es_model.py
    Author     : Honghe
    Descreption: 
"""
from elasticsearch_dsl import Document, Date, Integer, Keyword, Text, Boolean, Object, MetaField

from src.common import config
# from src.models import init_es
from src.models.base_es_handler import english_analyzer


class EnFaqDoc(Document):
    is_pre = Integer()
    query = Text(analyzer=english_analyzer, search_analyzer=english_analyzer)
    query_id = Keyword()
    norm_text = Text(analyzer=english_analyzer, search_analyzer=english_analyzer)
    keywords = Text(analyzer="whitespace")
    keywords_weight = Object(enabled=False)
    answer = Text(analyzer=english_analyzer, search_analyzer=english_analyzer)
    is_standard = Boolean()
    catalogs = Text(analyzer="whitespace")
    labels = Text(analyzer="whitespace")
    knowledge_code = Keyword()
    bot_id = Keyword()
    language = Keyword()
    update_time = Date()
    source = Integer()
    base_code = Keyword()
    answer_id = Keyword()
    uuid = Keyword()

    # class Meta:
    #     dynamic = MetaField('strict')

    class Index:
        name = 'en_faq'
        doc_type = 'en_faq_doc'


if __name__ == '__main__':
    es_client = init_es(config)
    # res = es_client.get(index='mrc_docs', doc_type="_doc", id="fSiu2HgBJBDkrsVXZKby")
    EnFaqDoc.init()
    # test = MrcDoc.get(id="9EWdEHsBJBDkrsVXfZLc")
    # test = test_mrc()
    # test.is_pre=1
    # test.subtitles = "test 1 2 3"
    # test.keywords = "1 2 3"
    # test.sentences = " test 1 2 3 4"
    # res = test.save()

    print("")