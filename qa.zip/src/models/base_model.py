# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-08-31
    FileName   : base_model.py
    Author     : Honghe
    Descreption: 
"""
import time

import peewee
from peewee import Model
from src.models import db

class BaseModel(Model):
    class Meta:
        database = db

    @classmethod
    def create_instance(cls, data: dict):
        cur_time = int(time.time() * 1000)
        data["gmt_create"] = cur_time
        data["gmt_modified"] = cur_time
        # data["uuid"] = hash_milvus_id(f"{data.get('data')}_{data.get('data_set')}")
        instance, _ = cls.get_or_create(**data)
        return instance

    def update_instance(self, data: dict):
        for key in data.keys():
            if key != "id":
                self.__data__[key] = data[key]
        self.gmt_modified = int(time.time() * 1000)
        self.save()
        return self

    @classmethod
    def generate_expressions(cls, raw_expressions: dict):
        if len(raw_expressions) == 0:
            expressions = [None]
        else:
            validated_expressions = {}
            for key, value in raw_expressions.items():
                # 判断 key 是否为类字段、属性
                if key not in cls.__dict__:
                    continue
                # 将布尔类型的字符串转换为布尔类型
                if isinstance(value, list) and value:
                    value = value[0]
                validated_expressions[key] = cls.transform_bool(key, value)
            # 判断 validated_expressions 是否为空
            if not validated_expressions:
                expressions = [None]
            else:
                expressions = [cls.__dict__[key].field == value for key, value in validated_expressions.items()]
        return expressions

    @classmethod
    def transform_bool(cls, key, value):
        """
        trans value from string to type that Field need
        :param key: Field name
        :param value:
        :return:
        """
        if isinstance(cls.__dict__[key].field, peewee.BooleanField):
            d = {"false": False, "False": False, "true": True, "True": True}
            value = d.get(value, bool(value))
            # value = [d.get(ve, bool(ve)) for ve in value]
            return value
        else:
            return value

    @classmethod
    def _simple_search(cls, fields: list = None, expressions: list = None):
        if expressions is None:
            expressions = [None]

        if fields is None:
            fields = []
        else:
            fields = [cls.__dict__[f].field for f in fields]
        ms = cls._custom_select(fields)
        result = ms.where(*expressions)  # todo need test
        return result

    @classmethod
    def simple_search(cls, fields: list = None, raw_expressions: dict = None):
        if raw_expressions is None:
            expressions = [None]
        else:
            expressions = cls.generate_expressions(raw_expressions)
        result = cls._simple_search(fields, expressions)
        return result

    @classmethod
    def _custom_select(cls, fields: list = None):
        """
        Function to define fields that simple search, override it when you need custom query
        :param fields:
        :return:
        """
        if fields is None:
            fields = []
        result = cls.select(*fields)
        return result

    def to_dict(self):
        d = self.__data__
        return d