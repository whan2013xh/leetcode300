# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-23
    FileName   : __init__.py.py
    Author     : Honghe
    Descreption: 
"""
from elasticsearch import Elasticsearch
from elasticsearch_dsl.connections import connections
from tuya_apollo_client import apollo_client
from milvus import Milvus, IndexType, MetricType
from peewee import MySQLDatabase

from src.common import logger,config
from src.models.base_milvus_handler import MilvusHandler



def init_es(config):
    """
    初始化ES
    :param config:
    :return:
    """
    env = config.get("ENV_NAME")
    sk = bytes(config.get("APOLLO_SK"), encoding="utf8")
    app_id = config.get("APOLLO_APP_ID")
    # client = apollo_client.TuyaApolloClient(app_id=app_id, env=env, sk=sk)
    #
    # configs = client.get_all(need_refetch=True)
    # baseuris = configs['es.data.host'].split(',')
    # configs = [
    #     {
    #         "baseuri": baseuri,
    #         "port": configs['es.data.port.restfull'],
    #         "user": configs['security.app.key.version'],
    #         "secret": configs['security.app.key']
    #     }
    #     for baseuri in baseuris
    # ]
    # hosts = ['http://qa_{user}:{secret}@{baseuri}:{port}'.format(**config) for config in configs]
    # hosts = 'http://qa-document_3:5c8d31b654489ca88581e217c70e2d169d4d523af53fbc409786991ad54ffdd2@elastic-proxy.common-in.wgine-dev.com:80'
    hosts = "172.30.68.102:9210"
    es_client = connections.create_connection(hosts= hosts)
    # es_client.indices.close("en_faq")
    # hosts = config.get("ES").get("ES_HOSTS")+":"+str(config.get("ES").get("ES_PORT"))
    # es_client = Elasticsearch(hosts)
    logger.info("es init succeed env: %s, hosts: %s" % (env, hosts))
    return es_client

def init_milvus(config):
    """
    初始化milvus
    :param config:
    :return:
    """
    milvus_config = config.get("MILVUS")
    milvus_client = Milvus(milvus_config['MILVUS_URL'], milvus_config['MILVUS_PORT'], pool_size=10, handler="HTTP")
    # milvus_client = Milvus(milvus_config['MILVUS_URL'], milvus_config['MILVUS_PORT'])
    res = MilvusHandler(milvus_client, milvus_config.get("MILVUS_TABLES"))
    return res.milvus_client

def init_db(config):
    database_name = config.get("MYSQL").get("NAME")
    mysql_user = config.get("MYSQL").get("USER")
    mysql_password = config.get("MYSQL").get("PASSWORD")
    mysql_host = config.get("MYSQL").get("HOST")
    mysql_port = config.get("MYSQL").get("PORT")
    db = MySQLDatabase(database_name, user=mysql_user, password=mysql_password,
                   host=mysql_host, port=mysql_port, charset='utf8mb4', autoconnect=False)
    return db


db = init_db
es_client = init_es(config)
milvus_client = None










