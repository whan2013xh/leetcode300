# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-26
    FileName   : faq_milvus_handler.py
    Author     : Honghe
    Descreption: 
"""
import enum

from src.common.config import config
from src.models.base_milvus_handler import MilvusHandler
from src.models.base_es_handler import Langeuage


class FaqMilvusHandler(MilvusHandler):
    def __init__(self):
        self.milvus_types = ["FAQ-ZH", "FAQ-EN"]
        self.collection_names = {"zh":config.get("FAQ-ZH")}







