# -*- coding: utf-8 -*-
"""
Author: bin zhou
Date: 2021-02-06
Description: 
"""
import grpc
import json
import copy
import math
import hashlib
import requests

from nltk.tokenize.punkt import PunktSentenceTokenizer, PunktLanguageVars

from src.common import config
from src.protos import nlp_basic_pb2_grpc
from src.protos.nlp_basic_pb2 import TextNormRequest
from src.common.md_parser import MdParser
from src.common.pre_process import Tokenizer
from src.common.character import CharacterNorm
from src.common.utils import hash_milvus_id, function_execute_time
from src.common import logger


class BulletPointLangVars(PunktLanguageVars):
    """
    定义中文的句子边界
    """
    sent_end_chars = ('。', '？', '！')


class DocParser(object):
    def __init__(self, config):
        # TODO: 调用关键词模型
        self.parser = MdParser()  # Md解析器
        self.channel = grpc.insecure_channel(config['NLP_BASIC_SERVER'])
        self.stub = nlp_basic_pb2_grpc.NLPBasicServerStub(self.channel)
        self.tokenizer = Tokenizer(config['STOPWORDS_PATH'])
        self.character_norm = CharacterNorm()
        self.sent_tokenizer = PunktSentenceTokenizer(lang_vars=BulletPointLangVars())

    def parse_data(self, data, is_pre):
        """
        单篇文档的解析
        :param data:
        :param is_pre:
        :return: es_records, SentId: sentences
        """
        content = data.get('content')
        json_content, _ = self.parser.parse(content)
        if len(json_content) == 0:  # content 为空
            logger.info("Content not exists, content: %s" % content)
            return []
        else:
            content_ids, records = self.build_mrc_record(json_content, data, is_pre)

        return content_ids, records

    def build_mrc_record(self, json_content: list, mrc_data: dict, bot_id, is_pre: int) -> (list, list):
        """
        构建入ES索引的数据格式
        :param json_content:
        :param data: mango中取出的数据
        :param is_pre:
        :return:
        """
        # content_ids = []  # 段落id
        records = []
        id2sentences = []  # [{'content_id': '', 'sent_id': '', 'sentence': ''}, {}]
        for idx, js_cont in enumerate(json_content):
            # logger.info('build_es_record, idx: %s, js_cont: %s' % (idx, js_cont))
            record = {}  # es record
            whitespace = ' '
            # 从MD解析器中提取数据
            subtitle = js_cont['subtitle']  # dict: {'2': '涂鸦', '3': '平台化'}
            if len(subtitle) == 0:
                ori_subtitles = []
                subtitles = ''
            else:
                ori_subtitles = list(subtitle.values())  # 段落子标题集合
                subtitles = self.list2tokens(ori_subtitles)  # 段落子标题集合（分词）
            ori_title = mrc_data.get('title')
            # 标题
            title = whitespace.join(self.tokenizer.tokenize(self.stub, ori_title, True, False))
            ori_content = js_cont['content']
            # 生成段落id(必须加上 _1 或 _2 区分test和app环境，否则同一条数据会覆盖)
            # content_id = hash_milvus_id(f"{ori_content}_{str(idx)}_{mrc_data.get('id')}_{mrc_data.get('channel_id')}")
            uuid = hash_milvus_id(f"{ori_content}_{str(idx)}_{mrc_data.get('id')}_{mrc_data.get('channel_id')}_{is_pre}")
            # 段落正文分词处理
            seg_content = whitespace.join(self.tokenizer.tokenize(self.stub, ori_content, False, False))
            # 句子拆分（先分词，标点符号分出，再切分句子）
            sentences = self.sent_tokenizer.tokenize(seg_content)
            sentences = [self.character_norm(sent) for sent in sentences]
            # 标准化seg_content
            norm_content = self.character_norm(seg_content)
            content_length = js_cont.get('content_length')
            # 个人上传的文档没有catalogs
            ori_catalogs = mrc_data.get('catalogs', [])
            catalogs = self.list2tokens(ori_catalogs)  # 文档目录（分词）
            # TODO: 计算content的keywords

            # 组装字典（ES的数据格式）
            record = {
                'bot_id': bot_id,
                'base_code': mrc_data.get('base_code'),
                'document_id': mrc_data.get('id'),
                'ori_title': ori_title,
                'title': title,
                'ori_subtitles': ori_subtitles,
                'subtitles': subtitles,
                'ori_content': ori_content,
                'content': norm_content,
                'content_length': content_length,
                'sentences': sentences,
                'ori_catalogs': ori_catalogs,
                'catalogs': catalogs,
                'doc_keywords': mrc_data.get('keywords', []),
                'doc_labels': mrc_data.get('labels', []),
                'keywords': '',
                'keywords_weight': {},
                'source': mrc_data.get('source', 0),
                'language': mrc_data.get('language'),
                'update_time': mrc_data.get('gmt_modified'),
                'is_hot': mrc_data.get('is_hot',False),
                'is_deleted': mrc_data.get('is_deleted',False),
                'is_pre': is_pre,
                "uuid": uuid
            }

            records.append(record)
            # content_ids.append(content_id)

        return records

    @function_execute_time
    def tfidf_keywords(self, querys, language, trace_id="qa_service", page_size=100):

        term_weight_url = config.get("TERM_WEIGHT")
        pages = math.ceil(len(querys) / page_size)
        result = []
        for i in range(pages):
            params = {
                "trace_id": trace_id,
                "querys": querys[i*page_size:(i+1)*page_size],
                "lang": language
            }
            response = requests.post(term_weight_url, json=params)
            tmp = response.json()
            if not tmp.get("success"):
                logger.info("faq get term_weight failed")
                return None
            result+=tmp.get("keywords")
        return result

    def cut_stop_words(self, words):
        stop_words = self.tokenizer.stopwords
        filter_words = []
        for word in words:
            if word not in stop_words:
                filter_words.append(word)
        return filter_words

    def build_faq_record(self, faq_data, language, trace_id="qa_service", base_code=None, bot_id=None, is_pre=0):
        """
        faq数据构建es索引
        :param data:
        :param is_pre:
        :return:
        """
        # bot_datalines = [bot_record.get('title') for bot_record in faq_data]
        bot_datalines = [bot_record.get('query') for bot_record in faq_data]
        # 1、归一化预处理
        bot_norm_datalines = self.data_norm(bot_datalines)
        logger.info(f"bot_datalines {bot_datalines},length {len(bot_datalines)} ,bot_norm_datalines {bot_norm_datalines} ,length {len(bot_norm_datalines)}")
        # 2、获取关键词
        term_weights = self.tfidf_keywords(bot_norm_datalines, language, trace_id)
        logger.info(f"term_weight {term_weights},length {len(term_weights)}")
        keywords = [[item[0] for item in term] for term in term_weights]
        logger.info(f"keywords {keywords},length {len(keywords)}")
        # weights = [[item[1] for item in term] for term in term_weights]
        # 3、构建索引
        # content_ids = []
        records = []
        parse_records = []
        for i, data_info in enumerate(faq_data):
            insert_char = '1' if data_info.get("is_standard") else '0'
            query_id = data_info.get("id") + insert_char + str(is_pre)
            record = {
                'bot_id': bot_id,
                'base_code': str(base_code),
                'query': bot_datalines[i],
                'query_id': query_id[3:].lstrip("0"),
                'norm_text': bot_norm_datalines[i],
                #'norm_text': "".join(self.cut_stop_words(keywords[i])),
                'keywords': " ".join(keywords[i]),
                'keywords_weight': json.dumps(term_weights[i], ensure_ascii=False),
                #'answer': data_info.get("answer"),
                'answer': "".join(self.cut_stop_words(keywords[i])),
                'answer_id': data_info.get("answer_id"),
                'is_standard': data_info.get("is_standard"),
                'catalogs': " ".join(data_info.get("catalogs",[])),
                'labels': " ".join(data_info.get("labels",[])),
                'language': data_info.get('language'),
                'update_time': data_info.get('gmt_modified'),
                'is_pre': is_pre,
                "knowledge_code": data_info.get("knowledge_code"),
                "source": 0,
                "uuid":query_id
            }
            # content_ids.append(data_info.get("id"))
            records.append(record)
            # 处理相似问题
            # similar_knowledge = data_info.get("similar_knowledge")
            # if similar_knowledge:
            #     similar_query = [knowledge.get("query") for knowledge in similar_knowledge]
            #     # 1、归一化预处理
            #     similar_norm_datalines = self.data_norm(similar_query)
            #     # 2、获取关键词
            #     similar_weights = self.tfidf_keywords(similar_norm_datalines,language, trace_id)
            #     similar_keywords = [[item[0] for item in term] for term in similar_weights]
            #     for index, knowledge in enumerate(similar_knowledge):
            #         similar_record = copy.deepcopy(record)
            #         similar_record["is_standard"] = False
            #         # 保证ID的唯一性
            #         similar_record["query_id"] = int(str(data_info.get("id")*10)+str(knowledge.get("id")*10))*10+is_pre
            #         similar_record["norm_text"] = similar_norm_datalines[index]
            #         similar_record["keywords"] = " ".join(similar_keywords[index])
            #         similar_record["keywords_weight"] = json.dumps(similar_weights[index], ensure_ascii=False)
            #         records.append(similar_record)
                    # content_ids.append(knowledge.get("id"))
        return records

    def list2tokens(self, lists: list, sep=' ') -> str:
        """
        将list集合的词，进行tokenize，
        如doc_subtitles = ['涂鸦智能', '云平台介绍'] -> '涂鸦 智能 云平台 介绍'
        :param lists:
        :param sep:
        :return:
        """
        results = ''
        for word in lists:
            if not word:
                continue
            tokens = self.tokenizer.tokenize(self.stub, word, True, False)
            for tok in tokens:
                results += sep + tok

        return results.strip()

    def content2sentences(self, ori_content: str, norm=True) -> list:
        """
        将原始段落拆分为句子（归一化）
        :param ori_content:
        :param norm:
        :return:
        """
        # 段落正文分词处理
        seg_content = ' '.join(self.tokenizer.tokenize(self.stub, ori_content, False, False))
        # 句子拆分（先分词，标点符号分出，再切分句子）
        sentences = self.sent_tokenizer.tokenize(seg_content)

        if norm:
            sentences = [self.character_norm(sent) for sent in sentences]

        return sentences

    @function_execute_time
    def data_norm(self, datalines):
        """
        数据标准化预处理
        :param datalines:
        :return:
        """
        normlines = []
        logger.info("faq start norm data")
        index = 0
        for dataline in datalines:
            logger.info(f"count {index},dataline {dataline}")
            norm_requests = TextNormRequest(trace_id='qa_service',
                                            text=dataline,
                                            tag_replace=False)
            norm_response = self.stub.text_norm(norm_requests)
            if not norm_response.success:
                raise ValueError("text norm failed!!!")
            normlines.append(norm_response.result)
            index+=1
            if index%100==0:
                logger.info(f"data norm count {index}")
        logger.info("faq end norm data")
        return normlines
