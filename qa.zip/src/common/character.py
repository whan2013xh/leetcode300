# -*- coding: utf-8 -*-
"""
Author: bin zhou
Date: 2021-04-06
Description: 
"""
import re
import unicodedata
from opencc import OpenCC

pattern = re.compile('[，。：“”【】《》？；、（）‘’『』「」﹃﹄〔〕—·]')


class CharacterNorm(object):
	def __init__(self):
		self.cc = OpenCC('t2s')

	def __call__(self, text):
		text = self.cc.convert(text)
		text = self.strQ2B(text)
		text = self.lower(text)
		return text

	@staticmethod
	def strQ2B(text):
		fps = re.findall(pattern, text)

		# re.findall: 搜索string，以列表形式返回全部能匹配的子串。

		# 对有中文特殊符号的文本进行符号替换

		if len(fps) > 0:
			text = text.replace('，', ',') \
				.replace('。', '.') \
				.replace('：', ':') \
				.replace('“', '"') \
				.replace('”', '"') \
				.replace('【', '[') \
				.replace('】', ']') \
				.replace('《', '<') \
				.replace('》', '>') \
				.replace('？', '?') \
				.replace('；', ':') \
				.replace('、', ',') \
				.replace('（', '(') \
				.replace('）', ')') \
				.replace('‘', "'") \
				.replace('’', "'") \
				.replace('’', "'") \
				.replace('『', "[") \
				.replace('』', "]") \
				.replace('「', "[") \
				.replace('」', "]") \
				.replace('﹃', "[") \
				.replace('﹄', "]") \
				.replace('〔', "{") \
				.replace('〕', "}") \
				.replace('—', "-") \
				.replace('·', ".")

		rstring = ""
		for uchar in text:
			inside_code = ord(uchar)
			# 全角空格直接转换
			if inside_code == 12288:
				inside_code = 32
			# 全角字符（除空格）根据关系转化
			elif 65374 >= inside_code >= 65281:
				inside_code -= 65248
			rstring += chr(inside_code)
		return rstring


	def lower(self,text):
		return text.lower()


if __name__ == "__main__":
	# character = CharacterNorm()
	q = "【我是谁】ｍｎ123abc博客园，。！？【】（）％＃＠＆１２３４５６７８９０；‘’“”《》『』"
	q = "1.0 时代 对 终端 消费 市场 的 教育 成果 逐步 显现 ， 用户 消费 逐步 升级 ， 对 智能 产品 从 认知 阶段 过渡 到 体验 阶段 ；"
	q = "尚恩·菲南（Shane Filan，），世界著名艺术家，也是世界上最著名的组合之一西城男孩()的主音。尚恩在爱尔兰斯莱戈郡长大，出生于一个非常大且关系非常紧密的大家庭，他有两个兄弟、三个姊妹。由于尚恩长得不高，他在校时有个绰号叫做“矮冬瓜”(Shorty)。尚恩最早的音乐影响力来自于莱昂纳尔·里奇(Lionel Richie)、比利·乔尔(Billy Joel)等歌手，不过，在麦可杰克森(Michael Jackson)发行《Bad》专辑的时候，麦可杰克森就成为他最崇拜的流行偶像，尚恩坦承：“那个时候他占据了我的人生，我还自学月球漫步的舞步呢！”在哥哥的鼓励后，尚恩参加《油脂小子》音乐剧在斯莱戈郡的Hawkswell剧院所举行的试演，他表示，就在那一刻他决定要当个演艺人员。此外，他非常喜欢骑马，他从一匹老马背上摔下来，造成膝盖受到轻伤。"
	character = CharacterNorm()
	print("ori query: %s" % character(q))
	print("aft query: %s" % character(q))
