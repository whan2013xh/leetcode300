# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-08-09
    FileName   : utils.py
    Author     : Honghe
    Descreption: 
"""
from functools import wraps
import hashlib
from time import time

import requests

from src.common import logger, config
from src.models import db


def hash_milvus_id(content):
    md5 = hashlib.md5()
    md5.update(content.encode('utf-8'))
    md5_value = md5.hexdigest()
    return md5_value

def logger_begin_end(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # 日志信息
        task = args[0]
        task_id = task.request.id
        task_args = task.request.args
        logger.info(f"Begin: id={ task_id }, args={ task_args }")

        # 链接数据库
        # connect_db(db)
        result = func(*args, **kwargs)
        # 关闭数据库
        # close_db(db)

        logger.info(f"End: id={ task_id }, args={ task_args }")
        return result

    return wrapper

def connect_db(db):
    if db.is_closed():
        db.connect()


def close_db(db):
    if not db.is_closed():
        db.close()


def function_execute_time(func):
    # 定义嵌套函数，用来打印出装饰的函数的执行时间
    def wrapper(*args, **kwargs):
        # 定义开始时间和结束时间，将func夹在中间执行，取得其返回值
        start = time()
        func_return = func(*args, **kwargs)
        end = time()
        # 打印方法名称和其执行时间
        logger.info(f'{func.__name__}() execute time: {end - start}s')
        # 返回func的返回值
        return func_return

    # 返回嵌套的函数
    return wrapper


class WeChatHandler(object):
    _url = "http://basic.tuya-inc.com:7007/qywx.do"

    _headers = {
        "Tuya-Intranet": "Tuya@intranet@2018",
        "Content-Type": "application/x-www-form-urlencoded"
    }

    _base = "xxx项目：QA数据同步模块{}\n" + \
            "任务名称：{}\n" + \
            "执行状态：{}\n" + \
            "任务信息：{}\n"


    def __init__(self, user_id, task_name):
        self.user_id = str(user_id) if user_id else "honghe.xu@tuya.com"
        self.task_name = str(task_name)


    def send(self, flag, message):
        status = "成功" if flag else "失败"
        msg = self._base.format(config.get("ENV_NAME"),self.task_name, status, str(message))
        url_token = config.get("text_parser_token")
        message_send_url = config.get("message_send_url")
        _headers = {
            "authorization": f"Bearer {url_token}"
        }
        send_message = {
            "text": msg,
            "user": self.user_id
        }
        logger.info(f"sss {self.user_id}")
        response = requests.post(message_send_url, json=send_message, headers=_headers)
        return response