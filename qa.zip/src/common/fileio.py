from enum import Enum
import os
from io import StringIO, BytesIO
import json

import requests
import pandas as pd
from pandas import DataFrame
import yaml
try:
    from yaml import CLoader as Loader, CDumper as Dumper
except ImportError:
    from yaml import Loader, Dumper

from src.common.logger import logger

def check_dir(base_dir):
    if not os.path.exists(base_dir):
        old_mask = os.umask(0o022)
        os.makedirs(base_dir)
        os.umask(old_mask)

class RequestFile(object):
    """
    request 文件
    """

    def __init__(self, file, schema_type=None):
        self.file = file
        self.name = self.file.name
        self.type = self.file.type
        self.body = self.file.body
        self.schema_type = schema_type
    
    @property
    def file_type(self):
        if self.name.endswith(".yml") or self.name.endswith(".yaml"):
            return FileType.YAML.value
        if self.name.endswith(".csv") or "csv" in self.type:
            return FileType.CSV.value
        if self.name.endswith(".xls") or self.name.endswith(".xlsx") or \
                    "excel" in self.type or self.type.endswith("sheet"):
            return FileType.EXCEL.value
        if self.name.endswith(".json") or "json" in self.type:
            return FileType.JSON.value
        return None
    
    def read(self, keep_default_na=True):
        """
        读取文件内容
        """
        if self.schema_type and self.schema_type != self.file_type:
            return None, f"只支持{ self.schema_type }类型的文件"

        if self.file_type == FileType.YAML.value:
            try:
                return YamlIO.read_str(self.body), None
            except Exception as e:
                return None, e
        
        if self.file_type == FileType.CSV.value:
            try:
                buffer = BytesIO(self.body)
                return CsvIO.read2PD(buffer, header=0), None
            except Exception as e:
                return None, e
        
        if self.file_type == FileType.EXCEL.value:
            try:
                buffer = BytesIO(self.body)
                return pd.read_excel(buffer, keep_default_na=keep_default_na), None
            except Exception as e:
                return None, e
        
        if self.file_type == FileType.JSON.value:
            try:
                return JsonIO.read_str(self.body), None
            except Exception as e:
                return None, e
        
        return None, f"暂不支持的请求文件类型: { self.type }"


class TmpFileMode(Enum):
    WRITE = "write"
    READ = "read"


class FileType(Enum):
    YAML = "yaml"
    YML = "yml"
    JSON = "json"
    CSV = "csv"
    EXCEL = "excel"
    XLSX = "xlsx"
    XLS = "xls"
    VIDEO = "video"
    MARKDOWN = "md"

formats = [".mp4",".avi"]


class YamlIO(object):
    """
    yaml 文件读写
    """
    @staticmethod
    def read_str(st: str):
        """
        读取yaml文件内容
        """
        try:
            return yaml.load(st, Loader=Loader)
        except:
            return None

    @staticmethod
    def read_file(file_path: str):
        """
        读取yaml文件内容
        """
        with open(file_path, "r") as fp:
            return yaml.load(fp, Loader=Loader)

    @staticmethod
    def write2str(obj):
        return yaml.dump(obj, allow_unicode=True,  default_flow_style=False)
    
    @staticmethod
    def write2file(file_path: str, obj):
        """
        向yaml文件写入内容
        """
        with open(file_path, "w", encoding="utf-8") as fp:
            yaml.dump(obj, fp, allow_unicode=True, Dumper=Dumper)


class JsonIO(object):
    """
    json 文件读写
    """
    @staticmethod
    def read_str(st: str):
        """
        读取json文件内容
        """
        return json.loads(st, encoding="utf-8")
    
    @staticmethod
    def write2str(obj):
        """
        读取json文件内容
        """
        return json.dumps(obj, ensure_ascii=False, indent=4)

    @staticmethod
    def read_file(file_path: str):
        """
        读取json文件内容
        """
        with open(file_path, "r") as fp:
            return json.load(fp)
    
    @staticmethod
    def write2file(file_path: str, obj):
        """
        向json文件写入内容
        """
        with open(file_path, "w") as fp:
            json.dump(obj, fp, ensure_ascii=False, indent=4)


class CsvIO(object):
    """
    csv 文件读写
    """

    @staticmethod
    def read2PD(file_path: str, header=None, names=None):
        """
        读取为 pandas 的 DataFrame 格式
        """
        return pd.read_csv(file_path, header=header, names=names, encoding="utf-8")
    
    @staticmethod
    def writeFromPD(file_path: str, pd_dataframe: DataFrame, sep=",", header=True, index=False):
        """
        将 pandas 的 DataFrame 格式写入 csv 文件
        """
        pd_dataframe.to_csv(file_path, sep=sep, header=header, index=index, encoding="utf-8")


class URLFile(object):
    """
    读取web数据文件，支持https传输
    """

    def __init__(self, file_url, schema_type=None):
        self.file_url = file_url
        self.name = self.file_url.split("?")[0].split("/")[-1]
        self.type = self.name.split(".")[-1]
        self.schema_type = schema_type
        self.https_flag = self.file_url.startswith("https")
        self.web_file = URLFile.get_web_file(file_url)


    @property
    def file_type(self):
        if self.name.endswith(".yml") or self.name.endswith(".yaml"):
            return FileType.YAML.value
        if self.name.endswith(".csv") or "csv" in self.type:
            return FileType.CSV.value
        if self.name.endswith(".xls") or self.name.endswith(".xlsx") or \
                "excel" in self.type or self.type.endswith("sheet"):
            return FileType.EXCEL.value
        if self.name.endswith(".json") or "json" in self.type:
            return FileType.JSON.value
        if self.name.endswith(".md") or "md" in self.type:
            return FileType.MARKDOWN.value
        return None

    @classmethod
    def get_web_file(cls, file_url, stream=False):
        # # 如果url里包含中文需要转换
        # # 如果是https请求需要设置ssl
        # context = ssl._create_unverified_context() if self.https_flag else None
        # safe_url = parse.quote(file_url, safe='/:?=.')
        # return request.urlopen(safe_url, context=context)
        return requests.get(file_url, stream=stream)

    def read(self, keep_default_na=True):
        """
        读取文件内容
        """
        if self.schema_type and self.schema_type != self.file_type:
            return None, f"只支持{self.schema_type}类型的文件"

        file_data = self.web_file.content

        if self.file_type == FileType.YAML.value:
            try:
                return YamlIO.read_str(file_data.decode('utf8')), None
            except Exception as e:
                return None, e

        if self.file_type == FileType.CSV.value:
            try:
                return CsvIO.read2PD(StringIO(file_data.decode()), header=0), None
            except Exception as e:
                return None, e

        if self.file_type == FileType.EXCEL.value:
            try:
                # buffer = BytesIO(self.body)
                return pd.read_excel(file_data, keep_default_na=keep_default_na), None
            except Exception as e:
                return None, e

        if self.file_type == FileType.JSON.value:
            try:
                return JsonIO.read_str(file_data.decode('utf8')), None
            except Exception as e:
                return None, e

        return None, f"暂不支持的请求文件类型: {self.type}"
