# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-21
    FileName   : config.py
    Author     : Honghe
    Descreption: 配置类
"""

import os
from yaml import load, Loader


def standard_request_max_size(config):
    request_max_size = config.get("REQUEST_MAX_SIZE")
    if request_max_size is not None and isinstance(request_max_size, str):
        config["REQUEST_MAX_SIZE"] = eval(request_max_size)


with open("./src/config/config.yaml") as f:
    config_set = load(f, Loader=Loader)

env_name = os.getenv("QA_ENV", "local")
env_name = os.getenv("QA_ENV", "daily")
# env_name = os.getenv("QA_ENV", "online")

config = config_set[env_name]
standard_request_max_size(config)