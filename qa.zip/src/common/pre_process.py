# -*- coding: utf-8 -*-
"""
Author: bin zhou
Date: 2021-02-06
Description: 
"""
import time
import logging
import traceback
from src.protos import nlp_basic_pb2_grpc
from src.protos.nlp_basic_pb2 import TokenRequest

logger = logging.getLogger(__name__)


class Tokenizer(object):
	def __init__(self, stopwords_path):
		self.stopwords = get_stopwords(stopwords_path)

	def tokenize(self, stub, text, norm, postag):
		"""
		grpc server tokenize
		:return:
		"""
		request = TokenRequest(
			trace_id='',
			text=text,
			channel='common',
			norm=norm,
			postag=postag)
		start = time.time()
		try:
			response = stub.tokenize(request, timeout=2.0)
		except Exception as e:
			logger.info("text: %s" % text)
			logger.info("Response failed: {}".format(traceback.format_exc()))
			raise e
		cost = time.time() - start
		result = response.tokens

		if type(result) != list:
			result = list(result)

		return result


def get_stopwords(stopwords_path):
	stopwords = []
	with open(stopwords_path, 'r') as rf:
		for line in rf:
			stopwords.append(line.strip())

	return stopwords


def get_word(vocab, index):
	"""
	在vocab中根据idx获取word
	:param index:
	:return:
	"""
	inverse_vocab = {v: k for k, v in vocab.items()}
	word = inverse_vocab[index]

	return word


if __name__ == '__main__':
	import grpc
	from config import config

	channel = grpc.insecure_channel(config['NLP_BASIC_SERVER'])
	stub = nlp_basic_pb2_grpc.NLPBasicServerStub(channel)
	test_text = '涂鸦云平台有哪些可用区'
	test_text = ''

	tokenizer = Tokenizer(config['STOPWORDS_PATH'])
	pairs = tokenizer.tokenize(stub, test_text, True, False)
	print(pairs)
