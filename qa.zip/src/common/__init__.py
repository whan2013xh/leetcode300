# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-21
    FileName   : __init__.py.py
    Author     : Honghe
    Descreption: 
"""

from sanic.config import Config

from src.common.logger import logger
from src.common.config import config as base_config


class BaseConfig:
    def __init__(self, **entries):
        self.__dict__.update(entries)


# 初始化配置
config = Config(base_config)
# 加载基础配置
# config.from_object(BaseConfig(**base_config))
# 从环境变量中加载配置
config.load_environment_vars("QA_")