# -*- coding: utf-8 -*-
"""
Author: bin zhou
Date: 2021-02-06
Description: 表格：|||, 图片：![](), 网页：[]()
"""
import mistune
import re
import json
import copy

from src.common.logger import logger

read_type = ["heading", "paragraph", "text"]

pattern_table_1 = re.compile(r'(\|\s*(.+)\n*)+')  # 第一种表格的形式
pattern_table_2 = re.compile(r'(<(t\w+|!--.+)>\n)(.+\n)+</t\w+>')  # 第二种表格的形式
pattern_image = re.compile(r'!\[.*\]\((.+)\)')  # 图片
pattern_url_1 = re.compile(r'\[.+\]\((.+)\)')  # url地址
pattern_url_2 = re.compile(r'<https://.+>')
pattern_font = re.compile(r'(<font\s*color=\W\w+>)(.+)(</font>)')  # 删除文本中的颜色修饰
pattern_chn = re.compile(r'[\u4e00-\u9fa5]+')  # 中文
pattern_newline = re.compile(r'\n+')  # 删除多余换行
pattern_title_idx = re.compile(r'^[0-9]+\.?')  # 删除标题前的数字
pattern_font_bold = re.compile(r'\*{1,2}')  # 删除正文中对加粗字体



class MdParser(object):
	def __init__(self):
		pass

	@staticmethod
	def filter(text):
		"""
		过滤表格、url、图片等文本
		:param text:
		:return:
		"""
		del_table = pattern_table_1.sub('', text)
		del_table = pattern_table_2.sub('', del_table)
		del_image = pattern_image.sub('', del_table)
		del_url = pattern_url_1.sub('', del_image)
		del_url = pattern_url_2.sub('', del_url)
		del_font = pattern_font.sub(r'\2', del_url)

		return del_font

	def parse(self, text: str) -> (json, list):
		"""

		:param text: 预处理后的markdown文档
		:return:
		"""
		markdown = mistune.Markdown()
		text_lists = markdown.block(mistune.preprocessing(text))
		parsed_lists = []
		# 处理每个list中的text
		for idx, line in enumerate(text_lists):
			# 过滤不包含text的list:
			if line.get("type") not in read_type:
				continue
			if 'text' not in line:
				continue
			# 过滤表格、url等内容
			text = self.filter(line['text']).strip()
			line['text'] = text
			# 过滤空text
			if text == '':
				continue
			# 过滤纯英文的text
			# 不过滤纯英文的title
			# elif not pattern_chn.search(text) and 'level' not in line:
			# 	continue
			# 已有标题，过滤错误解析出的标题
			elif idx > 0 and line['type'] == 'heading' and line['level'] == 1 and line['text'] == '#':
				continue
			parsed_lists.append(line)
		json_data, doc_subtitles = self.parse_text_to_json(parsed_lists)

		return json_data, doc_subtitles

	def parse_text_to_json(self, text_lists: list) -> (json, list):
		"""
		将每一段文本处理为（标题，正文）
		:param text_lists:
		:return:
		"""
		# 文本和标题的格式化
		json_content = []
		level = 0
		# 根据子标题level定义
		subtitle = {}
		# 初始化文档一级标题
		title = None
		# 存储单篇文档子标题
		doc_subtitles = []
		# 读取每一个段落：
		for plist in text_lists:
			p_type = plist['type']
			# 处理子标题
			if p_type == 'heading':
				p_level = plist['level']
				# 过滤主标题
				if p_level == 1:
					title = plist['text']
					continue
				else:  # 提取文档所有子标题
					doc_subtitle = self.post_processing_title(plist['text'])
					if doc_subtitle not in doc_subtitles:
						doc_subtitles.append(doc_subtitle)
				# 遇到下一级标题
				if p_level > level:
					level = p_level
					_subtitle = self.post_processing_title(plist['text'])
					subtitle[str(level)] = _subtitle
				# 遇到同级标题
				elif p_level == level:
					# 检查上一个段落的正文标题,是否包含当前的subtitle
					if not json_content:
						previous_subtitle = []  # 如，title = '统计服务'
					else:
						previous_subtitle = json_content[-1]['subtitle']
					if previous_subtitle != copy.deepcopy(subtitle):
						row_data = {
							'subtitle': copy.deepcopy(subtitle),
							'content': '',
							'content_length': 0
						}
						json_content.append(row_data)
					# 删除同级标题，替换新标题
					level = p_level
					_subtitle = self.post_processing_title(plist['text'])
					subtitle.pop(str(level))  # 删除之前的同级标题
					subtitle[str(level)] = _subtitle
				# 遇到上一级标题
				else:
					# 检查上一个段落的正文标题,是否包含当前的subtitle
					if not json_content:
						previous_subtitle = []  # 如，title = '8266 插座demo说明'
					else:
						previous_subtitle = json_content[-1]['subtitle']
					if previous_subtitle != copy.deepcopy(subtitle):
						row_data = {
							'subtitle': copy.deepcopy(subtitle),
							'content': '',
							'content_length': 0
						}
						json_content.append(row_data)
					# 获取当前subtitle的key
					level = p_level
					subtitle_keys = [int(i) for i in list(subtitle.keys())]
					# 删除当前level或大于当前level的子标题
					for key in subtitle_keys:
						if key >= level:
							subtitle.pop(str(key), None)
					_subtitle = self.post_processing_title(plist['text'])
					subtitle[str(level)] = _subtitle
			# 处理paragraph
			else:
				content = self.post_processing_content(plist['text'])
				row_data = {
					'subtitle': copy.deepcopy(subtitle),
					'content': content,
					'content_length': len(content)
				}
				json_content.append(row_data)

		logger.info('title: %s, paragraph: %s' % (title, len(json_content)))

		return json_content, doc_subtitles

	@staticmethod
	def post_processing_title(text: str) -> str:
		"""
		标题的后处理
		:param text:
		:return:
		"""
		# del_title_idx = pattern_title_idx.sub('', text)
		del_newline = pattern_newline.sub('', text)
		del_font_bold = pattern_font_bold.sub('', del_newline)
		del_strip = del_font_bold.strip()

		return del_strip

	@staticmethod
	def post_processing_content(text: str) -> str:
		"""
		正文的后处理
		:param text:
		:return:
		"""
		del_newline = pattern_newline.sub('', text)
		del_font_bold = pattern_font_bold.sub('', del_newline)
		del_strip = del_font_bold.strip()

		return del_strip


if __name__ == '__main__':
	test_text = "# 视频加载流程\n\n## P2P 连接流程\n\n门铃设备，可不做是否休眠判断，直接调用门铃唤醒接口，0.1 秒调用一次，一共调用三次。第一次调用门铃唤醒接口后，可直接调用 P2P 连接。所以这里不用区分是否是门铃设备，通用的\nP2P 连接流程如下：\n\n<div align=center><img src=\"https://images.tuyacn.com/fe-static/docs/img/318f8133-f775-4752-a37c-8556fb72d018.png\" width=\"100%\" height=\"100%\"></div>\n\n## 实时预览流程\n\n<div align=center><img src=\"https://images.tuyacn.com/fe-static/docs/img/f347add9-1315-444d-86a4-f50f42df52a9.png\n\" width=\"100%\" height=\"100%\"></div>\n\n## SD 卡回放流程\n\n<div align=center><img src=\"https://images.tuyacn.com/fe-static/docs/img/60d96ee9-5681-4ff1-bddc-c499e6a239f0.png\n\" width=\"100%\" height=\"100%\"></div>\n\n## 云存储播放流程\n\n<div align=center><img src=\"https://images.tuyacn.com/fe-static/docs/img/b3c9fc54-4813-4a65-b1f4-ee2cefcb333f.png\n\" width=\"100%\" height=\"100%\"></div>\n"
	md_parser = MdParser()
	result = md_parser.parse(test_text)
	pass
