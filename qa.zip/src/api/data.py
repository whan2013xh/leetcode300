# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-08-31
    FileName   : data.py
    Author     : Honghe
    Descreption: 
"""
from celery import chain
import time
# from queue import Queue

from sanic import Blueprint
import requests
from playhouse.shortcuts import model_to_dict

#
from src.common import logger, config
from src.api.base import get_request_json, response_json, ResponseCode
from src.services.mysql_services import MysqlServices
from src.models.async_task import AsyncTask
from src.models.mrc_sentences import SyncType, MrcSentences
from src.common.parser import DocParser


#
qa_data = Blueprint("qa_data", url_prefix="/qa_data")

@qa_data.post("/search")
async def search(request):
    """
    搜索数据
    """
    # 获取请求数据
    params = get_request_json(request)
    # 判断 service是否存在

    ms, limit, offset = MysqlServices.get_page_params(params)
    logger.info(f"search params {params}")
    if ms is None:
        return response_json(ResponseCode.FAIL,{"msg": "limit or offset must be int"}, 200)
    total = ms.count()
    page_ms = ms.order_by(MrcSentences.id.desc()).limit(limit).offset(offset)
    page_res = [record.to_dict() for record in page_ms]

    return response_json(ResponseCode.OK, "search mrc sentences succeed", 200, {"data":page_res,"total":total})

@qa_data.post("/norm")
async def norm_data(request):
    params = get_request_json(request)
    doc_parser = DocParser(config)
    data_lines = params.get("data_lines")
    res = doc_parser.data_norm(data_lines)
    return response_json(ResponseCode.OK, "norm sentences succeed", 200, {"data":res,"total":len(res)})
