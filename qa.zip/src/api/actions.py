# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-21
    FileName   : sync_tasks.py
    Author     : Honghe
    Descreption: 处理删除/同步/发布请求
"""
from __future__ import absolute_import, unicode_literals
from celery import chain
import time
# from queue import Queue
from sanic import Blueprint

import requests

#
from src.common import logger, config
from src.api.base import get_request_json, response_json, ResponseCode, qa_response_json
from src.models.async_task import AsyncTask
from src.models.mrc_sentences import SyncType
from src.celery_task.task import sync_es_data, get_sync_data, sync_meta_data, modify_sync_data, sync_milvus_data,test_milvus

#
actions = Blueprint("actions", url_prefix="/actions")


def get_faq_answer(params):
    url = config.get("FAQ_SERVICE")
    params["qaTypes"] = "faq"
    response = requests.post(url, params)
    if not response.get("success"):
        logger.info(f"get faq answer failed")
        return None
    answers = response.get("answers")
    result = []
    for answer in answers:
        tmp = {
            "knowledge_code": answer.get("ansId"),
            "score": answer.get("score"),
            "fromID": answer.get("fromID"),
            "qa_type": answer.get("qaType"),
            "answer": {
                "query": answer.get("question"),  # 相似问题
                "query_id": answer.get("query_id"),  # 相似问题的query_id
                "catalogs": answer.get("catalogs"),  # 类目
                "labels": answer.get("labels"),  # 标签
                "is_standard": answer.get("is_standard"),  # 是否标准问题
                "language": answer.get("language"),  # 语种
                "answer": answer.get("ansTxt")  # 答案
            }
        }
        result.append(tmp)
    return result


def get_mrc_answer(params):
    url = config.get("MRC_SERVICE")
    response = requests.post(url, json=params)
    if not response.get("success"):
        logger.info(f"get mrc answer failed")
        return None
    answers = response.get("answers")
    return answers


def result_sort(faq_result, mrc_result, faq_weight=1, mrc_weight=0.5):
    for answer in mrc_result:
        answer["score"] = (mrc_weight / faq_weight) * answer.get("score")
    result = faq_result + mrc_result
    result.sort(key=lambda x: x.get("score"), reverse=True)
    return result

@actions.get("/health")
async def qa_health(request):
    return qa_response_json(ResponseCode.OK, message="qa service is health")

@actions.post("/qa_router")
async def qa_router(request):
    """
    :param request:
    :return:
    """
    request_json = get_request_json(request)
    if not request_json:
        return qa_response_json(ResponseCode.FAIL, message="请求体异常")
    start = time.time()
    request_content = request.json
    query = request_content.get("query")
    trace_id = request_content.get("traceId")
    if query is None:
        return qa_response_json(ResponseCode.FAIL, message="query字段必填")
    faq_result = get_faq_answer(request_content)
    mrc_result = get_mrc_answer(request_content)
    result = result_sort(faq_result, mrc_result, faq_weight=1, mrc_weight=0.5)
    logger.info(f"qa_router params {request_content} total cost time:{time.time() - start}")
    return qa_response_json(ResponseCode.OK, message="qa router 查询成功", query=query, traceId=trace_id, data=result)


@actions.post("/synchronize")
async def synchronize(request):
    request_json = get_request_json(request)
    if not request_json:
        return response_json(ResponseCode.FAIL, "请求体异常")
    logger.info(f"get synchronize request params {request_json}")
    bot_id = request_json['botId']
    base_code = request_json['baseCode']
    sync_type = request_json['syncType']  # 0:删除,1:同步,2:发布,-1:下架
    trace_id = request_json['traceId']
    language = request_json.get("language")
    knowledge_type = request_json.get("knowledgeType")
    tenantId = request_json.get("tenantId")
    env = request_json.get("env","online")
    # if sync_type==SyncType.PUBLISH.value:
    #     check_flag = check_robot_ready(bot_id, knowledge_type)
    #     if not check_flag:
    #         return response_json(ResponseCode.FAIL, "训练平台模型未发布，请先发布")
    # 创建异步任务
    cur_time = int(time.time() * 1000)
    async_name = f"{bot_id}_{base_code}_{sync_type}_{cur_time}"

    result = None
    async_task = AsyncTask.create_instance({"name": async_name, "params": request_json})
    # 使用同步还是异步的开关
    if config.get("SYNC"):
        tmp_result = get_sync_data(bot_id, base_code, knowledge_type, sync_type, tenantId=tenantId, language=language,
                                       trace_id=trace_id)
        es_result = sync_es_data(tmp_result,bot_id, base_code, knowledge_type=knowledge_type, sync_type=sync_type,language=language,trace_id=trace_id)
        meta_result = sync_meta_data(es_result,bot_id, base_code, sync_type, knowledge_type, language, trace_id=trace_id)
        milvus_Result = sync_milvus_data(meta_result,bot_id, base_code, sync_type, knowledge_type, language,trace_id)
        modify_Res = modify_sync_data(milvus_Result,base_code, bot_id, knowledge_type, tenantId=tenantId, task_id="async_task.id")
    else:

        # result = chain(get_sync_data.s(bot_id, base_code, knowledge_type, sync_type, tenantId=tenantId, language=language,
        #                                trace_id=trace_id, env=env) | \
        #                sync_es_data.s(bot_id, base_code, knowledge_type=knowledge_type, sync_type=sync_type,language=language,trace_id=trace_id) | \
        #                sync_meta_data.s(bot_id, base_code, sync_type, knowledge_type, language, trace_id=trace_id) | \
        #                sync_milvus_data.s(bot_id, base_code, sync_type, knowledge_type, language,trace_id) | \
        #                modify_sync_data.s(base_code, bot_id, knowledge_type, tenantId=tenantId, task_id=async_task.id, env=env))()
        result = chain(
            get_sync_data.s(bot_id, base_code, knowledge_type, sync_type, tenantId=tenantId, language=language,
                            trace_id=trace_id, env=env) | \
            sync_es_data.s(bot_id, base_code, knowledge_type=knowledge_type, sync_type=sync_type, language=language,
                           trace_id=trace_id) | \
            modify_sync_data.s(base_code, bot_id, knowledge_type, tenantId=tenantId, task_id="async_task.id", env=env))()
        async_task.update_instance({"async_id": result.id})
    return response_json(ResponseCode.OK, trace_id, 200, {"bot_id": bot_id})


def check_robot_ready(bot_id, knowledge_type):
    url = config.get("CHECK_ROBOT_URL")
    params = {
        "isSingle": True,
        "origin": config.get("ORIGIN"),
        "target": config.get("TARGET").get(knowledge_type),
        "ownerCode": bot_id,
    }
    headers = {
        "authorization": f"Bearer {config.get('TOKEN')}"
    }
    start = time.time()
    response = requests.get(url, params=params, headers=headers).json().get("data")
    if not response.get("success"):
        logger.info(f"{bot_id} robot not ready.")
        return False
    logger.info(f"check robot cost{time.time() - start}.")
    return True

@actions.post("/test")
async def test(request):
    test_milvus.delay(count=10)
    return qa_response_json(ResponseCode.OK, message="qa router 查询成功")

import uvloop
@actions.post("/test2")
def test(request):

    coroutine = test_milvus2(count=10)

    #loop = asyncio.get_event_loop()
    loop = uvloop.new_event_loop()
    asyncio.set_event_loop(loop)
    task = loop.create_task(coroutine)
    print(task)  # pending

    loop.run_until_complete(task)
    loop.close()
    print(task)
    return qa_response_json(ResponseCode.OK, message="qa router 查询成功")

import asyncio
from milvus import Milvus
async def test_milvus2(count):
    for i in range(count):
        milvus_config = config.get("MILVUS")
        milvus_client = Milvus(milvus_config['MILVUS_URL'], milvus_config['MILVUS_PORT'], pool_size=1)
        print(f"====version {milvus_client.server_version()}")
        #logger.info(f"init milvus {app.milvus_client.list_partitions('mrc_sentence_rank_test')}")