# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-21
    FileName   : base.py
    Author     : Honghe
    Descreption: 
"""
import traceback
from enum import Enum

from sanic import response
from sanic.exceptions import SanicException



class ResponseCode(Enum):
    OK = True
    FAIL = False


def get_request_json(request):
    try:
        return request.json
    except:
        return {}


def response_json(code=ResponseCode.OK, message="", status=200, data=None):
    return response.json({
        "success": code.value,
        "message": message,
        "data": data
    }, status, headers={"Access-Control-Allow-Origin": "*"})

def qa_response_json(code=ResponseCode.OK, query="", message="",status=200, traceId=None, data=None):
    return response.json({
        "success": code.value,
        "message": message,
        "query": query,
        "answers": data,
        "traceId": traceId
    }, status, headers={"Access-Control-Allow-Origin": "*"})


def handle_exception(request, e):
    code = ResponseCode.FAIL
    message = repr(e)
    status = 500

    if isinstance(e, SanicException):
        status = e.status_code
    else:
        message = e.message
        if e.code is not None:
            code = e.code
        status = 200

    data = {}
    if request.app.config["DEBUG"]:
        data["exception"] = traceback.format_exc()

    return response_json(code, message, status, **data)
