# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-23
    FileName   : milvus_task.py
    Author     : Honghe
    Descreption: 
"""
import math
from milvus import Milvus

import numpy as np

from src.celery_task.app import app
from src.common.config import config
from src.common.logger import logger
from src.services.milvus_services import MilvusServices
from src.services.es_services import ESServices
from src.models.mrc_sentences import SyncType
from src.models.base_milvus_handler import MilvusHandler
from src.models import init_milvus
from src.models.mrc_sentences import MrcSentences
from src.celery_task.task.base_task import SyncTask
from src.common.utils import logger_begin_end


def handle_mrc_data(meta_data, bot_id, base_code, sync_type, language="zh", trace_id=None, limit=100, size=2):
    """
    处理MRC矢量数据：
    1、从meta数据库获取待处理的数据，分为删除和写入的
    2、
    :param meta_data:
    :param bot_id:
    :param base_code:
    :param sync_type:
    :param language:
    :param trace_id:
    :param limit:
    :return:
    """
    #
    sync_result = meta_data.get("sync_result")
    sync_time = sync_result.get("sync_time")
    collection_names = config.get("MILVUS").get("MRC")
    total = MrcSentences.select().where((MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code) & (
                MrcSentences.sync_time == sync_time)).count()
    logger.info(f"total record {total}")
    pages = math.ceil(total / limit)
    deleted_ids = []
    write_ids = []
    sentences_data = []
    # milvus_config = config.get("MILVUS")
    # milvus_client = Milvus(milvus_config['MILVUS_URL'], milvus_config['MILVUS_PORT'])
    # 1、分页获取sentence数据
    for page in range(pages):
        offset = page * limit
        tmp_sentences = MrcSentences.select(MrcSentences.id, MrcSentences.sentence, MrcSentences.is_deleted).where(
            (MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code) & (
                        MrcSentences.sync_time == sync_time)).order_by(MrcSentences.id).limit(limit).offset(offset)
        for record in tmp_sentences:
            if record.is_deleted:
                deleted_ids.append(record.id)
            else:
                write_ids.append(record.id)
                sentences_data.append(record.sentence)
    collection_tables = collection_names.get("MILVUS_COLLECTION_NAME")
    logger.info(f" delete ids {deleted_ids},write_id {write_ids}, len{len(write_ids)}")
    # 2、删除就把测试和线上都删除

    if sync_type == SyncType.DELETE.value or sync_type == SyncType.OFFSHELF.value:
        if deleted_ids:
            delete_res = MilvusHandler.delete_vectors(app.milvus_client, bot_id, deleted_ids,collection_tables)
            logger.info(f"删除矢量数据 res {delete_res}")
            # return delete_res
        if sync_type == SyncType.DELETE.value:
            MrcSentences.delete().where((MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code)).execute()
        else:
            MrcSentences.delete().where(
                (MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code) & (MrcSentences.id.in_(deleted_ids))).execute()
        return True
    # 3、同步先处理要删除的句子，再获取矢量写入
    MrcSentences.delete().where(
        (MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code) & (
            MrcSentences.id.in_(deleted_ids))).execute()
    sync_collection = collection_tables[0] if sync_type == SyncType.SYNC.value else collection_tables[1]
    if deleted_ids:
        delete_res = MilvusHandler.delete_vectors(app.milvus_client, bot_id, deleted_ids, [sync_collection])
        if not delete_res:
            logger.info(f"bot_id {bot_id},base_code {base_code}, delete vector failed")
            return False
    target = config.get("TARGET").get("mrc")
    sentence_vers = []
    pages = math.ceil(len(sentences_data)/size)
    for i in range(pages):
        params = {
            "trace_id": trace_id,
            "data": sentences_data[i * size:(i + 1) * size],
            "data_type": "doc"
        }
        tmp = MilvusServices.handle_vec_data(params, bot_id, sync_type, target)
        if tmp is None:
            logger.info(f"bot_id {bot_id},base_code {base_code},page {i} cal mrc rank vectors failed")
            return False
        rank_update_res = MilvusHandler.update_vectors(app.milvus_client, bot_id, collection_name=sync_collection,
                                                       ids=write_ids[i * size:(i + 1) * size], vectors=tmp)
        if not rank_update_res:
            logger.info(f"bot_id {bot_id},base_code {base_code},page {i} update rank vector failed")
            return False
        # sentence_vers += tmp
    # 非空才进行处理
    # if len(write_ids)>0:
    #     rank_update_res = MilvusHandler.update_vectors(app.milvus_client, bot_id, collection_name=sync_collection,
    #                                                    ids=write_ids, vectors=sentence_vers)
    #     if not rank_update_res:
    #         logger.info(f"bot_id {bot_id},base_code {base_code}, update rank vector failed")
    #         return False
    return True


def handle_faq_data(meta_data, bot_id, base_code, sync_type, language="zh", trace_id=None, size=6):
    """
    处理FAQ索引数据，FAQ分为精排矢量和召回矢量，一个部署在训练平台，一个是独立服务
    1、删除库，就拿到所有FAQ ID来进行删除
    2、同步/上线，先删除其中需要删除的，然后更新或者创建，实际也是先删除所有再创建
    :param meta_data:
    :param bot_id:
    :param base_code:
    :param sync_type:
    :param language:
    :param trace_id:
    :return:
    """
    deleted_ids = meta_data.get("deleted_ids")
    faq_data = meta_data.get("es_record")
    faq_type = "FAQ-ZH" if language == "zh" else "FAQ-EN"
    collection_names = config.get("MILVUS").get(faq_type)

    if (sync_type == SyncType.DELETE.value or sync_type == SyncType.OFFSHELF.value) and deleted_ids:
        delete_res = MilvusHandler.delete_vectors(app.milvus_client, bot_id, deleted_ids,
                                                  collection_names.get("MILVUS_COLLECTION_NAME"))
        return delete_res

    # 1、获取矢量
    querys = [query.get("query") for query in faq_data]
    query_id = [int(query.get("id")) for query in faq_data]
    uuids = [int(query.get("uuid")) for query in faq_data]
    # 2、插入
    sync_collection_name = []
    if sync_type == SyncType.SYNC.value:
        rank_collection = collection_names.get("MILVUS_COLLECTION_NAME")[0]
        encode_collection = collection_names.get("MILVUS_COLLECTION_NAME")[2]
    else:
        rank_collection = collection_names.get("MILVUS_COLLECTION_NAME")[1]
        encode_collection = collection_names.get("MILVUS_COLLECTION_NAME")[3]
    sync_collection_name.append(rank_collection)
    sync_collection_name.append(encode_collection)
    if deleted_ids:
        delete_res = MilvusHandler.delete_vectors(app.milvus_client, bot_id, deleted_ids, sync_collection_name)
        if not delete_res:
            logger.info(f"bot_id {bot_id},base_code {base_code}, delete vector failed")
            return False
    target = config.get("TARGET").get("faq")
    pages = math.ceil(len(querys)/size)
    query_vecs = []
    encode_vecs = []
    for i in range(pages):
        params = {
            "trace_id": trace_id,
            "data": querys[i*size:(i+1)*size],
            "data_type": "doc"
        }

        tmp = MilvusServices.handle_vec_data(params, bot_id, sync_type, target)
        logger.info(f"bot_id {bot_id},base_code {base_code},page {i},total {pages}")
        if tmp is None:
            logger.info(f"bot_id {bot_id},base_code {base_code},page {i} cal faq rank vectors failed")
            return False
        # query_vecs += tmp
        tmp_encode = MilvusServices.handle_faq_encode(querys[i*size:(i+1)*size], language, trace_id)
        if tmp_encode is None:
            logger.info(f"bot_id {bot_id},base_code {base_code},page {i} cal faq vectors failed")
            return False
        # encode_vecs += tmp_encode
        rank_update_res = MilvusHandler.update_vectors(app.milvus_client, bot_id, collection_name=rank_collection,
                                                       ids=query_id[i*size:(i+1)*size], vectors=tmp)
        if not rank_update_res:
            logger.info(f"bot_id {bot_id},base_code {base_code},page {i} update rank vector failed")
            return False
        encode_update_res = MilvusHandler.update_vectors(app.milvus_client, bot_id, collection_name=encode_collection,
                                                          ids=query_id[i*size:(i+1)*size], vectors=tmp_encode)
        if not encode_update_res:
            logger.info(f"bot_id {bot_id},base_code {base_code},page {i} update encode vector failed")
            return False
        if i%100==0 or (i==(pages-1) and pages<100):
            app.milvus_client.compact(rank_collection)
            app.milvus_client.compact(encode_collection)
        # es_index = language + "_faq"
        # vertor_es = [{"uuid":tmp_id,"encode_vector":np.array(tmp_encode[index],dtype=np.float16),"rank_vector":np.array(tmp[index],dtype=np.float16)} for index,tmp_id in enumerate(uuids[i*size:(i+1)*size])]
        # update_res = ESServices.update_record(es_index, vertor_es, "uuid")
        # if not update_res:
        #     logger.info(
        #         f"faq bot_id: {bot_id}, base_code: {base_code}, sync_type: {sync_type} ,page {i}write es vertor record failed")
        #     return False
    return True

def change_sync_result(sync_type):
    sync_res = sync_type
    if sync_type == SyncType.SYNC.value:
        sync_res = SyncType.SYNC_FAILED.value
    elif sync_type == SyncType.PUBLISH.value:
        sync_res = SyncType.PUBLISH_FAILED.value
    elif sync_type == SyncType.OFFSHELF.value:
        sync_res = SyncType.OFFSHELF_FAILED.value
    return sync_res

@app.task(bind=True, ignore_result=False, base=SyncTask, max_retries=3, default_retry_delay=1 * 6)
@logger_begin_end
def sync_milvus_data(self, meta_data, bot_id, base_code, sync_type, knowledge_type, language="zh", trace_id=None):
    """
    矢量构建异步任务
    :param meta_data:
    :param bot_id:
    :param base_code:
    :param sync_type:
    :param knowledge_type:
    :param language:
    :param trace_id:
    :return:
    """
    try:
        last_task_result = meta_data.get("success")
        sync_meta_data = meta_data.get("data")
        ids = sync_meta_data.get("ids")
        faq_knowledge_ids = sync_meta_data.get("stand_faq_ids", [])
        if not last_task_result:
            sync_res = change_sync_result(sync_type)
            return {"success": last_task_result, "data":{"sync_res":sync_res, "ids":ids, "stand_faq_ids":faq_knowledge_ids}}
        if knowledge_type == "faq":
            handle_res = handle_faq_data(sync_meta_data, bot_id, base_code, sync_type, language, trace_id)
        else:
            if sync_meta_data.get("sync_result") is None or sync_meta_data.get("sync_result").get("sync_time") is None or not sync_meta_data.get("ids"):
                logger.info(f"es sync data is 0")
                # sync_res = change_sync_result(sync_type)
                return {"success": True, "data":{"sync_res": sync_type, "ids":ids, "stand_faq_ids":faq_knowledge_ids}}
            handle_res = handle_mrc_data(sync_meta_data, bot_id, base_code, sync_type, language, trace_id)
        if handle_res:
            sync_res = sync_type
        else:
            sync_res = change_sync_result(sync_type)
            logger.info(f"bot_id {bot_id},base_code {base_code}, milvus task failed")
    except Exception as exc:
        raise sync_milvus_data.retry(exc=exc, countdown=60)
    return {"success": handle_res, "data":{"sync_res":sync_res, "ids":ids, "stand_faq_ids":faq_knowledge_ids},"msg":f"sync milvus data {handle_res}"}

@app.task(bind=True, ignore_result=False, base=SyncTask, max_retries=3, default_retry_delay=1 * 6)
@logger_begin_end
def test_milvus(self,count=10):
    import time

    for i in range(count):
        # milvus_config = config.get("MILVUS")
        # milvus_client = Milvus(milvus_config['MILVUS_URL'], milvus_config['MILVUS_PORT'], pool_size=1)
        print(f"====version {app.milvus_client.server_version()}")
        #logger.info(f"init milvus {app.milvus_client.list_partitions('mrc_sentence_rank_test')}")
        #with Milvus(milvus_config['MILVUS_URL'], milvus_config['MILVUS_PORT']) as milvus_client:
        MilvusHandler.check_partition(app.milvus_client,'mrc_sentence_rank_test', '298')
        # milvus_client.close()
        # try:
        #     res = app.milvus_client.has_partition('mrc_sentence_rank_test', '298')
        #     logger.info(f"count {i} {res}")
        # except Exception as e:
        #     res = app.milvus_client.has_partition('mrc_sentence_rank_test', '298')
        #     logger.info(f"except count {i} {res}")
        # logger.info(f"init milvus {app.milvus_client.has_partition('mrc_sentence_rank_test', '298')}")
        # time.sleep(1)