# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-23
    FileName   : meta_task.py
    Author     : Honghe
    Descreption: 
"""
import time
import math

from src.celery_task.app import app
from src.common.logger import logger
from src.services.mysql_services import MysqlServices
from src.models.mrc_sentences import MrcSentences
from src.models.mrc_sentences import SyncType
from src.celery_task.task.base_task import SyncTask
from src.common.utils import logger_begin_end, hash_milvus_id

def change_faq_data(query_result, bot_id, faq_knowledge_ids, query_status):
    faq_datas = []
    for data in query_result.get("datas"):
        stand_data = data.get("faqCO")
        similar_record = {
                "id": str(data.get("id")),
                "base_code": str(data.get("libraryId")),
                "query": data.get("title"),  # mrc是标题，faq是问题
                # "answer": stand_data.get("contentBody"),  # MRC是文档URL，FAQ是答案ID
                "answer":"",
                "status": data.get("publishStatus"),  # 0表示新增，1表示删除，2表示修改
                "language": stand_data.get("lang"),  # 语种
                "catalogs": [stand_data.get("cateName")] if stand_data.get("cateName") is not None else [],  # 场景分类
                "keywords": stand_data.get("keywords",[]),  # 关键词
                "labels": stand_data.get("keywords") if stand_data.get("keywords") is not None else [],
                "channel_id": bot_id,
                "is_hot": stand_data.get("isHot"),
                "is_delete": data.get("publishStatus") == SyncType.OFFSHELFING.value or query_status==SyncType.DELETE.value,
                "gmt_modified": data.get("gmtModified"),
                'is_standard': False,
                "answer_id": str(stand_data.get("contentBodyId")),
                "knowledge_code": stand_data.get("contentCode")
            }
        faq_datas.append(similar_record)
        # 判断标准问是否需要添加
        if (query_status==stand_data.get("publishStatus") or query_status==SyncType.DELETE.value) and stand_data.get("id") not in faq_knowledge_ids:
            faq_knowledge_ids.append(stand_data.get("id"))
            stand_record = {
                "id": str(stand_data.get("id")),
                "base_code": str(stand_data.get("libraryId")),
                "query": stand_data.get("title"),  # mrc是标题，faq是问题
                # "answer": stand_data.get("contentBody"),  # MRC是文档URL，FAQ是答案ID
                "answer": "",
                "status": stand_data.get("publishStatus"),  # 0表示新增，1表示删除，2表示修改
                "language": stand_data.get("lang"),  # 语种
                "catalogs": [stand_data.get("cateName")] if stand_data.get("cateName") is not None else [],  # 场景分类
                "keywords": stand_data.get("keywords",[]),  # 关键词
                "labels": stand_data.get("keywords") if stand_data.get("keywords") is not None else [],
                "channel_id": bot_id,
                "is_hot": stand_data.get("isHot"),
                "is_delete": stand_data.get("publishStatus") == SyncType.OFFSHELFING.value or query_status==SyncType.DELETE.value,
                "gmt_modified": stand_data.get("gmtModified"),
                'is_standard': True,
                "answer_id": str(stand_data.get("contentBodyId")),
                "knowledge_code": stand_data.get("contentCode")
            }
            faq_datas.append(stand_record)
    return faq_datas

def change_standard_faq(query_result, bot_id, faq_knowledge_ids, query_status):
    faq_datas = []
    for stand_data in query_result.get("datas"):
        if stand_data.get("id") not in faq_knowledge_ids:
            faq_knowledge_ids.append(stand_data.get("id"))
            stand_record = {
                "id": str(stand_data.get("id")),
                "base_code": str(stand_data.get("libraryId")),
                "query": stand_data.get("title"),  # mrc是标题，faq是问题
                 # "answer": stand_data.get("contentBody"),  # MRC是文档URL，FAQ是答案ID
                "answer": "",
                "status": stand_data.get("publishStatus"),  # 0表示新增，1表示删除，2表示修改
                "language": stand_data.get("lang"),  # 语种
                "catalogs": [stand_data.get("cateName")] if stand_data.get("cateName") is not None else [],  # 场景分类
                "keywords": stand_data.get("keywords", []),  # 关键词
                "labels": stand_data.get("keywords") if stand_data.get("keywords") is not None else [],
                "channel_id": bot_id,
                "is_hot": stand_data.get("isHot"),
                "is_delete": stand_data.get(
                    "publishStatus") == SyncType.OFFSHELFING.value or query_status == SyncType.DELETE.value,
                "gmt_modified": stand_data.get("gmtModified"),
                'is_standard': True,
                "answer_id": str(stand_data.get("contentBodyId")),
                "knowledge_code": stand_data.get("contentCode")
            }
            faq_datas.append(stand_record)
    return faq_datas


def get_standard_faq(params,bot_id, faq_knowledge_ids,query_status,limit=100, env="online"):
    standard_faq = MysqlServices.query_faq_data(params, env=env)
    if standard_faq is None:
        return [], []
    total = standard_faq.get("totalCount")
    if total is None:
        logger.info(f"get standard faq sync data failed")
        return None, None
    page = math.ceil(total / limit)
    total_result = []
    ids = []
    for i in range(page):
        params["offset"] = i * limit
        query_result = MysqlServices.query_faq_data(params, env=env)
        logger.info(f"get standard faq {query_result}")
        tmp_record = change_standard_faq(query_result, bot_id, faq_knowledge_ids, query_status)
        tmp_ids = [data.get("id") for data in query_result.get("datas")]
        total_result += tmp_record
        ids += tmp_ids
    return total_result, ids


@app.task(bind=True, ignore_result=False, base=SyncTask, max_retries=3, default_retry_delay=1 * 6)
@logger_begin_end
def get_sync_data(self, bot_id, base_code, base_type, sync_type, tenantId="", language="zh",trace_id=None, offset=0, limit=100, env="online"):
    """
    获取待同步数据
    :param bot_id: 机器人ID
    :param base_code: 知识库ID
    :param base_type: 知识库类型
    :param sync_type:
    :param trace_id:
    :return:
    """
    try:
        if sync_type==SyncType.SYNC.value:
            query_status = SyncType.SYNCING.value
        elif sync_type==SyncType.PUBLISH.value:
            query_status = SyncType.PUBLISHING.value
        elif sync_type == SyncType.DELETE.value:
            query_status = SyncType.DELETE.value
        elif sync_type == SyncType.OFFSHELF.value:
            query_status = SyncType.OFFSHELFING.value
        else:
            logger.info(f"sync type is illegal {sync_type}")
            return {"success":False}

        params = {
            "libraryId": base_code,
            "publishStatus":None if query_status == SyncType.DELETE.value else query_status,
            "lang":language,
            "tenantId": tenantId,
            "withSimilarQuestion":True,
            "withContentBody":True,
            "isDeleted": True if query_status == SyncType.DELETE.value else False
        }
        if base_type.upper()=="FAQ":
            params["withFaq"] = True
            params["withContentBody"] = False
            params["publishStatusList"] = [] if query_status == SyncType.DELETE.value else [query_status]
            params["withTagName"] = True
            params["withCateName"] = True

        params["offset"] = offset
        params["limit"] = limit
        query_result = MysqlServices.query_sync_data(params, base_type, env=env)
        if query_result is None:
            logger.info(f"get sync data succeed, base_code:{base_code}, sync_type:{base_type},count is 0")
            return {"success":True, "data":{"total_record":[], "ids":[]}, "msg":"mysql get knowledge succeed"}
        total = query_result.get("totalCount")
        if total is None:
            logger.info(f"get sync data failed, base_code:{base_code}, sync_type:{base_type}")
            return {"success":False, "msg":f"get sync data failed, base_code:{base_code}, sync_type:{base_type}"}
        page = math.ceil(total / limit)
        total_result = []
        ids = []
        repeat_ids = []
        faq_knowledge_ids = []
        # total_result.append(query_result)
        for i in range(page):
            params["offset"] = i*limit
            query_result = MysqlServices.query_sync_data(params, base_type, env=env)
            logger.info(f"get meta_record {query_result}")
            if query_result.get("totalCount") is None:
                logger.info(f"get sync data failed, base_code:{base_code}, sync_type:{base_type}")
                return {"success":False, "msg":f"get sync data failed, base_code:{base_code}, sync_type:{base_type}"}
            if base_type.upper()!="FAQ":
                tmp_record = [
                    {
                        "id": str(data.get("id")),
                        "base_code": str(data.get("libraryId")),
                        "title": data.get("title"),  # mrc是标题，faq是问题
                        "content": data.get("contentBodyId") if base_type=="mrc" and len(data.get("contentBodyId"))>0 is not None else data.get("contentBody"),  # MRC是文档URL，FAQ是答案ID
                        "status": data.get("publishStatus"),  # 0表示新增，1表示删除，2表示修改
                        "similar_query": data.get("similarQuestions"),  # 相似问
                        "language": data.get("lang"),  # 语种
                        "catalogs": data.get("sceneIdList"),  # 场景分类
                        "keywords": data.get("keywords"),  # 关键词
                        "labels": data.get("tagList"),
                        "channel_id": bot_id,
                        "is_hot": data.get("isHot"),
                        "is_delete": data.get("publishStatus")==SyncType.OFFSHELFING.value,
                        "gmt_modified": data.get("gmtModified")
                    } for data in query_result.get("datas")
                ]
            else:
                tmp_record = change_faq_data(query_result, bot_id, faq_knowledge_ids, query_status)
            tmp_ids = [data.get("id") for data in query_result.get("datas")]
            for id in tmp_ids:
                if id in ids:
                    repeat_ids.append(id)
            total_result += tmp_record
            ids += tmp_ids
        if base_type.upper()=="FAQ":
            standard_result, standard_ids = get_standard_faq(params,bot_id, faq_knowledge_ids,query_status,env=env)
            if standard_result is None:
                return {"success": False, "msg": f"get faq standard sync data failed, base_code:{base_code}, sync_type:{base_type}"}
            total_result += standard_result
            if faq_knowledge_ids:
                ids+=faq_knowledge_ids
        logger.info(f"get sync data succeed, base_code:{base_code}, sync_type:{base_type}")
        logger.info(f"get sync data count {len(ids)}, repeat id {len(repeat_ids)}, {repeat_ids}, real record count {len(list(set(ids)))}")
    except Exception as exc:
        raise get_sync_data.retry(exc=exc, countdown=60)
    return {"success":True, "data":{"total_record":total_result, "ids":ids, "stand_faq_ids":faq_knowledge_ids}, "msg":"mysql get knowledge succeed"}

@app.task(bind=True, ignore_result=False, base=SyncTask, max_retries=3, default_retry_delay=1 * 6)
@logger_begin_end
def modify_sync_data(self, sync_res, base_code, bot_id, knowledge_type, tenantId="",lang="zh",page_size=1000,task_id=None, env="online"):
    """
    在同步逻辑走完后，修改知识库远端数据，知识库只支持传ID修改，需要分页
    :param knowledge_ids:
    :param sync_type:
    :param bot_id:
    :param page_size:
    :return:
    """
    try:
        milvus_data = sync_res.get("data")
        sync_type = milvus_data.get("sync_res")
        knowledge_res = sync_res.get("success")
        knowledge_ids = milvus_data.get("ids")
        stand_faq_ids = milvus_data.get("stand_faq_ids",[])
        if knowledge_ids is None or not knowledge_ids:
            # logger.info(
            #     f"bot_id:{bot_id}, sync_type:{sync_type}  knowledge ids is none")
            # return {"success":False,"msg":f"bot_id:{bot_id}, sync_type:{sync_type} modify knowledge library status failed"}
            knowledge_ids = []
        modify_library_res = MysqlServices.modify_sync_library(sync_type, bot_id, base_code,knowledge_type,knowledge_res,knowledge_ids,stand_faq_ids,lang,tenantId=tenantId, env=env)

        if not modify_library_res:
            logger.info(
                f"bot_id:{bot_id}, sync_type:{sync_type} modify knowledge library status failed")
            return {"success": False,
                    "msg": f"bot_id:{bot_id}, sync_type:{sync_type} modify knowledge library status failed"}
        if knowledge_ids is None or not knowledge_ids:
            return {"success":True,"msg":f"bot_id:{bot_id}, sync_type:{sync_type} modify knowledge library status succeed knowledge num is 0"}
        # pages = math.ceil(len(knowledge_ids) / page_size)
        # logger.info(f"bot_id:{bot_id}, sync_type:{sync_type} start modify knowledge status count:{len(knowledge_ids)} page:{pages}")

        # for page in range(pages):
        #     res = MysqlServices.modify_sync_data(knowledge_ids, sync_type, bot_id, base_code,knowledge_type,tenantId=tenantId,lang=lang)
        #     if not res:
        #         logger.info(f"bot_id:{bot_id}, sync_type:{sync_type} pages:{page} modify knowledge failed")
        #         return False
    except Exception as exc:
        raise modify_sync_data.retry(exc=exc, countdown=60)
    return {"success":True,"msg":f"bot_id:{bot_id}, sync_type:{sync_type} modify knowledge library status succeed knowledge num is {len(knowledge_ids)}"}


def create_mrc_meta(mrc_data, bot_id, base_code, sync_type, sync_time=None):
    """
    将MRC拆分的句子写入到MySQL里去,返回同步时间用来之后矢量索引查询
    :param mrc_data:
    :param bot_id:
    :param base_code:
    :param sync_type:
    :return:
    """
    mrc_sentence_data = []
    sync_time = int(time.time()) if sync_type is None else sync_time
    logger.info(f"create mrc data {len(mrc_data)}")
    create_result = 0
    for mrc_index, data in enumerate(mrc_data):
        sentences = data.get("sentences")
        tmp_sentence = []
        for index, sentence in enumerate(sentences):
            content = sentence.replace(" ","")

            mrc_sentnece = {
                "channel_id": bot_id,
                "base_code": base_code,
                "document_id": data.get("document_id"),
                "content_id": data.get("content_id"),
                "sentence": content,
                "status": sync_type,
                "sync_time": sync_time,
                "is_publish": data.get("is_pre"),
                "uuid":hash_milvus_id(f"{content}_{data.get('content_id')}_{index}")
            }
            mrc_sentence_data.append(mrc_sentnece)
    create_result = MrcSentences.create_instances(mrc_sentence_data, sync_time).get("insert_num",0)

    if create_result<=0 and len(mrc_data)>0:
        logger.info(
            f"bot_id:{bot_id},base_code:{base_code},sync_type:{sync_type} create mate data failed")
        return None
    logger.info(
        f"bot_id:{bot_id},base_code:{base_code},sync_type:{sync_type} create mate data succeed count:{create_result}")
    return sync_time

@app.task(bind=True, ignore_result=False, base=SyncTask, max_retries=3, default_retry_delay=1 * 6)
@logger_begin_end
def sync_meta_data(self, sync_data, bot_id, base_code, sync_type, base_type, language="zh", trace_id=None):
    """
    同步meta数据，对于FAQ来说不存在这一步，对于MRC就是把记录写入到MySQL数据库里或者修改已有数据
    :param sync_data:
    :param bot_id:
    :param base_code:
    :param sync_type:
    :param base_type:
    :param trace_id:
    :return:
    """
    if base_type == "faq" or not sync_data.get("success", False):
        return {"success": sync_data.get("success"), "data": sync_data.get("data"),
                "msg": f"faq sync meta data true count 0"}
    es_sync_data = sync_data.get("data")
    # 需要同步数据为空
    if sync_type != SyncType.DELETE.value and not es_sync_data.get("es_record") and not es_sync_data.get("deleted_ids"):
        logger.info(f"bot_id: {bot_id}, base_code: {base_code}, sync_type: {sync_type} es data count 0")
        return {"success": True, "data": {"ids": []},
                "msg": f"sync meta data true count 0"}

    with app.db.atomic() as transaction:
        try:
            deleted_sentence_ids = []
            sync_time = int(time.time()*100)
            # 删除时，先逻辑删除，然后再矢量删除后再来删除
            if sync_type == SyncType.DELETE.value:
                update_Res = MrcSentences.update({"status":sync_type,"sync_time":sync_time,"is_deleted":1}).where((MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code)).execute()
                logger.info(f"bot_id:{bot_id}, base_code{base_code} delete succeed,count {update_Res}")
                # return {"success": True, "sync_result": None}
            elif sync_type == SyncType.SYNC.value:
                deleted_ids = es_sync_data.get("deleted_ids")
                # 同步时，先逻辑删除
                if deleted_ids:
                    sentence_ids = MrcSentences.select(MrcSentences.id).where((MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code) & (
                            MrcSentences.document_id.in_(deleted_ids))& (MrcSentences.status==sync_type))
                    deleted_sentence_ids = [sentence.id for sentence in sentence_ids]
                    update_res = MrcSentences.update({"sync_time":sync_time,"is_deleted":1}).where((MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code) & (
                            MrcSentences.document_id.in_(deleted_ids))& (MrcSentences.status==sync_type)).execute()
                meta_data = es_sync_data.get("es_record")
                sync_time = create_mrc_meta(meta_data, bot_id, base_code, sync_type,sync_time)
            elif sync_type == SyncType.OFFSHELF.value:
                deleted_ids = es_sync_data.get("deleted_ids")
                if deleted_ids:
                    sentence_ids = MrcSentences.select(MrcSentences.id).where(
                        (MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code) & (
                                MrcSentences.document_id.in_(deleted_ids)))
                    deleted_sentence_ids = [sentence.id for sentence in sentence_ids]
                    delete_res = MrcSentences.update({"status":sync_type,"sync_time":sync_time,"is_deleted":1}).where(
                        (MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code) & (
                                MrcSentences.document_id.in_(deleted_ids))).execute()
            else:
                deleted_ids = es_sync_data.get("deleted_ids")
                if deleted_ids:
                    #
                    is_deleted = 1 if sync_type == SyncType.PUBLISH.value else 0
                    sentence_ids = MrcSentences.select(MrcSentences.id).where(
                        (MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code) & (
                            MrcSentences.document_id.in_(deleted_ids) & (MrcSentences.status==sync_type)))
                    deleted_sentence_ids = [sentence.id for sentence in sentence_ids]
                    delete_res = MrcSentences.update({"sync_time":sync_time,"is_deleted":1}).where(
                        (MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code) & (
                            MrcSentences.document_id.in_(deleted_ids) & (MrcSentences.status==sync_type))).execute()
                # 下架的逻辑不需要进行状态更新
                if sync_type == SyncType.PUBLISH.value:
                    # update_res = MrcSentences.update({"status":sync_type,"sync_time":sync_time}).where(
                    #     (MrcSentences.channel_id == bot_id) & (MrcSentences.base_code == base_code) & (
                    #             MrcSentences.status == SyncType.SYNC.value)).execute()

                    meta_data = es_sync_data.get("es_record")
                    sync_time = create_mrc_meta(meta_data, bot_id, base_code, sync_type,sync_time)
            logger.info(f"bot_id:{bot_id}, base_code{base_code},sync_type {sync_type},  succeed")
            sync_result = {"sync_time": sync_time, "deleted_sentence_ids": deleted_sentence_ids}
            result_flag = False if sync_time is None else True
            return {"success": result_flag, "data":{"sync_result": sync_result, "ids":es_sync_data.get("ids")},"msg":f"meta task result {result_flag}"}
        except Exception as e:
            logger.info(f"bot_id:{bot_id}, base_code{base_code},sync_type {sync_type}, meta task failed")
            logger.exception(e)
            transaction.rollback()
            raise sync_meta_data.retry(exc=e, countdown=60)
    return {"success": False, "msg":f"bot_id:{bot_id}, base_code{base_code},sync_type {sync_type}, meta task failed","data":{"ids":es_sync_data.get("ids")}}



