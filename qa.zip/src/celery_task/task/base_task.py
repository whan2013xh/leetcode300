# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-08-06
    FileName   : utils.py
    Author     : Honghe
    Descreption: 
"""
import time

import celery

from src.common.logger import logger
from src.models import db
from src.models.async_task import AsyncTask
from src.common.utils import connect_db, close_db, WeChatHandler

class SyncTask(celery.Task):
    @staticmethod
    def change_ats(async_task_id, status, msg):
        """
        改变异步任务状态
        """
        connect_db(db)
        with db.atomic():
            update_data = {"status": status, "error_message": msg, "gmt_modified": int(time.time() * 1000)}
            AsyncTask.update(update_data).where(AsyncTask.id == async_task_id).execute()
        close_db(db)

    def after_return(self, status, retval, task_id, args, kwargs, einfo):
        logger.info(f"task execute after: name={ self.__qualname__ }, async_id={ task_id }, args={ args }")
        ## 获取返回结果信息
        logger.info(retval)
        if isinstance(retval,dict):

            flag, msg = (retval.get("success"), retval)
        else:
            flag = False
            msg = retval
        wc_handler = WeChatHandler("honghe.xu@tuya.com", self.__qualname__)
        # # 发送微信通知
        response = wc_handler.send(flag, msg)
        ## 回写数据库
        async_task_id = kwargs.get("task_id")
        if async_task_id is not None:
            SyncTask.change_ats(async_task_id, status, msg)
        if not flag:
            return {"success": False, "data": {}, "msg": f"{self.__qualname__} failed"}, None
        return True, None


    def on_success(self, retval, task_id, args, kwargs):
        logger.info(f"task execute success: name={self.__qualname__}, async_id={task_id}, args={args}")

        # 组织数据
        if retval is not None:
            status, error_message = "FAILURE", str(retval)
        else:
            status, error_message = "SUCCESS", ""
        update_data = {"status": status, "error_message": error_message[0:250]}
        # 回写任务状态
        return super().on_success(retval, task_id, args, kwargs)

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        logger.info(f"task execute failure: name={self.__qualname__}, async_id={task_id}, args={args}")

        # 组织数据
        status, error_message = "FAILURE", str(exc)
        update_data = {"status": status, "error_message": error_message[0:250]}
        # 回写任务状态
        super().on_failure(exc, task_id, args, kwargs, einfo)

        return {"success":False, "data":{}, "msg":f"{self.__qualname__} failed"}