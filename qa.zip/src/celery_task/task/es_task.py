# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-23
    FileName   : es_task.py
    Author     : Honghe
    Descreption: 
"""
import time

from src.celery_task.app import app
from src.celery_task.task.base_task import SyncTask
from src.common import config
from src.common import logger
from src.common.md_parser import MdParser
from src.common.parser import DocParser
from src.services.es_services import ESServices
from src.models.mrc_sentences import SyncType
from src.common.fileio import URLFile
from src.common.utils import logger_begin_end


def parser_mrc_doc(doc_data, bot_id=None, is_pre=0):
    md_parser = MdParser()
    doc_parser = DocParser(config)
    if doc_data.get("content") is None:
        logger.error(f"{doc_data} url is None")
        return []
    content = get_file_content(doc_data.get("content"))
    if content is None:
        return []
    # content = doc_data.get("content")
    json_content, _ = md_parser.parse(content)
    records = doc_parser.build_mrc_record(json_content, doc_data, bot_id=bot_id, is_pre=is_pre)
    return records

def get_file_content(file_url):
    if not file_url.startswith("http"):
        return file_url
    file = URLFile.get_web_file(file_url)
    if file.status_code!=200:
        logger.error(f"{file_url} get file content failed")
        return None
    return file.text

def parser_mrc_result(es_records, add_flag):
    """
    转换es索引记录传递到后面的meta异步任务处理，尽量只要必要的信息
    :param es_records:
    :param add_flag:
    :return:
    """
    if add_flag:
        mrc_result = [{"document_id": record.get("document_id"), "content_id": record.get("uuid"),
                       "sentences": record.get("sentences"),"is_pre":record.get("is_pre")} for record in es_records]
        return mrc_result
    return []

def parser_faq_result(es_records):
    # faq_result = ({"id":record.get("id"), "query":record.get("title"), "is_deleted":record.get("is_deleted",0)} for record in es_records)
    # faq_result = ({"id": record.get("query_id"), "query": record.get("query"), "is_deleted": record.get("is_deleted", 0)} for
    #               record in es_records)
    faq_result = [
    {"id": record.get("query_id"), "query": record.get("norm_text"), "is_deleted": record.get("is_deleted", False),"uuid":record.get("uuid")} for
    record in es_records]
    return faq_result


def handle_mrc_doc(doc_data, sync_type=None, bot_id=None, base_code=None, language="zh", trace_id=None):
    """
    将句子组装成需要建立的ES索引数据
    1、将文档装换成句子
    2、处理ES逻辑,添加ES索引
    3、es记录转meta记录
    :param is_pre:
    :param sync_type:
    :param bot_id:
    :param base_code:
    :return:
    """
    es_index = language + "_mrc"
    if sync_type == SyncType.DELETE.value:
        delete_res = ESServices.delete_record(es_index, {"bot_id": bot_id, "base_code": base_code}, app.es_client)
        return delete_res, None, None


    mrc_records = []
    is_pre = 0 if sync_type == SyncType.SYNC.value else 1
    deleted_document_ids = []
    for data in doc_data:
        document_id = data.get("id")
        # 删除原有的记录，因为对于mrc来说每次修改可能对所有索引都有影响
        # logger.info(f"offset data  {data}")
        deleted_document_ids.append(document_id)
        if data.get("is_delete"):
            # logger.info(f"offset data  {data}")
            res = ESServices.delete_record(es_index, {"bot_id": bot_id, "document_id": document_id},
                                           app.es_client)
            continue
        else:
            res = ESServices.delete_record(es_index, {"bot_id": bot_id, "document_id": document_id, "is_pre": is_pre}, app.es_client)
        # 删除的文档不用做解析
        # 所有文档都要先删除

        # 下架的文档不管

        if res:
            es_records = parser_mrc_doc(data, bot_id=bot_id, is_pre=is_pre)
            add_result = ESServices.add_record(es_index, es_records, "uuid")

            if not add_result:
                logger.info(
                    f"mrc bot_id: {bot_id}, base_code: {base_code}, sync_type: {sync_type}, document:{document_id} write es record failed")
                return False, None, None

            meta_record = parser_mrc_result(es_records, add_result)
            mrc_records.extend(meta_record)
        else:
            logger.info(f"mrc delete bot_id: {bot_id}, base_code: {base_code}, document: {document_id} delete failed")
            return False, None, None
    logger.info(
        f"bot_id: {bot_id}, base_code: {base_code}, sync_type: {sync_type}, count {len(doc_data)} write es record succeed")
    return True, mrc_records, deleted_document_ids

def split_faq_data(faq_data, is_pre):
    deleted_faq_ids = []
    other_faq_data = []
    for data in faq_data:
        if data.get("is_delete"):
            insert_char = '1' if data.get("is_standard") else '0'
            query_id = data.get("id")+insert_char+str(is_pre)
            deleted_faq_ids.append(query_id)
        else:
            other_faq_data.append(data)
    return deleted_faq_ids, other_faq_data

def handle_faq_record(faq_data, sync_type=None, bot_id=None, base_code=None, language="zh", trace_id=None):
    """
    处理faq数据到ES
    :param faq_data:
    :param sync_type:
    :param bot_id:
    :param base_code:
    :param language:
    :param trace_id:
    :return:
    """
    es_index = language+"_faq"
    is_pre = 0 if sync_type == SyncType.SYNC.value else 1
    deleted_faq_ids, other_faq_data = split_faq_data(faq_data, is_pre)
    if sync_type == SyncType.DELETE.value:
        delete_res = ESServices.delete_record(es_index, {"bot_id": bot_id, "base_code": base_code}, app.es_client)
        sync_deleted_ids, _ = split_faq_data(faq_data, 0)
        return delete_res, None, deleted_faq_ids+sync_deleted_ids

    if sync_type == SyncType.OFFSHELF.value:
        delete_res_publish = ESServices.delete_by_ids(es_index, deleted_faq_ids, app.es_client)
        sync_deleted_ids, _ = split_faq_data(faq_data, 0)
        delete_res_sync = ESServices.delete_by_ids(es_index, sync_deleted_ids, app.es_client)
        total_res = delete_res_publish and delete_res_sync
        total_faq_ids = deleted_faq_ids+sync_deleted_ids
        logger.info(f"offshelf data ids {total_faq_ids}")
        return total_res, None, total_faq_ids

    doc_parser = DocParser(config)

    # 删除原有的记录，因为对于mrc来说每次修改可能对所有索引都有影响
    delete_res = ESServices.delete_by_ids(es_index, deleted_faq_ids, is_pre, app.es_client)
    if not delete_res:
        logger.info(f"faq delete bot_id: {bot_id}, base_code: {base_code} delete failed")
        return False,None,None
    if not other_faq_data:
        logger.info(f"faq write record is None ")
        return True, [], deleted_faq_ids
    faq_es_records = doc_parser.build_faq_record(other_faq_data, language=language, trace_id=trace_id, base_code=base_code, bot_id=bot_id, is_pre=is_pre)
    handle_faq_es = ESServices.add_record(es_index, faq_es_records, "uuid")
    if not handle_faq_es:
        logger.info(
            f"faq bot_id: {bot_id}, base_code: {base_code}, sync_type: {sync_type}, write es record failed")
        return False,None,None
    logger.info(
        f"faq bot_id: {bot_id}, base_code: {base_code}, sync_type: {sync_type} count {len(faq_data)}, write es record succeed")
    parse_data = parser_faq_result(faq_es_records)
    return True, parse_data, deleted_faq_ids

def transfer_faq_id(faq_ids):
    res = []
    for i in faq_ids:
        tmp = int(str(i)[3:].lstrip("0"))
        res.append(tmp)
    return res

def change_sync_result(sync_type):
    sync_res = sync_type
    if sync_type == SyncType.SYNC.value:
        sync_res = SyncType.SYNC_FAILED.value
    elif sync_type == SyncType.PUBLISH.value:
        sync_res = SyncType.PUBLISH_FAILED.value
    elif sync_type == SyncType.OFFSHELF.value:
        sync_res = SyncType.OFFSHELF_FAILED.value
    return sync_res

@app.task(bind=True, ignore_result=False, base=SyncTask, max_retries=3, default_retry_delay=1 * 6)
@logger_begin_end
def sync_es_data(self, sync_data, bot_id, base_code, sync_type, knowledge_type, language="zh", trace_id=None):
    sync_res = change_sync_result(sync_type)
    try:
        if not sync_data.get("success"):
            return {"success":False, "data":{"sync_res":sync_res, "deleted_ids": [], "ids":[]},"msg": f"bot_id: {bot_id}, base_code: {base_code}, sync_type: {sync_type} get sync data failed"}
            # return sync_data
        legal_type = [name.value for name in SyncType]
        if sync_type not in legal_type:
            logger.info("sync type is illegal")

            return {"success":False, "data":{"sync_res":sync_res,"es_record": [], "deleted_ids": [], "ids":[]},"msg": f"bot_id: {bot_id}, base_code: {base_code}, sync_type: {sync_type} sync es data failed"}
        last_task_data = sync_data.get("data")
        sync_record = last_task_data.get("total_record")
        ids = last_task_data.get("ids",[])
        faq_knowledge_ids = last_task_data.get("stand_faq_ids", [])
        if not sync_record and not ids:
            logger.info(f"bot_id: {bot_id}, base_code: {base_code}, sync_type: {sync_type} mysql data count 0")
            return {"success": True, "data":{"sync_res":sync_type,"es_record": [], "deleted_ids": [], "ids":[]},"msg":f"sync es data true count 0"}
        if knowledge_type == "mrc":
            flag, es_res, deleted_ids = handle_mrc_doc(doc_data=sync_record, bot_id=bot_id, base_code=base_code, sync_type=sync_type, language=language, trace_id=trace_id)
        else:
            flag, es_res, deleted_ids = handle_faq_record(faq_data=sync_record, bot_id=bot_id, base_code=base_code, sync_type=sync_type, language=language, trace_id=trace_id)
            deleted_ids = transfer_faq_id(deleted_ids)
    except Exception as exc:
        logger.exception(exc)
        time.sleep(3)
        raise sync_es_data.retry(exc=exc, countdown=60)
    return {"success": flag, "data":{"sync_res":sync_type if flag else sync_res,"es_record": es_res, "deleted_ids": deleted_ids, "ids":ids, "stand_faq_ids":faq_knowledge_ids},"msg":f"sync es data {flag}"}


if __name__ == '__main__':
    file_path = "/Volumes/工作/部门工作/标注平台后台接口梳理.md"

    with open(file_path) as md:
        content = md.read()
    doc_data = {"content": content, "title": "标注平台后台接口梳理"}
    parser_mrc_doc(doc_data)
    print("")
