# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-21
    FileName   : __init__.py.py
    Author     : Honghe
    Descreption: 
"""
from src.celery_task.task.es_task import sync_es_data
from src.celery_task.task.meta_task import get_sync_data, sync_meta_data, modify_sync_data
from src.celery_task.task.milvus_task import sync_milvus_data, test_milvus