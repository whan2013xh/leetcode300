# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-21
    FileName   : config.py
    Author     : Honghe
    Descreption: 
"""
from kombu import Exchange, Queue

from src.common import config


class Config(object):
    ## 基础设置
    timezone = "Asia/Shanghai"
    broker_url = config["CELERY"]["BROKER_URL"]
    result_backend = config["CELERY"]["BACKEND_URL"]
    ## 状态相关
    # 该配置设置为 True 时，才会出现 STARTED 状态
    task_track_started = True
    ## include
    include = [
        "src.celery_task.task"
    ]

    ## 并发、内存相关设置
    # 每个worker最大执行任务数，当worker执行任务数达到最大后会自动销毁重建（释放内存资源）
    worker_max_tasks_per_child = 1
    worker_concurrency = 2
    # worker_max_tasks_per_child = 100
    # # celery worker并发数，通常不用设置，默认和系统核数一致
    #worker_prefetch_multiplier = 4
    task_time_limit = 48 * 60 * 60
    # redis_retry_on_timeout = 5
    # broker_transport_options = {
    #     'retry_policy': {
    #         'timeout': 5.0
    #     }
    # }
    # result_backend_transport_options = {
    #     'retry_policy': {
    #         'timeout': 5.0
    #     }
    # }

    ## 队列配置
    task_queues = (
        Queue(name="es_task", exchange=Exchange("es_task"), routing_key="es_task"),
        Queue(name="meta_task", exchange=Exchange("meta_task"), routing_key="meta_task"),
        Queue(name="milvus_task", exchange=Exchange("milvus_task"), routing_key="milvus_task")
    )
    task_routes = {
        'src.celery_task.task.es_task.*': 'es_task',
        'src.celery_task.task.meta_task.*': 'meta_task',
        'src.celery_task.task.milvus_task.*': 'milvus_task',
    }