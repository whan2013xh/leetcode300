# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-21
    FileName   : __init__.py.py
    Author     : Honghe
    Descreption: 
"""
# 绝对导入，以免celery和标准库中的celery模块冲突
from __future__ import absolute_import
from celery.backends.redis import RedisBackend

from .app import app as celery_app
from .app import celery_control
from .config import Config
from .task import sync_es_data,get_sync_data, sync_meta_data, modify_sync_data,sync_milvus_data

celery_backend = RedisBackend(host=Config.result_backend, app=celery_app)

__all__ = [
    "celery_app",
    "celery_control",
    "celery_backend",
    "sync_es_data",
    "get_sync_data",
    "sync_meta_data",
    "modify_sync_data",
    "sync_milvus_data"
]