# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-21
    FileName   : app.py
    Author     : Honghe
    Descreption: 
"""
from __future__ import absolute_import, unicode_literals
import os
from celery import Celery, platforms
from celery.app.control import Control
from http.server import HTTPServer, BaseHTTPRequestHandler
import json

from sanic import Sanic
from sanic.response import json

from src.celery_task.config import Config
from src.common import config
from src.models import db, milvus_client, es_client

# 解决不能用root用户启动问题
platforms.C_FORCE_ROOT = True
# 初始化 celery
app = Celery("sync_tasks")
# 添加配置
app.config_from_object(Config)

# 将数据库引擎加入异步应用
# 初始化mysqldb
# app.milvus_client = milvus_client(config)
app.milvus_client = None
# 初始化mongodb
app.es_client = es_client
app.db = db
# 将配置数据加入异步应用
# app.sync_config = config
celery_control = Control(app)

# res = app.milvus_client.has_partition("zh_faq_rank_test", "261")

# # print(milvus_client.connect())
# # print(milvus_client.connected())
# print(f"init milvus {milvus_client.list_partitions('mrc_sentence_rank_test')}")
# print(f"init test {milvus_client.get_collection_info('mrc_sentence_rank_test')}")


data = {'result': 'this is a qa-celery'}
host = ('localhost', 8888)

class Resquest(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())


web_app = Sanic("App Name")

@web_app.route("/")
async def test(request):
    return json({"success": "true"})

if os.getenv("CELERY") is not None:
    web_app.run(host="0.0.0.0", port=8888)

