# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-08-03
    FileName   : es_services.py
    Author     : Honghe
    Descreption: 
"""
from elasticsearch import helpers
from elasticsearch_dsl import Search, Q

from src.common.logger import logger
from src.services import es_models
from src.models import es_client
from src.common.utils import function_execute_time

# from src.models import es_models

class ESServices:
    def __init__(self):
        # self.es_client = app.es_client
        pass

    @staticmethod
    @function_execute_time
    def delete_record(es_index, params, es_client=es_client):
        """
        删除es记录，可以设置删除条件和对应的索引
        :param es_index: 指定需要进行删除操作的索引库
        :param params: 删除条件
        :return:
        """
        es_model = es_models.get(es_index)
        if es_model is None:
            logger.info(f"{es_index} does not exist!")
            return False
        # record = Search(using=app.es_client, index=es_model.Index().name).query("match", **params).execute()
        # record.delete()
        query_body = {"query": {"bool": {"must": [{"term": {key: value}} for key, value in params.items()]}}}
        res = es_client.delete_by_query(index=es_model.Index().name, body=query_body)
        if not res:
            logger.info(f"{es_index} delete record failed!")
            return False
        logger.info(f"{es_index} delete record succeed! condition is {query_body}")
        return True

    @staticmethod
    @function_execute_time
    def delete_by_ids(es_index, ids, is_pre, es_client=es_client):
        es_model = es_models.get(es_index)
        if es_model is None:
            logger.info(f"{es_index} does not exist!")
            return False
        # record = Search(using=app.es_client, index=es_model.Index().name).query("match", **params).execute()
        # record.delete()
        query_body = {"query": {"bool": {"must": {"ids": {"values":ids}}}}}
        res = es_client.delete_by_query(index=es_model.Index().name, body=query_body)
        if not res:
            logger.info(f"{es_index} delete record failed!")
            return False
        logger.info(f"{es_index} delete record succeed! condition is {query_body}")
        return True

    @staticmethod
    @function_execute_time
    def query_record(es_index, params):
        es_model = es_models.get(es_index)
        if es_model is None:
            logger.info(f"{es_index} does not exist!")
            return False
        #
        es_search = Search(using=es_client, index=es_model.Index().name).source("uuid")
        for key, value in params.items():
            q_condition = Q("multi_match", query=value, fields=[key])
            es_search = es_search.query(q_condition)
        response = es_search.execute()
        return

    @staticmethod
    @function_execute_time
    def add_record(es_index, records, unique_field):
        """
        添加es记录，支持批量插入和更新
        helpers.bulk默认_id对应的文档存在es就更新，不存在就插入
        不存在就插入，存在就跳过怎么办？此时就需要在文档里面添加_op_type指定操作类型为create
        :param es_index:
        :param records:
        :return:
        """
        es_model = es_models.get(es_index)
        if es_model is None:
            logger.info(f"{es_index} does not exist!")
            return False
        logger.info(f"{es_index} add {len(records)} records start")
        # logger.info(f"es records {records}")
        # 使用生成器节省内存
        es_records = ({"_index": es_index, "_source": record, "_id": record.get(unique_field)} for record in records)
        success_nums, failed_nums = helpers.bulk(es_client, es_records)
        logger.info(f"{es_index} add {len(records)} records success_nums:{success_nums} failed_nums:{len(failed_nums)}")
        return success_nums == len(records)

    @staticmethod
    @function_execute_time
    def update_record(es_index, records, unique_field):
        es_model = es_models.get(es_index)
        # body = {
        #     "query": {
        #         "term": {
        #             "uuid": str(uuids[0])
        #         }
        #     }
        # }
        # # 查询name="python"的所有数据
        # res = es_client.search(index=es_index, body=body)
        # logger.info(f"search es {res},params {body}")
        if es_model is None:
            logger.info(f"{es_index} does not exist!")
            return False
        logger.info(f"{es_index} update {len(records)} records start")
        # logger.info(f"es records {records}")
        es_records = ({'_op_type': 'update', "_index": es_index, "_id": str( record.get(unique_field)), "doc":record} for index,record in enumerate(records))
        success_nums, failed_nums = helpers.bulk(es_client, es_records)
        logger.info(f"{es_index} update {len(records)} records success_nums:{success_nums} failed_nums:{len(failed_nums)}")
        return success_nums == len(records)
