# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-08-24
    FileName   : milvus_services.py
    Author     : Honghe
    Descreption: 
"""
import time

import requests

from src.common.config import config
from src.common.logger import logger

class MilvusServices:
    @staticmethod
    def handle_vec_data(params, bot_id="237", sync_type=1, target="mrc_rank"):
        url = config.get("BASE_VEC_URL") if sync_type==1 else config.get("ONLINE_VEC_URL")
        # bot_id = "237"
        vec_params = {
            "isSingle": True,
            "origin": config.get("ORIGIN"),
            "target": target,
            "ownerCode": str(bot_id),
            "data":params
        }
        faq_vec = MilvusServices.vec_request(url, vec_params)
        # logger.info(f"vector result {faq_vec}")

        if faq_vec.get("code"):
            logger.info(f"{url} get vec data failed.")
            return None
        if faq_vec.get("data") is None:
            logger.info(f"{url} get vec data is None.")
            return None

        return faq_vec.get("data").get("result")

    @staticmethod
    def handle_faq_encode(querys, language="zh", trace_id=None):
        url = config.get("FAQ_ENCODE_URL")
        params = {
            "trace_id":trace_id,
            "querys": querys,
            "language": language
        }
        faq_vec = MilvusServices.vec_request(url, params)
        # logger.info(f"encode vector result {faq_vec}")
        if not faq_vec.get("success"):
            logger.info(f"{url} {trace_id} get encode vec data failed.")
            return None
        return faq_vec.get("query_vec_list")


    @staticmethod
    def vec_request(url, params, retry_times=3):
        headers = {
            "authorization": f"Bearer {config.get('TOKEN')}"
        }
        start = time.time()
        response = {}
        for i in range(retry_times):
            response = requests.post(url, json=params, headers=headers)
            if response.status_code!=200:
                logger.info(f"{url} response: failed {response}")
                if i !=retry_times-1:
                    continue
                else:
                    return {}
            logger.info(f"{url} response: {round((time.time() - start) * 1000, 2)}ms")
            break
        return response.json()
