# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-21
    FileName   : __init__.py.py
    Author     : Honghe
    Descreption: 
"""
from src.models.en_faq_es_model import EnFaqDoc
from src.models.zh_faq_es_model import ZhFaqDoc
from src.models.mrc_es_model import MrcDoc

def init_es_models():
    for key, model in es_models.items():
        model.init()

es_models = {
    "zh_mrc": MrcDoc,
    "zh_faq": ZhFaqDoc,
    "en_faq": EnFaqDoc
}

init_es_models()