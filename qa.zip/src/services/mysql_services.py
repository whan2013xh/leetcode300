# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-08-23
    FileName   : mysql_services.py
    Author     : Honghe
    Descreption: 
"""
import requests

from src.common.config import config
from src.common.logger import logger
from src.models.mrc_sentences import MrcSentences, SyncType

class MysqlServices:

    @staticmethod
    def query_sync_data(params, knowledge_type, env="online"):
        knowledge = knowledge_type.upper()+"_KNOWLEDGE_QUERY_URL"
        query_url = config.get(knowledge) if env=="online" else config.get("pre").get(knowledge)
        if 'MRC'==knowledge_type.upper():
            response = requests.get(query_url, params=params)
        else:
            response = requests.post(query_url, json=params)
        logger.info(f"query_url {query_url},params {params}, response {response}")
        query_result = response.json()
        if not query_result.get("success"):
            logger.info(f"get knowledge failed url:{query_url} params:{params}, return {query_result}")
        return query_result.get("data")

    @staticmethod
    def query_faq_data(params, env="online"):
        query_url = config.get("FAQ_QUERY_URL") if env=="online" else config.get("pre").get("FAQ_QUERY_URL")
        response = requests.post(query_url, json=params)
        query_result = response.json()
        if not query_result.get("success"):
            logger.info(f"get knowledge failed url:{query_url} params:{params}, return {query_result}")
        return query_result.get("data")

    @staticmethod
    def modify_sync_data(knowledge_ids, sync_type, bot_id, base_code, knowledge_type,tenantId="",lang="zh", env="online"):
        knowledge = knowledge_type.upper() + "_KNOWLEDGE_MODIFY_URL"
        modify_url = config.get(knowledge) if env=="online" else config.get("pre").get(knowledge)
        data = {
            "knowledgeIdList":knowledge_ids,
            "tenantId":tenantId,
            "publishStatus":sync_type,
            "libraryId":base_code,
            "lang":lang,
            "operator":"qa_service",
            "operationType":"UPDATE"
        }
        logger.info(f"bot_id:{bot_id}, sync_type:{sync_type} data:{data}， modify knowledge start")
        response = requests.post(modify_url, json=data)
        status_code = response.status_code
        if status_code!=200:
            logger.info(f"bot_id:{bot_id}, sync_type:{sync_type} modify knowledge failed")
            return False
        return True

    @staticmethod
    def modify_sync_library(sync_type, bot_id, base_code,knowledge_type,knowledge_res,knowledge_ids,stand_faq_ids,lang="zh",tenantId="", env="online"):
        library = knowledge_type.upper() + "_LIBRARY_MODIFY_URL"
        modify_url = config.get(library) if env=="online" else config.get("pre").get(library)
        operator_type = {
            SyncType.SYNC.value:"syncLibraryKnowledge",
            SyncType.SYNC_FAILED.value: "syncLibraryKnowledge",
            SyncType.PUBLISH.value:"publishLibraryKnowledge",
            SyncType.PUBLISH_FAILED.value: "publishLibraryKnowledge",
            SyncType.OFFSHELF.value:"unshelveLibraryKnowledge",
            SyncType.OFFSHELF_FAILED.value: "unshelveLibraryKnowledge",
            SyncType.DELETE.value:"deleteLibraryKnowledge"
        }
        data = {
            "tenantId": tenantId,
            "publishStatus": sync_type,
            "libraryId": base_code,
            "operator": "qa_service",
            "bizSpace": "AI_ROBOT",
            "knowledgeIds": knowledge_ids,
            "lang": lang,
            "operateType": operator_type.get(sync_type),
            "success": knowledge_res
        }
        if knowledge_type.upper()=='FAQ':
            similar_ids = list(set(knowledge_ids)-set(stand_faq_ids))
            data["similarSuccess"] = knowledge_res
            data["similarIds"] = similar_ids
            data["knowledgeIds"] = stand_faq_ids
        logger.info(f"before modify_library_res params {data}")
        response = requests.post(modify_url, json=data)
        status_code = response.status_code
        logger.info(f"modify_library_res result {status_code} {response.text}")
        if status_code != 200:
            logger.info(f"bot_id:{bot_id}, sync_type:{sync_type} modify knowledge failed")
            return False
        return True


    @staticmethod
    def get_page_params(params, init_limit=10, init_offset=0):
        """
        获取请求的分页信息及搜索表达式
        limit 默认值为 10
        offset 默认值为 0
        """
        try:
            limit = params.get("limit", [init_limit])
            offset = params.get("offset", [init_offset])
        except Exception as e:
            logger.info(e)
            return None, -1, -1
        fields = params.get("fields")
        condition = params.get("condition")
        content_ids = condition.pop("content_ids",[])
        ms = MrcSentences.simple_search(fields, condition)
        if content_ids:
            ms = ms.where(MrcSentences.content_id.in_(content_ids))
        return ms, limit, offset

