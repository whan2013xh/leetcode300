# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-07-21
    FileName   : app.py
    Author     : Honghe
    Descreption: 
"""
import os
import time

from sanic import Sanic

from src.models import db,es_client, milvus_client
from src.api.actions import actions
from src.api.data import qa_data
from src.common import config, logger
from src.common.utils import connect_db, close_db



# 初始化 app
app = Sanic(config["NAME"].capitalize())
# 更新配置
app.config.update(config)
# 注册错误处理器
# app.error_handler.add(Exception, handle_exception)
# 创建静态文件路由
# app.static(
#     "/files",
#     os.path.join(config["DATA_DIR"], config["TEMP_DIR"]),
#     stream_large_files=True
# )

# 注册蓝图
# app.blueprint(data)
app.blueprint(actions)
app.blueprint(qa_data)

# 注册服务开始监听器
@app.listener("before_server_start")
async def server_init(app, loop):
    # 初始化mysqldb
    # app.milvus_client = milvus_client(config)
    # 初始化mongodb
    app.es_client = es_client
    app.db = db


# 注册服务结束监听器
# @app.listener("after_server_stop")
# async def server_clean(app, loop):
#     # 关闭milvus
#     # app.milvus_client.close()
#     app.db.close()


# 注册请求开始中间件
@app.middleware("request")
async def request_begin(request):
    cur_time = time.time()
    # 添加 nlptcp_start_time
    request.headers["sync_start_time"] = cur_time
    # 添加 sync_time
    request.headers["sync_time"] = int(cur_time * 1000)
    # connect_db(app.db)

# 注册请求结束中间件
@app.middleware("response")
async def request_end(request, response):
    # 删除 sync_time
    request.headers.pop("sync_time", None)
    # 删除 nlptcp_start_time
    start_time = request.headers.pop("sync_start_time", None)
    # 计算 请求消耗时间
    end_time = time.time()
    if start_time is None:
        spend_time = 0
    else:
        spend_time = round((end_time - start_time) * 1000, 2)
    logger.info(f"{ response.status } { request.method } { request.path } { request.query_string } { spend_time }ms")
    # close_db(app.db)


if __name__ == "__main__":
    app.run(host=config["HOST"], port=config["PORT"], debug=config["DEBUG"],
            auto_reload=config["AUTO_RELOAD"], access_log=config["ACCESS_LOG"],
            workers=config["WORKERS"])
    logger.info("qa start")


