# 构建镜像
docker build . -f docker/celery_task -t qa_celery:v1.0

# 登陆到公司镜像仓库
docker login registry.shdocker.tuya-inc.top

# 将本地镜像打上tag
docker tag qa_celery:v1.0 registry.shdocker.tuya-inc.top/ai-platform-public/qa_celery:v1.0

# 将本地镜像tag推到公司仓库
docker push registry.shdocker.tuya-inc.top/ai-platform-public/qa_celery:v1.0
