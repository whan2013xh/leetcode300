import os, sys

cwd = os.path.abspath(os.path.dirname(__file__))
sys.path.append(cwd)
