# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-02-09
    FileName   : query_similarty.py
    Author     : Honghe
    Descreption: 计算文本相似度和精排
"""
import re
from collections import Counter

import requests
import numpy as np
from sklearn import preprocessing
from scipy import spatial
# import synonyms

from commons import logger,function_execute_time


def cal_bm25_similarity(query_info, rank_result):
    """
    bm25:相对的归一化
    :param query_info:
    :param rank_result:
    :return:
    """
    bm25_scores = [ele.get("es_score") for ele in rank_result]
    bm25_scores_arr = np.array(bm25_scores).reshape([len(bm25_scores), 1])
    # 归一化到【0，1】
    min_max_scaler = preprocessing.MinMaxScaler()
    norm_bm25_scores = min_max_scaler.fit_transform(bm25_scores_arr).reshape([len(bm25_scores)])

    norm_bm25_scores = 1.0 / (1 + np.exp(-norm_bm25_scores))
    query = query_info.get("norm_text","")
    for index,rank_item in enumerate(rank_result):
        # logger.info(f"{rank_item.get('norm_text','').strip()}")
        if rank_item.get("norm_text","").strip()==query.strip():
            logger.info(f"{index}")
            norm_bm25_scores[index] = 1
    return norm_bm25_scores


def cal_jaccard_similarity(query_info, rank_result):
    """
    jaccard:字符级
    :param query_info:
    :param rank_result:
    :return:
    """
    key = "query" if query_info.get("norm_text") is None else "norm_text"
    query_char_set = set(query_info.get(key))

    jaccard_scores = []
    for idx, rank_item in enumerate(rank_result):
        candidate_char_set = set(rank_item.get(key))
        if rank_item.get("norm_text","").strip()==query_info.get("norm_text").strip():
            jaccard_score = 1
        else:
            jaccard_score = len(query_char_set.intersection(candidate_char_set)) / len(query_char_set.union(candidate_char_set))
        jaccard_scores.append(jaccard_score)
    return jaccard_scores


def cal_cosine_similarity(query_info, rank_result):
    """
    cosine:单词级别和字符级别,字符级在英文时效果较差，尽量使用单词级别
    :param query_info:
    :param rank_result:
    :return:
    """
    key = "query" if query_info.get("keywords") is None else "keywords"
    keywords = query_info.get(key)
    vocab = set(keywords)
    es_keywords = []
    for rank_item in rank_result:
        rank_keywords =set(rank_item.get(key)) if query_info.get("keywords") is None else set(rank_item.get(key).split())
        es_keywords.append(rank_keywords)
        vocab.update(rank_keywords)
    vocab = list(vocab)

    query_w_freq = Counter(keywords)
    query_vec = np.array([query_w_freq.get(v, 0.0) for v in vocab])
    logger.info(f"vocab: {vocab}, query {keywords}")

    cosine_scores = []
    for i, rank_item in enumerate(es_keywords):
        if query_info.get("norm_text","").strip()==rank_result[i].get("norm_text").strip():
            es_query_score = 1
        else:
            resp_w_freq = Counter(rank_item)
            es_vec = np.array([resp_w_freq.get(v, 0.0) for v in vocab])
            # logger.info(f"cosine rank item {rank_item}, vec {es_vec}")
            es_query_score = 1 - spatial.distance.cosine(query_vec, es_vec)
        cosine_scores.append(es_query_score)
    return cosine_scores

@function_execute_time
def cal_semantic_similarity(query_info, rank_result, config, env="app", MAX_RETRY_NUMBER=3):
    """
    精排模型语义相似度
    :param query_info:
    :param rank_result:
    :param config:
    :param env:
    :param MAX_RETRY_NUMBER:
    :return:
    """
    bot_id = query_info.get("bot_id")
    language = query_info.get("language","zh")
    trace_id = query_info.get("trace_id")
    norm_text = query_info.get("norm_text")
    pattern = re.compile(r'[;；。，,.！\n!?？ ]')
    url = config.get(f"{env}_model_url")
    target = config.get("target")
    token = config.get("token")

    # 预处理
    if language == 'zh':
        query_tokens = list(norm_text)
        candidate_tokens = [list(item.get("norm_text")) for item in rank_result]
        logger.info(f"faq model params {query_tokens},{candidate_tokens}")
    else:
        query_tokens = [tok for tok in pattern.split(norm_text.lower()) if tok != '']
        candidate_tokens = [[tok for tok in pattern.split(item.get("norm_text").lower()) if tok != '']
                            for item in rank_result]
    # 去请求对应机器人的排序模型（表征型）
    params = {
        "isSingle": True,
        "origin": "b9afeacd09885ee3bea033ffb86563ae",
        "target": target,
        "ownerCode": str(bot_id),
        "data": {
            "trace_id": trace_id,
            "question": query_tokens,
            "candidates": candidate_tokens
        }
    }
    headers = {
        "authorization": f"Bearer {token}"
    }
    semantic_sim = [0.0] * len(rank_result)
    for i in range(MAX_RETRY_NUMBER):
        try:
            response = requests.post(url, json=params, headers=headers)

            if (not response) or (response.json()['code'] != 0):
                logger.info(f'time {i} request embedding failure.')
            else:
                result = response.json()['data']['result']
                sorted_index = result.get("sorted_index")
                semantic_result = result.get("results")

                for idx, index in enumerate(sorted_index):
                    semantic_sim[index] = semantic_result[idx][1]
                logger.info(f"精排模型结果：{semantic_sim}")
                return semantic_sim
        except Exception as e:
            error_msg = f'url: {url}, params: {params}， message: 请求模型失败'
            logger.error(error_msg)
            return semantic_sim
    return semantic_sim

@function_execute_time
def cal_synonyms_similarity(query_info, rank_result, key="keywords"):
    # synonyms_similarity = []
    # for idx, rank_item in enumerate(rank_result):
    #     synonyms_score = synonyms.compare(" ".join(query_info.get(key)),rank_item.get(key).strip(),seg=False)
    #     logger.info(f"cal_synonyms_similarity query_info {query_info.get(key)}, {rank_item.get(key).strip()}, score {synonyms_score}")
    #     synonyms_similarity.append(synonyms_score)
    # return synonyms_similarity
    pass
