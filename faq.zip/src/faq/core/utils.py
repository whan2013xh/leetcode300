import numpy as np


def load_stopwords(stopwords_path):
    """加载停用词列表
    """
    return set([l.strip() for l in open(stopwords_path, 'r').readlines()])


def lang_detect(s):
    """语种识别: 中文(zh)/英文(en)"""

    def is_contains_chinese(strs):
        for _char in strs:
            if '\u4e00' <= _char <= '\u9fa5':
                return True
        return False

    return 'zh' if is_contains_chinese(s) else 'en'


def import_class(class_path):
    components = class_path.split('.')
    mod = __import__(components[0])
    for comp in components[1:]:
        mod = getattr(mod, comp)
    return mod


def text_cos_similarity(x_keywords, y_keywords):
    if len(x_keywords) == 0 or len(y_keywords) == 0:
        return 0.0
    sorted_x_keywords = sorted(x_keywords, key=lambda ele: ele[0])
    sorted_y_keywords = sorted(y_keywords, key=lambda ele: ele[0])

    i = 0
    j = 0
    product = 0.0
    x_norm = 0.0
    y_norm = 0.0
    while i < len(sorted_x_keywords) and j < len(sorted_y_keywords):
        if sorted_x_keywords[i][0] == sorted_y_keywords[j][0]:
            product = product + sorted_x_keywords[i][1] * sorted_y_keywords[j][1]
            x_norm = x_norm + sorted_x_keywords[i][1] * sorted_x_keywords[i][1]
            y_norm = y_norm + sorted_y_keywords[j][1] * sorted_y_keywords[j][1]
            i = i + 1
            j = j + 1
        elif sorted_x_keywords[i][0] < sorted_y_keywords[j][0]:
            x_norm = x_norm + sorted_x_keywords[i][1] * sorted_x_keywords[i][1]
            i = i + 1
        else:
            y_norm = y_norm + sorted_y_keywords[j][1] * sorted_y_keywords[j][1]
            j = j + 1

    while i < len(sorted_x_keywords):
        x_norm = x_norm + sorted_x_keywords[i][1] * sorted_x_keywords[i][1]
        i = i + 1
    while j < len(sorted_y_keywords):
        y_norm = y_norm + sorted_y_keywords[j][1] * sorted_y_keywords[j][1]
        j = j + 1

    cos_sim = product / (np.sqrt(x_norm) * np.sqrt(y_norm))
    return cos_sim


def edit_distance(src_words, target_words):
    src_len = len(src_words)
    target_len = len(target_words)

    if src_len == 0:
        return target_len

    if target_len == 0:
        return src_len
    matrix = np.zeros([src_len + 1, target_len + 1], dtype=np.int)

    for i in range(src_len + 1):
        matrix[i][0] = i

    for j in range(target_len + 1):
        matrix[0][j] = j

    for i in range(1, src_len + 1):
        # print('i', i, src_len)
        for j in range(1, target_len + 1):
            # print('j', j, target_len)
            cost = 0
            if src_words[i - 1] != target_words[j - 1]:
                cost = 1
            matrix[i][j] = min(min(matrix[i - 1][j] + 1, matrix[i][j - 1] + 1), matrix[i - 1][j - 1] + cost)

    return matrix[src_len][target_len]


def load_idf(idf_path):
    word2weight = {}
    with open(idf_path, 'r') as file_r:
        for line in file_r:
            if len(line.strip().split('\t')) != 2:
                print(line)
                continue
            word, weight = line.strip().split('\t')
            word2weight[word] = float(weight)
    median_idf = sorted(word2weight.values())[len(word2weight) // 2]
    print(f"median_idf: {median_idf}")

    return word2weight, median_idf


import re

id_box = re.compile("(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{15,35}")
mobile_box = re.compile("\+?[\d]{2,3}-?[\d]{7,11}")
url_box = re.compile("https?://[\w./-=]*")
version_box = re.compile("[vV]?\d{1,2}\.\d{1,2}\.\d{0,2}")
dns_box = re.compile("tuya[\w]*\.[\w\.\(\)]+\.[a-zA-Z0-9_\.\(\)]+")
ip_box = re.compile("\d+\.\d+\.\d+\.\d+")
email_box = re.compile("[\w\.-]+@[\w\.-]+")
path_box = re.compile("/[a-zA-Z0-9_\.\[\]\{\}?=]+/[a-zA-Z0-9_\.\[\]\{\}/?=]+")

zh_box = re.compile("[\u4e00-\u9fa5]+")
en_box = re.compile("[\da-zA-Z]+")

zh_en_box = re.compile("([\u4e00-\u9fa5]+)([\da-zA-Z]+)")
en_zh_box = re.compile("([\da-zA-Z]+)([\u4e00-\u9fa5]+)")


def zh_tag_replace(w):
    if re.findall(url_box, w):
        return '#URL#'
    elif re.findall(version_box, w):
        return '#VERSION#'
    elif re.findall(dns_box, w):
        return '#DNS#'
    elif re.findall(ip_box, w):
        return '#IP#'
    elif re.findall(email_box, w):
        return '#EMAIL#'
    elif re.findall(path_box, w):
        return '#PATH#'
    elif re.findall(phone, w):
        return '#PHONE#'
    elif re.findall(phone2, w):
        return '#PHONE#'
    elif re.findall(path_box, w):
        return '#PATH#'
    elif len(re.findall(num_tag, w)) != 0 and len(re.findall(num_tag, w)[0]) == len(w):
        return '#NUM#'
    else:
        return w


phone = re.compile(' (\+?\d{3,4}-? ?\d{6,9})')
phone2 = re.compile('(\+?[\dx]{11,13})')
id_tag = re.compile('\+?[0-9a-zA-Z]{15,28}')
num_tag = re.compile('\d+')
alpha_tag = re.compile('[a-z]+')
time_tag = re.compile(r'([x]+:[0-9]{1,2}[ap]?m?)|' \
                      '([0-9]{1,2}:[0-9]{1,2}[ap]?m?)|' \
                      '([0-9]{1,2}[ap]m)|' \
                      '([0-9]{1,2}\.[0-9]{1,2}[ap]m)', re.S)


def en_tag_replace(w):
    ''' 英文文本标签化: 电话号码, 网址, 邮箱, 时间等; '''
    if w.find('xxxxxxx') != -1 and w.find('mail') != -1 \
            or w.find("@") != -1:
        return '#EMAIL#'
    elif w.startswith('https://') or w.startswith('http://'):
        return "#URL#"
    elif len(w) > 30:
        return '#EMAIL#'
    elif re.findall(id_tag, w):
        _w = w.replace('x', '')
        if re.findall(alpha_tag, _w) and re.findall(num_tag, _w):
            if w[:-1].find('.') != -1:
                return "#EMAIL#"
            else:
                return "#ID#"
        elif re.findall(num_tag, _w) and not re.findall(alpha_tag, _w):
            return '#PHONE#'
        elif w[:-1].find('.') != -1:
            return '#EMAIL#'
        else:
            return w
    elif re.findall(time_tag, w):
        return '#TIME#'
    elif len(re.findall(num_tag, w)) != 0 and len(re.findall(num_tag, w)[0]) == len(w):
        return "#NUM#"
    elif re.findall(phone, w):
        return '#PHONE#'
    elif re.findall(phone2, w):
        return '#PHONE#'
    elif re.findall('&quot;', w):
        return '"'
    else:
        return w
