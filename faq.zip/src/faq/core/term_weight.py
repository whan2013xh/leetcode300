# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-01-17
    FileName   : term_weight.py
    Author     : Honghe
    Descreption: 
"""
import spacy
import grpc
import re
import os
import sys
from collections import Counter

import traceback
from tytextnorm import TextNorm
import requests

from protos import nlp_basic_pb2_grpc, spwords_pb2_grpc
from protos.spwords_pb2 import BatchTokenRequest
from .utils import load_idf, en_tag_replace, alpha_tag, num_tag, zh_tag_replace, zh_box, en_box
from commons import logger, config



class TermWeight:
    def __init__(self, config):
        self.config = config
        self.en_nlp = spacy.load("en_core_web_sm")
        # self.en_nlp = None
        # self.nlpbasic_grpc_host = config['nlpbasic_grpc_host']
        # grpc_channel = grpc.insecure_channel(self.nlpbasic_grpc_host)
        # self.nlp_basic_stub = nlp_basic_pb2_grpc.NLPBasicServerStub(grpc_channel)

        self.segment_grpc_host = config.get('segment_grpc_host')
        grpc_channel = grpc.insecure_channel(self.segment_grpc_host)
        self.segment_grpc_stub = spwords_pb2_grpc.SpWordsServerStub(grpc_channel)

        self.zh_word2idf, self.zh_median_idf = load_idf(config.get('zh_idf_path'))
        self.en_word2idf, self.en_median_idf = load_idf(config.get('en_idf_path'))
        self.stop_words = self.get_stop_words()
        logger.info("term weight init ....")

    def text_norm(self, query):
        """
        标准化
        :param query:
        :return:
        """
        norm_pre = TextNorm(lower=True, char_norm=True, cc=True, rm_emoji=True, lemma=True, tag_replace=True)
        norm_res = norm_pre(query)
        norm_text = norm_res.get("text")
        return norm_text

    def en_segment(self, querys):
        """
        英文分词
        :param querys:
        :return:
        """
        segments = []
        batch_size = config.get("SEGMENT_BATCH_SIZE", 500)
        for idx in range(int(len(querys) / batch_size) + 1):
            tmp_querys = querys[idx * batch_size:(idx + 1) * batch_size]
            if not tmp_querys:
                continue
            logger.info(f"en_segment {tmp_querys}")
            docs = self.en_nlp.pipe(tmp_querys)  # 分词（考虑了复合词的提取）
            for _, doc in enumerate(docs):
                ori_segment = []
                start = 0
                for idx, tok in enumerate(doc):
                    if start > idx or tok.text.strip() == '':
                        continue

                    if tok.dep_ == "compound":
                        word = doc[tok.i:tok.head.i + 1].text
                        start = tok.head.i + 1
                    else:
                        word = tok.text
                    ori_segment.append(word.strip())
                segment = []
                for word in ori_segment:
                    # if len(word) < 2 or word in self.stopwords: #不考虑分词服务
                    #     continue·
                    if (not re.findall(num_tag, word)) and (not re.findall(alpha_tag, word)):
                        continue
                    replaced_word = en_tag_replace(word)
                    segment.append(replaced_word)
                    # print(word)
                segments.append(segment)
        return segments

    def zh_segment(self, querys, trace_id="zh_faq", retry_times=3):
        """
        中文分词
        :param querys:
        :param trace_id:
        :param retry_times:
        :return:
        """
        segments = []
        batch_size = config.get("SEGMENT_BATCH_SIZE", 500)
        for idx in range(int(len(querys) / batch_size) + 1):
            tmp_querys = querys[idx * batch_size:(idx + 1) * batch_size]
            if not tmp_querys:
                continue
            response = None
            for i in range(retry_times):
                try:
                    # batch_token_requests = BatchTokenRequest(trace_id=trace_id,
                    #                                          texts=tmp_querys,
                    #                                          lang='zh')

                    token = config.get("token")
                    metadata = (
                        ('authorization', f"Bearer {token}"),
                        ('ai-path', "/nlp/spwords/grpc/")
                    )
                    # response, call = self.segment_grpc_stub.batch_tokenize.with_call(batch_token_requests,
                    #                                                                  metadata=metadata)


                    # url = "http://spwords.yulh.svc:8080/v1/spwords/batch_tokenize"
                    url = config.get("batch_tokenize")
                    params = {
                      "texts": tmp_querys,       # 请求query
                      "lang": "zh",                  # 语种，[`zh`|`en`]
                      "filter_stopwords": False       # 是否过滤停用词
                    }
                    response = requests.post(url, json=params)

                    if response.status_code==200:
                        break
                except Exception as e:
                    logger.error(traceback.format_exc())

            # 标签归一化并过滤
            ori_segments = [item.get("tokens") for item in response.json().get("tokenlists")] if response is not None else []
            for ori_segment in ori_segments:
                segment = []
                for word in ori_segment:
                    word = word.strip()
                    # if len(word) < 2 or word in self.stopwords:
                    #     continue
                    if (not re.findall(zh_box, word)) and (not re.findall(en_box, word)):  # 没有找到对应语种的
                        continue
                    replaced_word = zh_tag_replace(word)  # 对分词之后的结果进行替换操作
                    segment.append(replaced_word)

                segments.append(segment)
        return segments

    def segment(self, querys, trace_id, language="zh"):
        """
        1、标准化
        2、分词
        :param querys:
        :param trace_id:
        :param language:
        :return:
        """
        #  # 全角转半角等处理,批量转换
        for idx, query in enumerate(querys):
            query = self.text_norm(query)
            query = ' '.join(query.split())
            querys[idx] = query

        segments = self.zh_segment(querys, trace_id) if language=="zh" else self.en_segment(querys)
        return segments

    def cal_term_weight(self, querys, trace_id, language="zh"):
        """
        计算权重
        :param querys:
        :param trace_id:
        :param lang:
        :return:
        """
        keywords_list = []
        segments = self.segment(querys, trace_id, language=language)
        logger.info(f"cal query {querys} segments {segments}")
        if language=="zh":
            word2idf = self.zh_word2idf
            median_idf = self.zh_median_idf
        else:
            word2idf = self.en_word2idf
            median_idf = self.en_median_idf


        filter_words_list = []
        for segment in segments:
            # word2freq = {}
            keywords = []
            # for word in segment:
            #     word2freq[word] = word2freq.get(word, 0.0) + 1.0

            # total = sum(word2freq.values())
            total = len(segment)
            word2freq = Counter(segment)

            filter_keywords = []
            for word in segment:
                weight = word2freq.get(word) * word2idf.get(word, median_idf) / total
                keywords.append((word.replace(' ', '-'), weight))
                # keywords.append((word, weight))
                if word not in self.stop_words:
                    filter_keywords.append(word)
            keywords_list.append(keywords)
            filter_words_list.append(filter_keywords)
        logger.info(f"trace_id {trace_id},querys {querys}, cal_term_weight result {keywords_list}, filter_words_list:{filter_words_list}")
        return keywords_list, filter_words_list

    def get_stop_words(self):
        stop_words_path = "./config/baidu_stopwords.txt"
        stop_words = []
        with open(stop_words_path, "r+") as f:
            stop_words = f.readlines()
        return [word.strip() for word in stop_words]

