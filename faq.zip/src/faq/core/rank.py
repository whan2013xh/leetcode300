# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-01-14
    FileName   : rank.py
    Author     : Honghe
    Descreption: 排序
"""
import numpy as np

from .query_similarty import cal_bm25_similarity, cal_jaccard_similarity, cal_cosine_similarity, cal_semantic_similarity,cal_synonyms_similarity
from commons import logger, function_execute_time


class Rank:
    def __init__(self, config):
        self.config = config

        self.rough_rank_top = config.get("rough_rank_top", 10)
        self.rank_top = config.get("rank_top", 5)
        self.rough_rank_threshold = config.get("rough_rank_threshold", 0.0)
        self.rank_threshold = config.get("rank_threshold", 0.0)

        self.feature_calculator = []
        self.rough_feature_names = []
        self.feature_names = []

    @function_execute_time
    def rank(self, query_info, es_result):
        """
        排序：文本相似度排序+语义模型精排
        :param query_info:
        :param es_result:
        :return:
        """
        version = query_info.get("version")
        language = query_info.get("language")
        model_info = query_info.get("modelInfo")
        topN = query_info.get("topN")
        have_model = model_info is not None
        exec_model = False
        bm25_result = [0.0]*len(es_result)
        jaccard_result = [0.0] * len(es_result)
        cosine_result = [0.0] * len(es_result)
        # 1、粗排
        if self.rough_rank_top>0:
            bm25_result = cal_bm25_similarity(query_info, es_result)
            jaccard_result = cal_jaccard_similarity(query_info, es_result)
            cosine_result = cal_cosine_similarity(query_info, es_result)

        semantic_similarity = [0.0]*len(es_result)
        # 2、判断是否需要调用模型
        if version != "v1.4" and model_info is not None:
            semantic_similarity = cal_semantic_similarity(query_info, es_result, self.config)
            exec_model = sum(semantic_similarity)>0

        # synonyms_similarity =[0.0]*len(es_result)
        # tmp = cal_synonyms_similarity(query_info, es_result[:topN])
        # synonyms_similarity[:topN] = tmp
        tmp_weight = self.config.get("weight").get(language)
        features_names = list(self.config.get("weight").get(language).keys())
        features = [[bm25_result[i],jaccard_result[i], cosine_result[i], semantic_similarity[i]] for i in range(len(es_result))]
        bm25_result = [i*tmp_weight.get("bm25") for i in bm25_result]
        jaccard_result = [i*tmp_weight.get("jaccard") for i in jaccard_result]
        cosine_result = [i * tmp_weight.get("cosine") for i in cosine_result]
        semantic_similarity = [i * tmp_weight.get("semantic") for i in semantic_similarity]
        # synonyms_similarity = [i * 0.5 for i in synonyms_similarity]
        # 3、加权重排
        weight_score = np.sum([bm25_result, jaccard_result, cosine_result, semantic_similarity], axis=0)
        if not query_info.get("rerank", True):
            weight_score = [0]*len(es_result)
        # synonyms_similarity = cal_synonyms_similarity(query_info, es_result[:topN])
        # rank_result = self.sort_result(es_result[:topN], synonyms_similarity, have_model, exec_model, features_names, features)
        rank_result = self.sort_result(es_result, weight_score, have_model, exec_model, features_names, features)


        return rank_result[:topN]

    def sort_result(self, es_result, weight_score, have_model, exec_model, features_names, features):
        """
        重排
        :param es_result:
        :param weight_score:
        :param have_model:
        :param exec_model:
        :param features_names:
        :param features:
        :return:
        """
        sort_es = []
        for index, record in enumerate(es_result):
            tmp_record = {}
            answer = {'query': record.get("query"), 'query_id': record.get("query_id"),
                      'knowledge_code': record.get("knowledge_code"),
                      'is_standard': record.get("is_standard"), 'catalogs': record.get("catalogs"),
                      'labels': record.get("labels"),
                      'language': record.get("language"), 'answer': record.get("answer"),
                      'answer_id': record.get("answer_id"), 'features': features[index],
                      'feature_names': features_names}
            tmp_record["answer"] = answer
            tmp_record["score"] = weight_score[index]
            tmp_record["fromID"] = record.get("bot_id")
            # 遗留问题，后期优化需要新增字段，修改为answer_id
            tmp_record["knowledge_code"] = record["knowledge_code"]
            tmp_record["have_model"] = have_model
            tmp_record["exec_model"] = exec_model
            tmp_record["qa_type"] = "faq"
            sort_es.append(tmp_record)
        sort_es.sort(key=lambda x:x.get("score"), reverse=True)
        return sort_es


if __name__ == '__main__':
    query_info = {
        "query": "设备?",
        "norm_text": "设备?",
        "keywords": "设备"
    }
    es_result = [
        {
            "query": "设备组设备数量上限?",
            "norm_text": "设备组设备数量上限?",
            "keywords": "设备 组 设备 数量 上限",
            "es_score": 3.6847417
        },
        {
            "query": "多个设备，设备顺序不能调整",
            "norm_text": "多个设备,设备顺序不能调整",
            "keywords": "多 个 设备 设备 顺序 不 能 调整",
            "es_score": 3.6847417
        },
        {
            "query": "设备",
            "norm_text": "设备",
            "keywords": "设备",
            "es_score": 3.679741
        }
    ]
    import asyncio
    # loop = asyncio.get_event_loop()
    rank_obj = Rank({})
    # loop.run_until_complete(rank_obj.rank(query_info, es_result))
    rank_obj.rank(query_info, es_result)






