# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-01-14
    FileName   : recall.py
    Author     : Honghe
    Descreption: 
"""
import json
from copy import deepcopy
import os
import sys
from tuya_apollo_client import apollo_client

from elasticsearch_dsl import Search, Q

from commons import logger, function_execute_time, init_es




class TermRecall:
    def __init__(self, config):
        self.faq_index = config.get("FAQ_INDEX")
        self.config = config
        self.es_client = init_es(config)

    @function_execute_time
    def recall(self, query_info, es_client=None):
        """
        召回
        :param query_info:
        :param is_pre:
        :param language:
        :return:
        """
        query = query_info.get("norm_text")
        if query_info.get("norm_text") is None:
            query_condition = {
                "query":query_info.get("query")
            }
        else:
            query_condition = {
                "norm_text": query_info.get("norm_text")
            }
        bot_id = query_info.get("bot_id")
        language = query_info.get("language", "zh")
        topN =max(self.config.get("recall_size"), int(query_info.get("topN",10))*2)
        base_code = query_info.get("base_code")
        is_pre = query_info.get("is_pre", 1)

        knowledge_code_set = set([])  # 可以根据knowledge_code过滤
        index_name = self.faq_index.get(language)

        es_search = Search(using=self.es_client, index=index_name)
        q = Q("match", **query_condition) & Q("match", bot_id=bot_id) & Q("match", is_pre=is_pre) #&Q("match", answer=query_info.get("answer"))
        if query_info.get("stop_words") is not None:
            # q = q & Q("match",**{"answer":{"query":query_info.get("answer"),"boost":2}})
            q = q | Q("match", **{"answer": {"query": query_info.get("answer"),"boost":0.5}})
            # q= Q("match", bot_id=bot_id) & Q("match", is_pre=is_pre)&Q("match", **{"answer": {"query": query_info.get("answer")}})
            # q = q|Q("match", **query_condition)
        if base_code is not None:
            q = q & Q("match", base_code=base_code)
        res = es_search.query(q).params(size=topN).execute()
        hit_results = res["hits"]["hits"]
        results = []
        for hit in hit_results:
            tmp = hit.to_dict()
            score = tmp.get("_score")
            record = tmp.get("_source")
            record["es_score"] = score
            knowledge_code = record.get("knowledge_code")
            if knowledge_code in knowledge_code_set:
                continue
            knowledge_code_set.add(knowledge_code)
            results.append(record)

        logger.info(f"query: {query}，q:{q.to_dict()} recall candidate size: {len(results)} from term recall.")
        return results

