# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-01-14
    FileName   : pre_handler.py
    Author     : Honghe
    Descreption: 预处理
"""

from tytextnorm import TextNorm

from commons import logger, function_execute_time
from .term_weight import TermWeight


class PreHandler:
    def __init__(self,config):
        self.term_weight = TermWeight(config)

        # self.term_weight = None

    @staticmethod
    def text_norm(text):
        norm_pre = TextNorm(lower=True, char_norm=True, cc=True, rm_emoji=True, lemma=True, tag_replace=True)
        norm_res = norm_pre(text)
        logger.info(f"text_norm query {text} norm result {norm_res.get('text')}")
        return norm_res.get("text")

    @function_execute_time
    def pre_handler(self, query_info, keywords=True):
        """
        预处理：
        1、归一化
        2、分词计算权重
        :param query_info:
        :return:
        """
        query = query_info.get("query")
        trace_id = query_info.get("trace_id")
        language = query_info.get("language")

        # 1、归一化
        norm_text = query_info.get("norm_query", "")
        if not norm_text:
            norm_text = self.text_norm(query)
        query_info["norm_text"] = norm_text
        logger.info(f"norm query is {norm_text}")
        if norm_text is None or not norm_text:
            logger.info(f"query {query}, trace_id {trace_id} norm failed {norm_text}")
            return None

        if not keywords:
            return norm_text
        # 2、计算权重
        keyword_weight_list, filter_words_list = self.term_weight.cal_term_weight([norm_text], trace_id, language=language)
        # keyword_weight_list =[[('can',0.1), ('i',0.2), ('get',0.3), ('an',0.01), ('invoice',0.02)]]

        if keyword_weight_list:
            query_info["keywords"] = [keyword for keyword, weight in keyword_weight_list[0]]
            query_info["keywords_weight"] = keyword_weight_list[0]
            return filter_words_list[0]
        else:
            return filter_words_list




