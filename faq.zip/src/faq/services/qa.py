# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-01-14
    FileName   : qa.py
    Author     : Honghe
    Descreption: FAQ推理服务主流程
"""
from commons import logger, middle_ware
from core import PreHandler, Rank, TermRecall


class QA(object):
    def __init__(self, config):
        self.config = config
        self.pre_handler = PreHandler(config)
        self.recaller = TermRecall(config)
        self.ranker = Rank(config)

    def process(self, query_info):
        """
        faq 推理服务主流程
        1、预处理：标准化+关键词提取
        2、召回：es
        3、排序: bm25+jaccard+cosine+model精排
        :param query_info:请求参数
        :return:
        """
        trace_id = query_info.get("trace_id")
        # 预处理
        logger.info(f"trace_id:{trace_id} start analysis process!!!")
        handler_res = self.pre_handler.pre_handler(query_info, keywords=self.config.get("keywords"))
        if handler_res is None:
            return False, "faq 预处理失败"
        query_info["answer"] = "".join(handler_res)
        logger.info(f"norm_text {''.join(handler_res)}")
        # recall 召回
        logger.info(f"trace_id:{trace_id} start recall process!!!")
        es_res = self.recaller.recall(query_info)
        if not es_res:
            logger.info(f"query_info {query_info} 召回数据为0")
            return True, []

        # rank 排序
        logger.info(f"trace_id:{trace_id} start match and rank process!!!")
        answers = self.ranker.rank(query_info, es_res)
        return True, answers

    def get_term_weight(self, querys, trace_id, language):
        """
        获取term_weight
        """
        keywords_list, _ = self.pre_handler.term_weight.cal_term_weight(querys, trace_id, language)
        return keywords_list[0]



