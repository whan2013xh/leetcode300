# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-01-14
    FileName   : actions.py
    Author     : Honghe
    Descreption: 
"""
import time
# from queue import Queue

from sanic import Blueprint
from prometheus_client import Counter
from prometheus_client.core import CollectorRegistry

from .base import get_request_json, response_json, ResponseCode, handle_exception
from commons import logger, config
from services import QA

faq = Blueprint("faq", url_prefix="/faq")
qa_service = QA(config)
# requests_total = Counter('qa-inference','faq 推理服务请求计数器')

#
@faq.get("/health")
async def health(request):
    """
    :param request:
    :return:
    """
    return response_json(ResponseCode.OK, message="faq 推理服务正常")


@faq.post("/get_answers")
async def get_answers(request):
    # requests_total.inc(1)
    start_time = time.time()
    request_json = get_request_json(request)
    if not request_json:
        return response_json(ResponseCode.FAIL, status=500, message="请求体异常")
    trace_id = request_json.get("trace_id", '')
    query = request_json.get('query', '')
    bot_id = request_json.get("bot_id", "")

    logger.info(f"faq get answers start to process!")
    # 初始化返回结果
    if not query or not bot_id:
        err_msg = f"trace_id:{trace_id}, query and bot_id is need!!!"
        logger.error(err_msg)
        return response_json(ResponseCode.FAIL, status=500, message="faq 请求参数不对")

    logger.info(f"init qa cost:{trace_id}, it cost time: {time.time() - start_time} ms ")
    flag, answers = qa_service.process(request_json)
    if not flag:
        response_json(ResponseCode.FAIL, query=query, message=answers, traceId=trace_id, status=500, data=answers)

    # 初始化输入信息
    logger.info(f"faq end trace_id:{trace_id}, it cost time: {time.time() - start_time} ms, result: {answers}")

    return response_json(ResponseCode.OK, query=query, message="faq 推理服务正常", traceId=trace_id, data=answers)

@faq.post("/get_term_weight")
async def get_term_weight(request):
    # requests_total.inc(1)
    start_time = time.time()
    request_json = get_request_json(request)
    if not request_json:
        return response_json(ResponseCode.FAIL, status=500, message="请求体异常")
    trace_id = request_json.get("trace_id", '')
    query = request_json.get('query', '')
    bot_id = request_json.get("bot_id", "")

    logger.info(f"faq get answers start to process!")
