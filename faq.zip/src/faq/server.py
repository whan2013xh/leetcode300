# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-01-12
    FileName   : server.py
    Author     : Honghe
    Descreption: 启动脚本
"""
import time
import os

from sanic import Sanic

from commons import config, logger, get_log_config, middle_ware
from blueprint import faq, handle_exception
from sanic_prometheus import monitor

print("xxxx")
# 初始化 app
app = Sanic(config["NAME"].capitalize(), log_config=get_log_config(config))
# 更新配置
app.config.update(config)
# 注册错误处理器
app.error_handler.add(Exception, handle_exception)
# os.environ["PROMETHEUS_MULTIPROC_DIR"] = config.get("PROMETHEUS_MULTIPROC_DIR","cache")
# print(os.path.join(os.getcwd(),config.get("PROMETHEUS_MULTIPROC_DIR","cache")))
# 创建静态文件路由
# app.static(
#     "/files",
#     os.path.join(config["DATA_DIR"], config["TEMP_DIR"]),
#     stream_large_files=True
# )

# 注册蓝图
app.blueprint(faq)


# 注册服务开始监听器
@app.listener("before_server_start")
async def server_init(app, loop):
    # 初始化mysqldb
    # app.milvus_client = milvus_client(config)
    # 初始化mongodb
    # middle_ware.init_es(config)
    logger.info("server init...")
    pass


# 注册服务结束监听器
@app.listener("after_server_stop")
async def server_clean(app, loop):
    # 关闭milvus
    # app.milvus_client.close()
    # app.db.close()
    logger.info("server closed")


# 注册请求开始中间件
@app.middleware("request")
async def request_begin(request):
    """
    记录请求参数等信息
    :param request:
    :return:
    """
    cur_time = time.time()
    # 添加 nlptcp_start_time
    request.headers["sync_start_time"] = cur_time
    # 添加 sync_time
    request.headers["sync_time"] = int(cur_time * 1000)
    logger.info(f"request start { request.method } params { str(request.body, encoding='utf-8') }")
    # connect_db(app.db)

# 注册请求结束中间件
@app.middleware("response")
async def request_end(request, response):
    # 删除 sync_time
    request.headers.pop("sync_time", None)
    # 删除 nlptcp_start_time
    start_time = request.headers.pop("sync_start_time", None)
    # 计算 请求消耗时间
    end_time = time.time()
    if start_time is None:
        spend_time = 0
    else:
        spend_time = round((end_time - start_time) * 1000, 2)
    logger.info(f"request end { response.status } { request.method } { request.path } { request.query_string } { spend_time }ms")
    # close_db(app.db)


if __name__ == "__main__":
    monitor(app).expose_endpoint()
    # app.run(host=config["HOST"], port=config["PORT"], debug=config["DEBUG"],
    #         auto_reload=config["AUTO_RELOAD"], access_log=config["ACCESS_LOG"],
    #         workers=config["WORKERS"])
    app.run(host=config["HOST"], port=config["PORT"],
            workers=config["WORKERS"])
    print("yyyy")
    logger.info("faq service start")