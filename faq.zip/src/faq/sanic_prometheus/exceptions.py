class SanicPrometheusError(RuntimeError):
    pass
