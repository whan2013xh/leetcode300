# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-01-12
    FileName   : log.py
    Author     : Honghe
    Descreption: 
"""
import logging
import sys
import datetime
import os

from loguru import logger

from .config import config

log_dir = config["LOG_DIR"]
date = datetime.date.today()

def check_dir(bd):
    if not os.path.exists(bd):
        old_mask = os.umask(0o022)
        os.makedirs(bd)
        os.umask(old_mask)

class InterceptHandler(logging.Handler):
    def emit(self, record):
        logger_opt = logger.opt(depth=6, exception=record.exc_info)
        msg = self.format(record)
        logger_opt.log(record.levelno, msg)


# logging.basicConfig(handlers=[InterceptHandler()], level=0)
# 配置日志到标准输出流
logger.configure(handlers=[{"sink": sys.stderr, "level": 'INFO'}])
check_dir(log_dir)
# 配置日志到输出到文件，按大小切分
logger.add(
    f"{ log_dir }/{ date }.log", rotation="20 MB",  retention=7, encoding='utf-8', colorize=False, level='INFO'
)

def get_log_config(config):
    default_level = 'DEBUG' if config['DEBUG'] else 'INFO'

    return {
        'version': 1,
        'disable_existing_loggers': False,
        'loggers': {
            'sanic.root': {
                'level': config.get('LOGGER_SANIC_ROOT_LEVEL', default_level),
                'handlers': ['console'],
            },
            'sanic.error': {
                'level': config.get('LOGGER_SANIC_ERROR_LEVEL', default_level),
                'handlers': ['error_console'],
                'propagate': True,
                'qualname': 'sanic.error',
            },
            'sanic.access': {
                'level': config.get('LOGGER_SANIC_ACCESS_LEVEL', default_level),
                'handlers': [config.get('LOGGER_SANIC_ACCESS_HANDLER',
                                        'access_console')],
                'propagate': True,
                'qualname': 'sanic.access',
            },
            'app': {
                'level': config.get('LOGGER_APP_LEVEL', default_level),
                'handlers': [config.get('LOGGER_APP_HANDLER', 'app_console')],
                'propagate': True,
                'qualname': 'app',
            },
        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'generic',
                'stream': sys.stdout,
            },
            'error_console': {
                'class': 'logging.StreamHandler',
                'formatter': 'generic',
                'stream': sys.stderr,
            },
            'access_console': {
                'class': 'logging.StreamHandler',
                'formatter': 'access',
                'stream': sys.stdout,
            },
            'access_file': {
                'class': 'logging.handlers.RotatingFileHandler',
                'formatter': 'access',
                'filename': '{}/access.log'.format(config['LOG_DIR']),
                'maxBytes': 10 * 1024 * 1024,
            },
            'app_console': {
                'class': 'logging.StreamHandler',
                'formatter': 'generic',
                'stream': sys.stdout,
            },
            'app_file': {
                'class': 'logging.handlers.RotatingFileHandler',
                'formatter': 'generic',
                'filename': '{}/app.log'.format(config['LOG_DIR']),
                'maxBytes': 10 * 1024 * 1024,
            },
        },
        'formatters': {
            'generic': {
                'format': '%(asctime)s [%(process)d] [%(levelname)s] %(message)s',
                'datefmt': '[%Y-%m-%d %H:%M:%S %z]',
                'class': 'logging.Formatter',
            },
            'access': {
                'format': '%(asctime)s - (%(name)s)[%(levelname)s][%(host)s]: '
                + '%(request)s %(message)s %(status)d %(byte)d',
                'datefmt': '[%Y-%m-%d %H:%M:%S %z]',
                'class': 'logging.Formatter',
            },
        },
    }
