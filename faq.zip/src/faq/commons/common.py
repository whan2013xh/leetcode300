# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-01-12
    FileName   : common.py
    Author     : Honghe
    Descreption: 
"""
import traceback
from functools import wraps

from sanic import response
from sanic.exceptions import SanicException

def response_json(success=True, message='', status=200, **data):
    return response.json({'success': success, 'message': message, 'data': data},
                         status)


def handle_exception(request, e):
    status = 200
    success = True
    message = repr(e)
    if isinstance(e, SanicException):
        if e.status_code is not None:
            status = e.status_code
        traceback.print_exc()
    # elif isinstance(e, UsecaseException):
    #     message = e.message
    #     if isinstance(e, UnauthenticatedException):
    #         status = 401
    #         code = 'unauthenticated'
    #     elif isinstance(e, UnauthorizedException):
    #         status = 403
    #         code = 'unauthorized'
    #     elif isinstance(e, NotFoundException):
    #         status = 404
    #         code = 'not_found'
    else:
        traceback.print_exc()

    return response_json(success, message, status)