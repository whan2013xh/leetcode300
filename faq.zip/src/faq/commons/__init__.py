# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-01-12
    FileName   : __init__.py.py
    Author     : Honghe
    Descreption: 
"""
from sanic.config import Config

from .log import get_log_config, logger
from .common import response_json, handle_exception
from .utils import  function_execute_time, middle_ware, init_es
from .config import config as base_config

# 初始化配置
config = Config(base_config)
# 加载基础配置
# config.from_object(BaseConfig(**base_config))
# 从环境变量中加载配置
config.load_environment_vars("QA_")

