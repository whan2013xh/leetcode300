# -*- coding: utf-8 -*-
"""
    CreatedDate: 2021-08-09
    FileName   : utils.py
    Author     : Honghe
    Descreption:
"""
from functools import wraps
import hashlib
from time import time

import requests
from elasticsearch_dsl.connections import connections
from tuya_apollo_client import apollo_client

from .log import logger
from .config import config


def init_es(config):
    """
    初始化ES
    :param config:
    :return:
    """
    env = config.get("ENV_NAME")
    sk = bytes(config.get("APOLLO_SK"), encoding="utf8")
    app_id = config.get("APOLLO_APP_ID")
    if env == "dev":
        hosts = "172.16.248.34:9210"
    elif env == "daily":
        hosts = "172.30.68.102:9210"
    else:
        client = apollo_client.TuyaApolloClient(app_id=app_id, env=env, sk=sk)

        configs = client.get_all(need_refetch=True)
        baseuris = configs['es.data.host'].split(',')
        configs = [
            {
                "baseuri": baseuri,
                "port": configs['es.data.port.restfull'],
                "user": configs['security.app.key.version'],
                "secret": configs['security.app.key']
            }
            for baseuri in baseuris
        ]
        hosts = ['http://qa_{user}:{secret}@{baseuri}:{port}'.format(**config) for config in configs]
    # hosts = 'http://qa-document_3:5c8d31b654489ca88581e217c70e2d169d4d523af53fbc409786991ad54ffdd2@elastic-proxy.common-in.wgine-dev.com:80'
    # dev_hosts = "172.16.248.34:9210"
    # daily_host = "172.30.68.102:9210"
    # hosts = dev_hosts
    es_client = connections.create_connection(hosts=hosts)
    # es_client.indices.close("en_faq")
    # hosts = config.get("ES").get("ES_HOSTS")+":"+str(config.get("ES").get("ES_PORT"))
    # es_client = Elasticsearch(hosts)
    logger.info("es init succeed env: %s, hosts: %s" % (env, hosts))
    return es_client


class MiddleWare():
    def __init__(self):
        self.es_client = None

    def init_es(self, config):
        """
        初始化ES
        :param config:
        :return:
        """
        env = config.get("ENV_NAME")
        sk = bytes(config.get("APOLLO_SK"), encoding="utf8")
        app_id = config.get("APOLLO_APP_ID")
        logger.info(f"es init start env: {env}" )
        if env=="dev":
            hosts= "172.16.248.34:9210"
        elif env=="daily":
            hosts = "172.30.68.102:9210"
        else:
            client = apollo_client.TuyaApolloClient(app_id=app_id, env=env, sk=sk)

            configs = client.get_all(need_refetch=True)
            baseuris = configs['es.data.host'].split(',')
            configs = [
                {
                    "baseuri": baseuri,
                    "port": configs['es.data.port.restfull'],
                    "user": configs['security.app.key.version'],
                    "secret": configs['security.app.key']
                }
                for baseuri in baseuris
            ]
            hosts = ['http://qa_{user}:{secret}@{baseuri}:{port}'.format(**config) for config in configs]
        # hosts = 'http://qa-document_3:5c8d31b654489ca88581e217c70e2d169d4d523af53fbc409786991ad54ffdd2@elastic-proxy.common-in.wgine-dev.com:80'
        # dev_hosts = "172.16.248.34:9210"
        # daily_host = "172.30.68.102:9210"
        # hosts = dev_hosts
        self.es_client = connections.create_connection(hosts=hosts)
        # es_client.indices.close("en_faq")
        # hosts = config.get("ES").get("ES_HOSTS")+":"+str(config.get("ES").get("ES_PORT"))
        # es_client = Elasticsearch(hosts)
        logger.info("es init succeed env: %s, hosts: %s" % (env, hosts))
        return self.es_client




def hash_milvus_id(content):
    md5 = hashlib.md5()
    md5.update(content.encode('utf-8'))
    md5_value = md5.hexdigest()
    return md5_value



def logger_begin_end(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # 日志信息
        task = args[0]
        task_id = task.request.id
        task_args = task.request.args
        logger.info(f"Begin: id={ task_id }, args={ task_args }")

        # 链接数据库
        # connect_db(db)
        result = func(*args, **kwargs)
        # 关闭数据库
        # close_db(db)

        logger.info(f"End: id={ task_id }, args={ task_args }")
        return result

    return wrapper

def connect_db(db):
    if db.is_closed():
        db.connect()


def close_db(db):
    if not db.is_closed():
        db.close()


def function_execute_time(func):
    # 定义嵌套函数，用来打印出装饰的函数的执行时间
    def wrapper(*args, **kwargs):
        # 定义开始时间和结束时间，将func夹在中间执行，取得其返回值
        start = time()
        func_return = func(*args, **kwargs)
        end = time()
        # 打印方法名称和其执行时间
        logger.info(f'{func.__name__}() execute time: {end - start}s')
        # 返回func的返回值
        return func_return

    # 返回嵌套的函数
    return wrapper


class WeChatHandler(object):
    _url = "http://basic.tuya-inc.com:7007/qywx.do"

    _headers = {
        "Tuya-Intranet": "Tuya@intranet@2018",
        "Content-Type": "application/x-www-form-urlencoded"
    }

    _base = "xxx项目：faq推理服务模块{}\n" + \
            "任务名称：{}\n" + \
            "执行状态：{}\n" + \
            "任务信息：{}\n"


    def __init__(self, user_id, task_name):
        self.user_id = str(user_id) if user_id else "honghe.xu@tuya.com"
        self.task_name = str(task_name)


    def send(self, flag, message):
        status = "成功" if flag else "失败"
        msg = self._base.format(config.get("ENV_NAME"),self.task_name, status, str(message))
        url_token = config.get("text_parser_token")
        message_send_url = config.get("message_send_url")
        _headers = {
            "authorization": f"Bearer {url_token}"
        }
        send_message = {
            "text": msg,
            "user": self.user_id
        }
        logger.info(f"sss {self.user_id}")
        response = requests.post(message_send_url, json=send_message, headers=_headers)
        return response


middle_ware = None

