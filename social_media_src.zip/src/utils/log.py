# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-09-01
    FileName   : log.py
    Author     : Honghe
    Descreption: 
"""
import logging
import sys
import datetime
import os

from loguru import logger

from .config import config

log_dir = config["LOG_DIR"]
date = datetime.date.today()

def check_dir(bd):
    if not os.path.exists(bd):
        old_mask = os.umask(0o022)
        os.makedirs(bd)
        os.umask(old_mask)

class InterceptHandler(logging.Handler):
    def emit(self, record):
        logger_opt = logger.opt(depth=6, exception=record.exc_info)
        msg = self.format(record)
        logger_opt.log(record.levelno, msg)


# logging.basicConfig(handlers=[InterceptHandler()], level=0)
# 配置日志到标准输出流
logger.configure(handlers=[{"sink": sys.stderr, "level": 'INFO'}])
check_dir(log_dir)
# 配置日志到输出到文件，按大小切分
logger.add(
    f"{ log_dir }/{ date }.log", rotation="20 MB",  retention=7, encoding='utf-8', colorize=False, level='INFO'
)