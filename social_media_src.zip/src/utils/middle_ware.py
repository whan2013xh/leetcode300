# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-09-01
    FileName   : middle_ware.py
    Author     : Honghe
    Descreption: 
"""
import time

from .log import logger
from .auth import login
from .db import mongo_base,MotorBase


# 注册服务开始监听器
async def server_init(app, loop):
    # 初始化mysqldb
    # 初始化mongodb
    logger.info("server init...")
    mongo_db = MotorBase()
    app.ctx.mongo_db = mongo_db.db
    app.ctx.mongo_client = mongo_db.client()




# 注册服务结束监听器
async def server_clean(app, loop):
    # 关闭milvus
    # app.db.close()
    logger.info(f"closing motor connection ")
    app.ctx.mongo_client.close()
    logger.info("server closed")


# 注册请求开始中间件
async def request_begin(request):
    """
    记录请求参数等信息
    :param request:
    :return:
    """
    cur_time = time.time()
    # 添加 start_time
    request.headers["start_time"] = cur_time
    # 添加 sync_time
    request.headers["sync_time"] = int(cur_time * 1000)
    # login(request)
    logger.info(f"request start { request.method } params { str(request.body, encoding='utf-8') }")
    # db.connect()

# 注册请求结束中间件
async def request_end(request, response):
    # 删除 sync_time
    request.headers.pop("sync_time", None)
    # 删除 nlptcp_start_time
    start_time = request.headers.pop("sync_start_time", None)
    # 计算 请求消耗时间
    end_time = time.time()
    if start_time is None:
        spend_time = 0
    else:
        spend_time = round((end_time - start_time) * 1000, 2)
    logger.info(f"request end { response.status } { request.method } { request.path } { request.query_string } { spend_time }ms")
    # if not db.is_closed():
    #     db.close()
