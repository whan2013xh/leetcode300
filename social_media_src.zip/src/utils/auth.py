# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-09-08
    FileName   : auth.py
    Author     : Honghe
    Descreption: 
"""
import json
import time
import datetime

from itsdangerous import Signer

from .log import logger
from .config import config

signer = Signer(config["SECRET_KEY"])  # test@tuya.com.Y4aC9HsxfPdECrf78injor8c9Uo

def ai_sso_auth(request):
    """
    算法平台鉴权
    :param request:
    :return:
    """
    flag = True
    sso_email = request.headers["ai-userid"]
    logger.info(sso_email)
    request.headers["user"] = sso_email
    return


def sso_auth(request):
    """
    如果使用sso访问后端，如果该操作人员还未在用户表，则创建
    """
    sso_user = json.loads(request.headers["tuya_employee"])
    sso_email = sso_user["email"]
    logger.info(sso_email)
    request.headers["user"] = sso_email
    return


def login(request):
    """
    登陆鉴权分发，根据不同的登陆用户进行不同的权限鉴权，authorization是测试开发登陆鉴权
    :param request:
    :return:
    """
    if "user" in request.headers:
        return
    if "ai-userid" in request.headers:
        logger.info("ai sso_check")
        sso_email = request.headers["ai-userid"]
        request.headers["user"] = sso_email
    elif "tuya_employee" in request.headers:
        logger.info("tuya sso_check")
        sso_user = json.loads(request.headers["tuya_employee"])
        sso_email = sso_user["email"]
        request.headers["user"] = sso_email
    elif "authorization" in request.headers:
        logger.info("token_check")
        sso_email = signer.unsign(request.headers["authorization"])
        request.headers["user"] = sso_email
    else:
        return None