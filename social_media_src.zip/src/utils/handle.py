# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-09-01
    FileName   : handle.py
    Author     : Honghe
    Descreption: 
"""

import traceback
from functools import wraps

from sanic import response
from sanic.exceptions import SanicException

def response_json(success=True, message='', status=200, **data):
    return response.json({'success': success, 'message': message, 'data': data},
                         status)

def response_normalize(f):
    """
    对API接口返回标准化
    """
    @wraps(f)
    async def decorated_function(request, *args, **kwargs):
        result = await f(request, *args, **kwargs)
        result = {} if not isinstance(result,dict) else result
        success = result.get("success", True)
        code = result.get("code", 200)
        return response.json({'success': success, 'message': result.get("msg",""), 'data': result.get("data")},
                      code)

    return decorated_function


def handle_exception(request, e):
    status = 200
    success = True
    message = repr(e)
    if isinstance(e, SanicException):
        if e.status_code is not None:
            status = e.status_code
        traceback.print_exc()
    # elif isinstance(e, UsecaseException):
    #     message = e.message
    #     if isinstance(e, UnauthenticatedException):
    #         status = 401
    #         code = 'unauthenticated'
    #     elif isinstance(e, UnauthorizedException):
    #         status = 403
    #         code = 'unauthorized'
    #     elif isinstance(e, NotFoundException):
    #         status = 404
    #         code = 'not_found'
    else:
        traceback.print_exc()

    return response_json(success, message, status)
