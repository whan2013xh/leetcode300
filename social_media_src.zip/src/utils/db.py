# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-09-05
    FileName   : db.py
    Author     : Honghe
    Descreption: 连接数据库
"""
from motor import motor_asyncio

from .config import config

# mongoDB_url = f"mongodb://{config.get('MONGODB_USER')}:{config.get('MONGODB_PASSWORD')}@{config.get('MONGODB_HOST')}"
# mongo_client = motor_asyncio.AsyncIOMotorClient(mongoDB_url)
# db_name = config.get('MONGODB_DB_NAME')
# mongo_db = mongo_client.get_database(db_name)

class MotorBase:
    """
    默认实现了一个db只创建一次，缺点是暂不支持多库连接
    """
    _db = None
    MONGODB = config.get("MONGODB")

    def client(self, db=None):
        # motor
        db = self.MONGODB['MONGODB_DB_NAME'] if db is None else db
        self.motor_uri = 'mongodb://{account}{host}:{port}/{database}'.format(
            account='{username}:{password}@'.format(
                username=self.MONGODB['MONGODB_USER'],
                password=self.MONGODB['MONGODB_PASSWORD']) if self.MONGODB['MONGODB_USER'] else '',
            host=self.MONGODB['MONGODB_HOST'] if self.MONGODB['MONGODB_HOST'] else 'localhost',
            # port=self.MONGODB['MONGODB_HOST'] if self.MONGODB['MONGODB_HOST'] else 27017,
            database=db)
        return motor_asyncio.AsyncIOMotorClient(self.motor_uri)

    @property
    def db(self):
        if self._db is None:
            self._db = self.client(self.MONGODB['MONGODB_DB_NAME'])

        return self._db

mongo_base = None





