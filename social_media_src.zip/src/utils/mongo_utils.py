# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-09-08
    FileName   : mongo_utils.py
    Author     : Honghe
    Descreption: 
"""


class MongoUtils:
    @classmethod
    async def find_all(cls, db, collection_name, condition, sort_field=None,sort_flag = True):
        collection = db.get(collection_name)
        cursor = collection.find(condition)
        # Modify the query before iterating
        if sort_field is not None:
            cursor.sort(sort_field, 1 if sort_flag else -1)
        result = []
        async for document in cursor:
            result.append(document)
        return result

    @classmethod
    async def do_insert_many(cls, db, collection_name, insert_data):
        collection = db[collection_name]
        result = await collection.insert_many(insert_data)
        print('inserted many %d docs' % (len(result.inserted_ids),))
        return len(result.inserted_ids)

    @classmethod
    async def do_insert_one(cls, db, collection_name, insert_data):
        collection = db[collection_name]
        result = await collection.insert_one(insert_data)
        print(f'inserted one  docs id is {result.inserted_id}')
        return result.inserted_id





