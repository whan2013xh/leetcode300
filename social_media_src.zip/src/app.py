# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-09-01
    FileName   : app.py
    Author     : Honghe
    Descreption: 
"""

import time
import os

from sanic import Sanic
from sanic_ext import Extend, openapi
# from sanic_openapi import openapi3_blueprint
from tortoise.contrib.sanic import register_tortoise
from tortoise import Tortoise,run_async


from utils import config, logger, handle_exception,response_json,server_init,server_clean,request_begin,request_end
from routes import projects
# from models import Mention


# 初始化 app
app = Sanic(config["NAME"].capitalize())
# 更新配置
app.config.update(config)
# app.ctx.mongo_client = mongo_client
# app.ctx.mongo_db = mongo_db
# 注册错误处理器
app.error_handler.add(Exception, handle_exception)

db_url = f"mysql://{config.get('MYSQL_USER')}:{config.get('MYSQL_PASSWORD','')}@{config.get('MYSQL_HOST')}:{config.get('MYSQL_PORT')}/{config.get('MYSQL_DB_NAME')}"
# 异步连接MySQL
register_tortoise(
    app, db_url=db_url, modules={"models": ["models"]}, generate_schemas=True
)
# Extend(app)

# 注册监听器和中间件
app.register_listener(server_init, "before_server_start")
app.register_listener(server_clean, "after_server_stop")
app.register_middleware(request_begin, "request")
app.register_middleware(request_end, "response")

# 注册蓝图
app.blueprint(projects)


if __name__ == "__main__":
    app.run(host=config["HOST"], port=config["PORT"],
            workers=config["WORKERS"])
    logger.info("social service start")


