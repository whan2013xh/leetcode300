# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-09-07
    FileName   : projects.py
    Author     : Honghe
    Descreption: 
"""
import time

from sanic.blueprints import Blueprint
from sanic.views import HTTPMethodView
from sanic.response import text
from tortoise import Tortoise
from sanic_ext import openapi
import asyncio

from utils import response_normalize,MongoUtils

projects = Blueprint(
    name="projects",
    url_prefix="/projects",
    # version=1.0,
)

@projects.route("/query_project_sets")
@openapi.description("查询项目配置项,返回平台、语种和系统主题")
@response_normalize
async def query_project_sets(request):
    """
    查询获取项目相关配置；
    平台和语种配置文件配置；
    系统主题从数据库获取
    :param request:
    :return:
    """
    config = request.app.config
    platform = config.get("PLATFORM")
    language = config.get("LANGUAGE")
    mongo_db = request.app.ctx.mongo_db
    mongo_client = request.app.ctx.mongo_client
    collection_name = "feature"
    condition = {
        "typ":0
    }
    loop = mongo_client.get_io_loop()
    loop.run_until_complete(MongoUtils.find_all(mongo_db,collection_name,))
    return "", 200

class Feature:
    name=openapi.String(description="自定义主题名称")
    keywords = openapi.Array(openapi.String(description="关键词"))
    description = openapi.String(description="主题描述")

class ProjectDetail:
    project_name = openapi.String(description="项目名称") # 项目名
    project_type = openapi.Integer(description="项目类型，1：电商评论")
    key_words=openapi.Array(openapi.String(description="关键词"),description="关键词列表")  # 关键词
    except_key_words=openapi.Array(openapi.String(description="关键词"),description="排除关键词列表")# 排除关键词
    platforms=openapi.Array(openapi.Integer(description="平台映射值"),description="数据源平台") # 数据源平台
    language=openapi.Integer(description="语种")  # 语种
    system_topic=openapi.Array(openapi.String(description="关键词"),description="系统主题") # 系统主题
    topic=openapi.Array(Feature,description="自定义主题")  # 自定义主题，没有传空{}
    user = openapi.String(description="用户名")


@projects.route("/create_project",methods=["POST"])
@openapi.description("项目新建接口")
# @openapi.parameter("authorization", str, "header", description="测试专用，默认值为test@tuya.com.Y4aC9HsxfPdECrf78injor8c9Uo")
@openapi.body({ "application/json" : ProjectDetail})
@response_normalize
async def create_project(request):
    """
    项目新建接口
    1、先插入自定义主题；
    2、再插入项目表
    :param request:
    :return:
    """
    data = request.json
    topic_data = data.get("topic")
    gmt_create = int(time.time()*1000)
    topic_typ = 1
    user_name = data.get("user")
    set_topic=[]
    # 构建自定义主题数据
    for item in topic_data:
        item["gmt_create"] = gmt_create
        item["typ"] = topic_typ
        item["user"] = user_name
        item["deleted_at"] = 0
        set_topic.append(item.get("name"))

    # 项目详情
    project_data = {
        "gmt_create":gmt_create,
        "user":user_name,
        "name":data.get("project_name"),
        "typ":data.get("project_type"),
        "platforms":data.get("platforms"),
        "keywords":data.get("key_words"),
        "exkeywords":data.get("except_key_words"),
        "language":data.get("language"),
        "features":data.get("system_topic")+set_topic
    }

    mongo_db = request.app.ctx.mongo_db
    mongo_client = request.app.ctx.mongo_client

    # loop = asyncio.get_event_loop()
    flag = False
    # loop = asyncio.get_event_loop()
    # loop.run_until_complete(MongoUtils.do_insert_one(mongo_db,"topic",project_data))
    # feature_result = await mongo_db.feature.insert_many(topic_data)
    # topic_result = await mongo_db.topic.insert_one(project_data)
    async with await mongo_db.client.start_session() as s:
        async with s.start_transaction():
            # inserted_result = loop.run_until_complete(MongoUtils.insert_many(mongo_db,collection_name="topic"))
            feature_result = await mongo_db.feature.insert_many(topic_data, session=s)
            topic_result = await mongo_db.topic.insert_one(project_data, session=s)
            print(f"feature_result:{feature_result.inserted_ids},topic_result:{topic_result.inserted_id}")
            if feature_result and topic_result.inserted_id:
                flag = True
    #     s.commit_transaction()

    return {"data":{"create_flag":flag},"msg":f"新建项目结果{flag}"}


@projects.route("/query_project_name")
@openapi.description("查询项目名称")
@openapi.parameter("user_name",str,location="query")
@openapi.parameter("project_name",str,location="query")
@response_normalize
async def query_project_name(request):
    """
    项目查重
    :param request:
    :return:
    """
    data = request.args
    pass









    







