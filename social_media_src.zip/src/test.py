# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-09-13
    FileName   : test.py
    Author     : Honghe
    Descreption: 
"""
import pymongo
from utils import config
from motor import motor_asyncio
import asyncio


mongoDB_url = f"mongodb://{config['MONGODB'].get('MONGODB_USER')}:{config['MONGODB'].get('MONGODB_PASSWORD')}@{config['MONGODB'].get('MONGODB_HOST')}"
# mongoDB_url = f"mongodb://{config['MONGODB'].get('MONGODB_USER')}:{config['MONGODB'].get('MONGODB_PASSWORD')}@{'172.16.248.111:27017'}"
mongo_client = motor_asyncio.AsyncIOMotorClient(mongoDB_url)
db_name = config['MONGODB'].get('MONGODB_DB_NAME')
mongo_db = mongo_client.get_database(db_name)
# myclient = pymongo.MongoClient(mongoDB_url)
# mydb = myclient[db_name]
# collist = mydb. list_collection_names()
# if "topic" in collist:   # 判断 sites 集合是否存在
#   print("集合已存在！")

topic_data = {
  "except_key_words": [
    "string"
  ],
  "key_words": [
    "string"
  ],
  "language": 0,
  "platforms": [
    0
  ],
  "project_name": "string",
  "project_type": 0,
  "system_topic": [
    "string"
  ],
  "topic": [
    {
      "description": "string",
      "keywords": [
        "string"
      ],
      "name": "string"
    }
  ],
  "user": "string"
}
# mycol = mydb["topic"]
# x = mycol.insert_one(topic_data)

# print(x.inserted_id)
async def do_insert():
    topic_result = await mongo_db.topic.insert_one(topic_data)
    print(topic_result)

async def do_find_one():
    n = await mongo_db.topic.count_documents({})
    print(n)
    document = await mongo_db.topic.find_one({'name': 'string'})
    print(document)


loop = asyncio.get_event_loop()
collections = mongo_db.list_collection_names()
loop.run_until_complete(do_find_one())