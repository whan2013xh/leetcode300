# -*- coding: utf-8 -*-
"""
    CreatedDate: 2022-09-07
    FileName   : mention.py
    Author     : Honghe
    Descreption: 
"""

from tortoise import Model, fields


class Mention(Model):
    dt = fields.DatetimeField()
    topicid = fields.CharField(25)
    target = fields.CharField(255)
    dataid = fields.CharField(25)
    tokens = fields.TextField()
    indexes = fields.TextField()
    strategy = fields.IntField()
    typ = fields.IntField()
    platform = fields.IntField()
    spid = fields.CharField(255)
    author = fields.CharField(50)
    priclsfy = fields.CharField(50)
    keyphrase = fields.TextField()
    hashtag = fields.TextField()
    category = fields.TextField()
    gmt_create = fields.BigIntField()

    def __str__(self):
        return f"I am {self.topicid}"

