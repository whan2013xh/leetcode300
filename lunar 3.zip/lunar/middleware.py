import time

from lunar.app import app
from lunar.db import db
from lunar.utils import remove_file, connect_db, close_db
from lunar.logger import logger


@app.middleware('request')
async def db_connect(request):
    # 增加开始时间
    request.headers['start_time'] = time.time()
    # 开启数据库链接
    connect_db(db)


@app.middleware('response')
async def db_close(request, response):
    # 关闭数据库链接
    close_db(db)
    # 删除增加的 用户信息
    request.headers.pop("user", None)
    request.headers.pop("jobNo", None)
    # 删除临时文件
    file_path = request.headers.get("tmp_file_path", "")
    remove_file(file_path)
    # 记录请求信息
    start_time = request.headers.get('start_time')
    if start_time is None:
        spend_time = ""
    else:
        spend_time = round((time.time() - start_time) * 1000, 2)
    logger.info(f"{ response.status } { request.method } { request.path } { request.query_string } { spend_time }ms")
