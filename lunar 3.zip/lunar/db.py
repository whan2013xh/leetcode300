from peewee import MySQLDatabase
import pymongo
from lunar.config import config
import pymysql

app_name = config["name"]
database_name = config["database_name"]
mysql_user = config["mysql_user"]
mysql_password = config["mysql_password"]
mysql_host = config["mysql_host"]
mysql_port = config["mysql_port"]

# mongo_user = config["mongo_user"]
# mongo_password = config["mongo_password"]
# mongo_host = config["mongo_host"]
# mongo_port = config["mongo_port"]

es_hosts = config["es_hosts"]
es_index_prefix = config["es_index_prefix"]
es_type = config["es_type"]


def init_database():
    with pymysql.connect(host=mysql_host,
                         port=mysql_port,
                         user=mysql_user,
                         password=mysql_password,
                         charset='utf8mb4',
                         cursorclass=pymysql.cursors.DictCursor) as cur:
        cur.execute("show databases")
        databases = [x["Database"] for x in cur.fetchall()]
        if database_name in databases:
            pass
        else:
            sql = f"create database {database_name}"
            cur.execute(sql)


# init_database()
db = MySQLDatabase(database_name, user=mysql_user, password=mysql_password,
                   host=mysql_host, port=mysql_port, charset='utf8mb4', autoconnect=False)



