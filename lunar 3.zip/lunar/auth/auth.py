from datetime import datetime
from functools import wraps
from lunar.models import User, Role, Group, GroupUser
from itsdangerous import Signer
from lunar.config import config
from lunar.logger import logger
import casbin
import json
import time

from lunar.db import db

signer = Signer(config["secret_key"])

enforcer = casbin.Enforcer("lunar/auth/model.conf", "lunar/auth/policy.csv")


def create_group_user(name, sso_email, allow_sso=True):
    flag = True
    user = None
    with db.atomic() as transaction:
        try:
            # 创建用户
            role = Role.get_or_none(Role.name == "demander")
            # 日期
            cur_time = int(time.time() * 1000)
            # 创建组和用户

            user_info = {
                "name": name,
                "defaults": {
                    "role": role, "allow_sso": allow_sso, "sso_email":
                        sso_email, "gmt_create": cur_time, "gmt_modified": cur_time}
            }
            user, _ = User.get_or_create(**user_info)
            # 创建组
            group_info = {
                "name": name,
                "defaults": {"gmt_create": cur_time, "gmt_modified": cur_time, "info": "auto create group",
                             "last_operator_id": user.id, "is_private": 1}
            }
            group, _ = Group.get_or_create(**group_info)
            # 创建组和用户的映射
            group_user_info = {
                "group": group, "user": user,
                "defaults": {"gmt_create": cur_time, "gmt_modified": cur_time, "last_operator_id": user.id}
            }
            GroupUser.get_or_create(**group_user_info)
        except Exception as e:
            transaction.rollback()
            logger.info(e)
            flag = False, None
    return flag, user


def token_auth(request):
    """
    测试开发鉴权流程，读取请求头中authorization字段信息
    :param request:
    :return:
    """
    flag = True
    try:
        username = signer.unsign(request.headers["authorization"])
        # 这个用户名是明文的话不能在控制台打印输出，存在安全风险
        logger.info(username)

        user = User.get_or_none(User.name == username)
        if user is None:
            flag, user = create_group_user(username, "", allow_sso=False)
        if flag:
            request.headers["user"] = user
        update_login_time(user)
    except Exception as e:
        logger.info(e)
        flag = False
        return None
    return user.to_dict()


def update_login_time(user):
    login_time = user.gmt_modified
    cur_day = int(time.mktime(datetime.now().date().timetuple())) * 1000
    if login_time < cur_day:
        user.gmt_modified = cur_day
        user.save()

def ai_sso_auth(request):
    """
    算法平台鉴权
    :param request:
    :return:
    """
    flag = True

    sso_email = request.headers["ai-userid"]
    logger.info(sso_email)
    user = User.get_or_none(User.sso_email == sso_email)

    if user is None:
        flag, user = create_group_user(sso_email.split("@")[0], sso_email)
    if flag:
        request.headers["user"] = user
    update_login_time(user)
    request.headers["jobNo"] = sso_email.split("@")[0]
    return user.to_dict()


def sso_auth(request):
    """
    如果使用sso访问后端，如果该操作人员还未在用户表，则创建
    """
    flag = True

    sso_user = json.loads(request.headers["tuya_employee"])
    sso_email = sso_user["email"]
    logger.info(sso_email)
    user = User.get_or_none(User.sso_email == sso_email)
    if user is None:
        flag, user = create_group_user(sso_user["name"], sso_user["email"])
    if flag:
        request.headers["user"] = user
        request.headers["jobNo"] = sso_user["jobNo"]
    update_login_time(user)
    return user.to_dict()


def login(request):
    """
    登陆鉴权分发，根据不同的登陆用户进行不同的权限鉴权，authorization是测试开发登陆鉴权
    :param request:
    :return:
    """
    if "ai-userid" in request.headers:
        logger.info("ai sso_check")
        return ai_sso_auth(request)
    elif "tuya_employee" in request.headers:
        logger.info("tuya sso_check")
        return sso_auth(request)
    elif "authorization" in request.headers:
        logger.info("token_check")
        return token_auth(request)
    else:
        return None


def check_request_for_authorization_status(request):
    # Note: Define your check, for instance cookie, session.
    if "authorization" in request.headers:
        try:
            username = signer.unsign(request.headers["authorization"])
            logger.info(username)
            request.headers["user"] = User.get(User.name == username)
            flag = True
        except Exception as e:
            logger.error(e)
            flag = False
        return flag
    else:
        return False


def auth_check(request):
    user = request.headers["user"]
    role = user.role.name
    url = request.path
    method = request.method
    is_allowed = enforcer.enforce(role, url, method)
    logger.info(f"casbin is allowed : {is_allowed}")
    return is_allowed


def authorized(f):
    @wraps(f)
    async def decorated_function(request, *args, **kwargs):

        user = login(request)
        if user is not None:
            is_allowed = auth_check(request)
            if is_allowed:
                response = await f(request, *args, **kwargs)
                return response
            else:
                return {'msg': 'not authorized'}, 200
        else:
            return {'msg': 'not authorized'}, 200

    return decorated_function


def admin(f):
    @wraps(f)
    def decorated_function(request, *args, **kwargs):
        # run some method that checks the request
        # for the client's authorization status
        is_authorized = check_request_for_authorization_status(request)

        if is_authorized:
            if request.headers["user"].role.name == "admin":
                response = f(request, *args, **kwargs)
                return response
            else:
                return {'msg': 'not authorized'}, 200
        else:
            # the user is not authorized.
            return {'msg': 'not authorized'}, 200

    return decorated_function
