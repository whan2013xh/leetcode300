import os
from yaml import load, dump
try:
    from yaml import CLoader as Loader, CDumper as Dumper
except ImportError:
    from yaml import Loader, Dumper

with open("./config/config.yaml") as f:
    config_set = load(f, Loader=Loader)

env_name = os.getenv("LUNAR_ENV", "dev")
# env_name = os.getenv("LUNAR_ENV", "local")
# env_name = os.getenv("LUNAR_ENV", "test")

config = config_set[env_name]

# ROOT_PATH
import pathlib
ROOT_PATH = pathlib.Path(__file__).parents[1]
