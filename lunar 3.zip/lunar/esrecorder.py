# -*- coding: utf-8 -*-
"""
-------------------------------------------------
File Name：      esrecorder
Description :
Author :         Liu Cheng
Date：           2020/4/1
Change Activity: 2020/4/1:
-------------------------------------------------
"""

from elasticsearch import Elasticsearch


class ESRecorder(object):
    def __init__(self, hosts=['localhost'], index="qa", doc_type="_doc"):
        self.index = index
        self.doc_type = doc_type
        self.es = Elasticsearch(hosts, maxsize=25)

    def add(self, doc_id, doc):
        '''
        Adds or updates a typed JSON document in a specific index, making it searchable.
        @param doc_id: Document ID;
        @param doc: JSON document;
        '''
        res = self.es.index(index=self.index, doc_type=self.doc_type, id=doc_id, body=doc)

        return res

    def delete(self, doc_id):
        '''
        Delete a typed JSON document from a specific index based on its id.
        @param doc_id: The document ID
        '''
        res = self.es.delete(index=self.index, id=doc_id)

        return res

    def get(self, doc_id):
        '''
        Get a typed JSON document from the index based on its id.
        @param doc_id: The document ID
        '''
        res = self.es.get(index=self.index, doc_type="_doc", id=doc_id)

        return res

    def mget(self, body):
        '''
        Get multiple documents based on an index, type (optional) and ids.
        @param body: Document identifiers; can be either docs (containing full document information)
                    or ids (when index and type is provided in the URL.

        '''
        return self.es.mget(index=self.index, body=body)

    def search(self, body, **kwargs):
        '''
        Execute a search query and get back search hits that match the query.
        @param body: The search definition using the Query DSL
        '''
        res = self.es.search(index=self.index, body=body, **kwargs)

        return res

    def msearch(self, body):
        '''
        Execute several search requests within the same API.
        @param body:The request definitions (metadata-search request definition pairs),
                    separated by newlines
        '''
        res = self.es.msearch(index=self.index, body=body)

        return res

    def update(self, doc_id, doc):
        '''
        Updates a typed JSON document in a specific index, making it searchable.
        @param doc_id:The document ID
        @param doc: JSON document
        '''
        return self.add(doc_id, doc)

    def info(self):
        '''
        Get the basic info from the current cluster.
        '''
        return self.es.info()
