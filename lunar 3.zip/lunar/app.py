# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-05-21
    FileName: app.py
    Author: Mustom
    Descreption: 
"""
import os
from sanic import Sanic
from lunar.logger import logger, InterceptHandler
from sanic import log
from tuya_ai_trace_sanic import SanicTracing
from lunar.utils import handle_exception
from lunar.config import config
from lunar.fileio import check_dir

d = log.LOGGING_CONFIG_DEFAULTS
d['handlers']["console"]['class'] = 'lunar.logger.InterceptHandler'
d['handlers']["error_console"]['class'] = 'lunar.logger.InterceptHandler'
d['handlers']["access_console"]['class'] = 'lunar.logger.InterceptHandler'
del d['handlers']["console"]["stream"]
del d['handlers']["error_console"]["stream"]
del d['handlers']["access_console"]["stream"]


def create_app():
    app = Sanic("lunar", log_config=d)
    return app


app = create_app()
# SanicTracing(app)
# 注册错误处理器
# app.error_handler.add(Exception, handle_exception)
# 创建静态文件路由
static_file_dir = os.path.join(config["data_dir"], config["file_dir"])
check_dir(static_file_dir)
app.static("/files", static_file_dir, stream_large_files=True)
