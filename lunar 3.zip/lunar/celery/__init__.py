# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-10-30
    FileName   : __init__.py
    Author     : Mustom
    Descreption: 
"""
# 绝对导入，以免celery和标准库中的celery模块冲突
from __future__ import absolute_import
from celery.backends.redis import RedisBackend

from .app import app as celery_app
from .app import celery_control
from .config import Config
from .task import oss_instances, excel_instances, \
    append_instances, config_task, export_dataset, \
    export_task, delete_dataset, export_snorkel_task, \
    merge_dataset, delete_async_task, web_file_instances, export_rules

celery_backend = RedisBackend(host=Config.result_backend, app=celery_app)

__all__ = [
    "celery_app",
    "celery_control",
    "celery_backend",
    "oss_instances",
    "excel_instances",
    "append_instances",
    "config_task",
    "export_dataset"
]
