# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-10-30
    FileName   : app.py
    Author     : Mustom
    Descreption: 
"""
from __future__ import absolute_import, unicode_literals
from celery import Celery, platforms
from celery.app.control import Control

from lunar.celery.config import Config

# 解决不能用root用户启动问题
platforms.C_FORCE_ROOT = True
# 初始化 celery
app = Celery("lunar_tasks")
# 添加配置
app.config_from_object(Config)

celery_control = Control(app)
