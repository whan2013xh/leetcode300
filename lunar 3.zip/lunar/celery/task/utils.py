# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-11-12
    FileName   : utils.py
    Author     : Mustom
    Descreption: 
"""
from collections import defaultdict
import os
import json
from functools import wraps
import time
import math
import ast

import celery
import requests
# from tuya_ai_trace_requests import requests

from lunar.db import db
from lunar.config import config
from lunar.fileio import TmpFile
from lunar.mio import OssFile
from lunar.utils import connect_db, close_db, execute_time
from lunar.logger import logger
from lunar.models import DataSet, LabelTask, AsyncTask, LabelNode


def rebuild_text_result(instance, task_type):
    """
    重构 文本结果
    """
    if instance["data_set_type"] == "text":
        text = instance["data"]["text"]
        label_node_id = instance["label_node_id"]

        label_data = instance["label_data"]

        if task_type == "text_classify":
            # label = "None" if label_data.get("node_n") else label_data.get("label")
            return {"text": text, "label": label_data.get("label"), "slot":label_data.get("slot"),"node_id": label_node_id}
        elif task_type == "text_sequence":
            slot = json.dumps({st["slot"]: {"value": st["value"].strip(), "range": st["range"]} for st in label_data["slots"]}, ensure_ascii=False)
            return {"text": text, "slot": slot, "node_id": label_node_id}
        elif task_type == "reapu":
            label = label_data.get("label")
            label = "None" if label is None or label == "none" else label
            slot = json.dumps({st["slot"]: {"value": st["value"].strip(), "range": st["range"]} for st in label_data["slots"]}, ensure_ascii=False)
            return {"text": text, "label": label, "slot": slot, "node_id": label_node_id}

        return text, label_node_id

    return instance


def rebuild_image_result(instance, task_type):
    """
    重构 图片结果
    """
    # 2D_rect（矩形框）、key_point（关键点）、image_attr（属性）、semantic_seg（多边形）
    # 新的结构
    if instance["data_set_type"] in ["image", "video"] :
        source_data = instance["data"]
        label_node_id = instance["label_node_id"]
        label_data = instance["label_data"]

        field_data = label_data.get("data")

        # filename = os.path.basename(source_data["path"])
        filename = source_data["path"]
        base = {
            "label_node_id": label_node_id
        }
        
        tmp = []
        if task_type in ["2D_rect", "OCR_2D_rect","video_2D_rect"] and field_data is not None:
            for item in field_data:
                data = {}
                data.update(base)
                bbox = item.pop("bbox")
                data["bbox"] = {"left": bbox[0][0], "top": bbox[0][1],
                                "right": bbox[2][0], "bottom": bbox[2][1]}
                data["segmentation"] = item.pop("segmentation", []) \
                                        if item.pop("segmentation", []) else []
                data["point"] = item.pop("point", []) if item.pop("point", []) else []
                data["text"] = item.pop("text", [])
                item.pop("raw", [])
                data.update(item)

                tmp.append(data)
        elif task_type in ["semantic_seg", "OCR_semantic_seg", "video_semantic_seg"] and field_data is not None:
            for item in field_data:
                data = {}
                data.update(base)
                data["segmentation"] = sum(item.pop("segmentation", []), [])
                data["point"] = item.pop("point", []) if item.pop("point", []) else []
                data["bbox"] = item.pop("bbox", {}) if item.pop("bbox", {}) else {}
                data["text"] = item.pop("text", [])
                data.update(item)

                tmp.append(data)
        elif task_type in ["key_point", "video_key_point"] and field_data is not None:
            data = {}
            data.update(base)
            data["point"] = field_data
            data["segmentation"] = label_data.pop("segmentation", []) \
                                    if label_data.pop("segmentation", []) else []
            data["bbox"] = label_data.pop("bbox", {}) \
                                    if label_data.pop("bbox", {}) else {}
            label_data.pop("data", [])
            data.update(label_data)

            tmp.append(data)
        elif task_type in ["image_attr", "video_image_attr"] and field_data is not None:
            for item in field_data:
                item.update(base)
                tmp.append(item)
        
        return {filename: tmp}
    
    return instance


def get_task_by_id(task_id):
    with db.atomic():
        return LabelTask.get_or_none(LabelTask.id == task_id)


def dataset_success(dataset_id):
     with db.atomic():
        data_set = DataSet.get_by_id(dataset_id)
        data_set.execute_success()


def dataset_error(data_set, error_message):
     with db.atomic():
        data_set.execute_error(error_message)


def create_instances(data_set, instances):
    res = {}
    with db.atomic() as transaction:
        try:
            res = data_set.create_and_combine_instances(instances)
            data_set.execute_success()
        except Exception as e:
            data_set.execute_error(e)
            logger.error(e)
            transaction.rollback()
            return 0
    return res.get("insert_num", 0)


def get_dataset_by_id(data_set_id):
    with db.atomic():
        return DataSet.get_or_none(DataSet.id == data_set_id)


def change_ats(async_task_id, status, msg):
    """
    改变异步任务状态
    """
    connect_db(db)
    with db.atomic():
        update_data = {"status": status, "error_message": msg, "gmt_modified": int(time.time() * 1000)}
        AsyncTask.update(update_data).where(AsyncTask.id == async_task_id).execute()
    close_db(db)


class LunarTask(celery.Task):
    def after_return(self, status, retval, task_id, args, kwargs, einfo):
        logger.info(f"task execute after: name={ self.__qualname__ }, async_id={ task_id }, args={ args }")
        ## 获取返回结果信息
        flag, msg = (False, retval) if retval is not None else (True, "")
        ## 回写数据库
        async_task_id = kwargs.get("atid")
        if async_task_id:
            change_ats(async_task_id, status, msg)
        ## 企业微信发送消息
        # 初始化 WeChatHandler
        info = kwargs.pop("info", {})
        wc_handler = WeChatHandler(info.get("user_id", "honghe.xu@tuya.com"), info.get("task_name", ""))
        # # 发送微信通知
        response = wc_handler.send(flag, msg)
        # url_token = config["text_parser_token"]
        # message_send_url = config.get("message_send_url")
        # _headers = {
        #     "authorization": f"Bearer {url_token}"
        # }
        # start = time.time()
        # send_message = {
        #     "text": info.get("task_name"),
        #     "user": info.get("user_id")
        # }
        # response = requests.post(message_send_url, json=send_message, headers=_headers)
        # logger.info(f"response: {round((time.time() - start) * 1000, 2)}ms, {response.text}")
        webhook = info.get("webhook")
        hock_info = {
            "async_task_id": async_task_id,
            "status": status,
            "error_message": msg
        }
        if webhook:
            hook_url = webhook.get("url") if isinstance(webhook,dict) else ast.literal_eval(webhook).get("url")
            requests.post(hook_url, json=hock_info)
            logger.info(f"send hook request: {hook_url}")
        status_code = response.status_code
        if status_code != 200:
            return None, response.text
        logger.info(response)
        result = response.text
        try:
            result = json.loads(result)
            success = result.get("errcode")
            if success:
                return None, f"send wechat failure: msg [{msg}]"
        except Exception as e:
            return None, str(e)

        logger.info(f"send wechat info: flag [{ flag }], msg [{ msg }]")
        return True, None

    def on_success(self, retval, task_id, args, kwargs):
        logger.info(f"task execute success: name={ self.__qualname__ }, async_id={ task_id }, args={ args }")
        return super().on_success(retval, task_id, args, kwargs)
    
    def on_failure(self, exc, task_id, args, kwargs, einfo):
        logger.info(f"task execute failure: name={ self.__qualname__ }, async_id={ task_id }, args={ args }")
        return super().on_failure(exc, task_id, args, kwargs, einfo)


def logger_begin_end(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # 日志信息
        task = args[0]
        task_id = task.request.id
        task_args = task.request.args
        logger.info(f"Begin: id={ task_id }, args={ task_args }")

        # 链接数据库
        connect_db(db)
        result = func(*args, **kwargs)
        # 关闭数据库
        close_db(db)

        logger.info(f"End: id={ task_id }, args={ task_args }")
        return result

    return wrapper


def get_image_result(task_id, data_set_type, task_type, count, limit=1000):
    """
    获取图片结果
    """
    result = {}
    pages = math.ceil(count / limit)
    logger.info(f"Get task [{task_id}] data, total count [{count}] records, pages [{pages}]")

    for page in range(pages):
        logger.info(f"Cycle get task [{task_id}], page [{page}, ]")
        offset = page * limit
        nodes = LabelNode.select_nodes(
            task_id=task_id, is_labeled=True, data_disqualified=False, fields=["id", "data", "label_data"]
        ).order_by(LabelNode.id.desc()).limit(limit).offset(offset)

        for node in nodes:
            instance = {
                "label_node_id": node.id,
                "data": node.data.data,
                "label_data": node.label_data,
                "data_set_type": data_set_type
            }
            instance = rebuild_image_result(instance, task_type)
            result.update(instance)
    logger.info(f"End Get task [{task_id}] data ...")
    return result


def get_text_result(task, nodes):
    """
    获取结果
    """
    instances = []
    data_set_type = task.data_set.data_set_type.name
    task_type = task.task_type.name
    for node in nodes:
        instance = {
            "label_node_id": node.id,
            "data": node.data.data, 
            "label_data": node.label_data,
            "data_set_type": data_set_type
        }
        instance = rebuild_text_result(instance, task_type)
        instances.append(instance)
    return instances


def get_result(task, nodes):
    """
    获取结果
    """
    instances = []
    data_set_type = task.data_set.data_set_type.name
    for node in nodes:
        instance = {
            "label_node_id": node.id,
            "text": node.data.data.get("text"),
            "label_data": node.label_data,
            "data_set_type": data_set_type,
            "task_type": task.task_type.name
        }
        instances.append(instance)
    return instances


def export_json(data, file_path):
    """
    导出为json
    """
    # 将数据转换为 bytes 格式
    str_data = json.dumps(data, ensure_ascii=False, indent=4)
    bytes_data = bytes(str_data, encoding="utf-8")
    # 将数据写入文件
    oss_file = OssFile()
    content_type = "application/octet-stream"

    return oss_file.put_object(config["minio_bucket"], file_path, bytes_data, content_type)


def export_excel(input_data, file_path):
    """
    导出为excel
    """
    instances = input_data.get("instances")
    task_name = input_data.get("name")
    # 重构数据
    if not instances:
        data = {}
    else:
        logger.info("===========")
        logger.info(instances)
        instance = instances[0]
        keys = instance.keys()
        data = defaultdict(list)
        for key in keys:
            data[key].extend([ie[key] for ie in instances])
    # 生成临时文件名称
    _, ext = os.path.splitext(file_path)
    tmp_name = f"{ task_name }_{ int(time.time() * 1000) }.{ext}"
    # 创建临时文件
    tmp_file = TmpFile(tmp_name)
    err = tmp_file.write_excel(data)
    if err is not None:
        return err
    # 上传至minio
    err = OssFile().fput_object(
        config["minio_bucket"], file_path, tmp_file.file_path,
        content_type="application/octet-stream"
    )
    # 删除临时文件
    # tmp_file.remove()
    
    return err


def text_data_file_trans(df, field, duplicate=True):
    # 去重
    if not duplicate:
        df = df.drop_duplicates([field])
    # 修改插入数据集实例值为非字符串报错的bug
    df["data"] = df.apply(lambda x: {field: str(x[field])}, axis=1)
    extra_field = [x for x in df.columns if x not in [field, "data"]]
    if not extra_field:
        return df
    df["extra_info"] = df.apply(lambda x: x[extra_field].to_dict(), axis=1)
    return df


def loop_paths(bucket, path, level=0, count=0, dir_count=0, video_frame=False):
    result = []

    objs = OssFile().get_paths(bucket, prefix=path)
    for obj in objs:
        if level == 0:
            dir_count += 1

        path = obj.object_name
        if not obj.is_dir:
            if obj.object_name.endswith(".json"):
                continue
            if obj.object_name.endswith(".csv"):
                continue
            if obj.object_name.endswith(".py"):
                continue
            path_info = {"data": {"path": os.path.join("/", bucket, path)}}
            if video_frame:
                path_info["frame_index"] = int(os.path.basename(path).split('.')[0])
            result.append(path_info)
            count += 1
            continue
        paths, count = loop_paths(bucket, path, level=level+1, count=count, dir_count=dir_count, video_frame=video_frame)
        result.extend(paths)
    
    return result, count


class WeChatHandler(object):
    _url = "http://basic.tuya-inc.com:7007/qywx.do"

    _headers = {
        "Tuya-Intranet": "Tuya@intranet@2018",
        "Content-Type": "application/x-www-form-urlencoded"
    }

    _base = "xxx项目：标注平台\n" + \
            "任务名称：{}\n" + \
            "执行状态：{}\n" + \
            "错误信息：{}\n" + \
            "项目地址：<https://ai.wgine-dev.com:7799/sora-online/>"

    def __init__(self, user_id, task_name):
        self.user_id = str(user_id) if user_id else "honghe.xu@tuya.com"
        self.task_name = str(task_name)

    # def send(self, flag, message):
    #     status = "成功" if flag else "失败"
    #     msg = self._base.format(self.task_name, status, str(message))
    #     body = {
    #         "do": "message",
    #         "opt": "sendMessage",
    #         "agentId": "1000006",
    #         "message": msg,
    #         "toUser": self.user_id
    #     }
    #     requests.post(self._url, data=body, headers=self._headers)

    def send(self, flag, message):
        status = "成功" if flag else "失败"
        msg = self._base.format(self.task_name, status, str(message))
        url_token = config["text_parser_token"]
        message_send_url = config.get("message_send_url")
        _headers = {
            "authorization": f"Bearer {url_token}"
        }
        send_message = {
            "text": msg,
            "user": self.user_id
        }
        logger.info(f"sss {self.user_id}")
        response = requests.post(message_send_url, json=send_message, headers=_headers)
        return response

def execute_time(func):
    # 定义嵌套函数，用来打印出装饰的函数的执行时间
    def wrapper(*args, **kwargs):
        # 定义开始时间和结束时间，将func夹在中间执行，取得其返回值
        start = time()
        func_return = func(*args, **kwargs)
        end = time()
        # 打印方法名称和其执行时间
        print(f'{func.__name__}() execute time: {end - start}s')
        # 返回func的返回值
        return func_return

    # 返回嵌套的函数
    return wrapper
