# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-11-12
    FileName   : export_task.py
    Author     : Mustom
    Descreption: 
"""
import os
import json
import time
from itertools import groupby

from ..app import app
from .utils import get_dataset_by_id, get_result, \
    get_task_by_id, logger_begin_end, LunarTask, \
    get_image_result, export_json, export_excel, \
    get_text_result

from lunar.db import db
from lunar.models import LabelNode, LabelRule, NodeStatus, LabelTask
from lunar.config import config
from lunar.logger import logger
from lunar.fileio import TmpFile, YamlIO
from lunar.mio import OssFile
from lunar.data import get_pre_label_data, PreLabelData
from lunar.nlp.autolabel.label_data import snorkel_predict_pd


base_dir = os.path.join(config["data_dir"], config["file_dir"])
export_excel_types = ["text", "qa-top10"]
export_json_types = ["image", "voice", "video"]


@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def export_dataset(self, dataset_id, file_path, info=None, atid=None):
    """
    导出数据集
    """
    celery_id = self.request.id

    # 获取 数据集对象
    dataset = get_dataset_by_id(dataset_id)
    if dataset is None:
        msg = "数据集不存在"
        logger.info(f"Error: id={ celery_id }, { msg }")
        raise Exception(msg)
    
    data = {
        "name": dataset.name,
        "type": dataset.data_set_type.name
    }
    instances = []
    with db.atomic():
        dataset_instances = dataset.instances
        count = len(dataset_instances)
        logger.info(f"Info: id={ celery_id }, start export instance, count={ count }")
        for instance in dataset_instances:
            instances.append({
                "data_id": instance.id,
                "data": instance.data
            })
        logger.info(f"Info: id={ celery_id }, end export instance, count={ count }")
    data["instances"] = instances
    # 将数据转换为 bytes 格式
    str_data = json.dumps(data, ensure_ascii=False, indent=4)
    bytes_data = bytes(str_data, encoding="utf-8")
    # 将数据写入文件
    oss_file = OssFile()
    content_type = "application/octet-stream"

    logger.info(f"Info: id={ celery_id }, start put object")
    err = oss_file.put_object(config["minio_bucket"], file_path, bytes_data, content_type)
    logger.info(f"Info: id={ celery_id }, end put object")
    if err is not None:
        logger.info(f"Error: id={ celery_id }, { err }")
        raise Exception(err)
    return None

@app.task(bind=True, base=LunarTask)
@logger_begin_end
def export_task(self, task_id, file_path, atid=None, info=None):
    """
    导出标注数据
    """
    celery_id = self.request.id

    # 获取 任务对象
    task = get_task_by_id(task_id)
    if task is None:
        msg = "标注任务不存在"
        logger.info(f"Error: id={ celery_id }, { msg }")
        raise Exception(msg)
    
    data = {
        "name": task.name,
        "task_type": task.task_type.name,
        "data_set_id": task.data_set_id
    }
    # 获取所有的task数据
    instances = []
    # 获取任务标注数据
    data_set_type = task.data_set.data_set_type.name
    with db.atomic():
        nodes = LabelNode.select_nodes(
            task_id=task.id, is_labeled=True, data_disqualified=False
        )
        # 筛选掉质检错误的节点
        nodes = nodes.where((LabelNode.status != NodeStatus.CHECK_ERROR.value) & (LabelNode.status != NodeStatus.CUT_WORD_ERROR.value))
        count = nodes.count()
        logger.info(f"Info: id={ celery_id }, start export node, count={ count }")

        if data_set_type == "image" or data_set_type == "video":
            instances = [get_image_result(task_id, data_set_type, task.task_type.name, count)]
        elif data_set_type == "text":
            instances = get_text_result(task, nodes)
        else:
            instances = get_result(task, nodes)
        logger.info(f"Info: id={ celery_id }, end export node, count={ count }")
    data["instances"] = instances
    # 根据导出类型，组织数据
    logger.info(f"Info: id={ celery_id }, start put object")
    if data_set_type in export_json_types:
        err = export_json(data, file_path)
    elif data_set_type in export_excel_types:
        err = export_excel(data, file_path)
    else:
        err = "export type not support"
    logger.info(f"Info: id={ celery_id }, end put object")
    if err is not None:
        logger.info(f"Error: id={ celery_id }, { err }")
        raise Exception(err)
    return None


@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def export_snorkel_task(self, task_id, file_path, atid=None, info=None):
    """
    导出规则标注数据
    """
    celery_id = self.request.id

    # 获取 任务对象
    task = get_task_by_id(task_id)
    if task is None:
        msg = "标注任务不存在"
        logger.info(f"Error: id={ celery_id }, { msg }")
        raise Exception(msg)
    
    # 第一步，获取数据
    logger.info(f"Info: id={ celery_id }, get origin data")
    task_data = task.get_origin_data()
    # 第二步，获取规则
    logger.info(f"Info: id={ celery_id }, get rules")
    rules = task.get_rules()
    rules = [x.to_dict() for x in rules]
    # 第三步，获取标签
    logger.info(f"Info: id={ celery_id }, get labels")
    labels = task.get_labels()
    # 第四步骤，打标
    logger.info(f"Info: id={ celery_id }, snorkel data")
    prioritys = task.get_priority()
    preds, probs, seg_list, hits = snorkel_predict_pd(rules, labels, task_data, use_model=False, prioritys=prioritys)
    # 第五步，组织返回数据
    data = {
        "text": task_data,
        "label": preds,
        "probability": [max(prob) if len(set(prob)) != 1 else -1 for prob in probs] if prioritys is None or not prioritys else probs,
        "hits": [{k: [x[1] for x in v] for k, v in groupby(sorted(ld, key=lambda x: x[0]), key=lambda x: x[0])} for ld in hits],
        "segment": [" ".join(seg) for seg in seg_list]
    }
    # 生成临时文件
    _, ext = os.path.splitext(file_path)
    suffix = ext.replace('.', '')

    logger.info(f"Info: id={ celery_id }, build tmp file")
    tmp_file = TmpFile(f"snorkel_{ int(time.time() * 1000) }{ ext }")
    tmp_file.write(data, type=suffix)
    # 将数据写入文件
    oss_file = OssFile()
    content_type = "application/octet-stream"

    logger.info(f"Info: id={ celery_id }, start put file")
    err = oss_file.fput_object(config["minio_bucket"], file_path, tmp_file.file_path, content_type)
    logger.info(f"Info: id={ celery_id }, end put file")
    if err is not None:
        logger.info(f"Error: id={ celery_id }, { err }")
        raise Exception(err)
    # 删除临时文件
    logger.info(f"Info: id={ celery_id }, remove tmp file")
    tmp_file.remove()
    
    return None


@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def export_rules(self, task_id, rule_ids, file_path, atid=None, info=None):
    """
    导出数据集
    """
    celery_id = self.request.id

    # 获取 数据集对象
    choose_rules = LabelRule.select().where(LabelRule.task == task_id)
    if rule_ids is not None:
        choose_rules = choose_rules.where(LabelRule.id.in_(rule_ids))
    if choose_rules is None:
        msg = "规则不存在"
        logger.info(f"Error: id={celery_id}, {msg}")
        return msg

    rules = []
    count = choose_rules.count()
    logger.info(f"Info: id={celery_id}, start export rules, count={count}")
    for rule in choose_rules:
        rules.append({
            "num": rule.id,
            "type": rule.type,
            "match_label": rule.match_label,
            "not_match_label": rule.not_match_label,
            "contain": rule.params.get("contain"),
            "whether": rule.params.get("whether"),
            "exclude": rule.params.get("exclude")
        })
    logger.info(f"Info: id={celery_id}, end export rules, count={count}")
    # 将数据转换为 bytes 格式
    str_data = YamlIO.write2str(rules)
    bytes_data = bytes(str_data, encoding="utf-8")
    # 将数据写入文件
    oss_file = OssFile()
    content_type = "application/octet-stream"

    logger.info(f"Info: id={celery_id}, start put object")
    err = oss_file.put_object(config["minio_bucket"], file_path, bytes_data, content_type)
    logger.info(f"Info: id={celery_id}, end put object")
    if err is not None:
        logger.info(f"Error: id={celery_id}, {err}")
        raise Exception(err)
    return None

@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def run_rules(self, task_id, file_path, atid=None, info=None):
    # 获取 数据集对象
    choose_rules = LabelRule.select().where(LabelRule.task == task_id)
    task = LabelTask.get_or_none(LabelTask.id == task_id)
    task_type = task.task_type.name
    rules = task.get_rules()
    # 获取标签
    labels = task.get_labels()
    if not labels:
        return {"msg": "task labels not exist"}, 200
    if not isinstance(labels, list):
        return {"msg": "task labels format error"}, 200
    nodes = LabelNode.select().where(LabelNode.task==task_id)
    task_datas = (node.data.data for node in nodes)
    # label_list = [label for label in labels]
    pd = PreLabelData(task_type, rules=rules, labels=labels, use_model=False)
    data, err = pd.get_text_datas(task_datas)
    return data if err is None else [[] for _ in task_datas], None