# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-10-29
    FileName   : async_tasks.py
    Author     : Mustom
    Descreption: 
"""
from __future__ import absolute_import, unicode_literals
import os
import time
# from celery.utils.log import get_task_logger
import pandas as pd
from io import StringIO

from ..app import app
from .utils import loop_paths, text_data_file_trans, \
    logger_begin_end, get_dataset_by_id, create_instances, \
    dataset_error, get_task_by_id, LunarTask, execute_time

from lunar.db import db
from lunar.mio import OssFile
from lunar.models import LabelTaskOperator, User, LabelTask, DataSet, DataInstance
from lunar.fileio import TmpFile, URLFile, Video, write2mio
from lunar.logger import logger


# logger = get_task_logger("lunar_tasks")

@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def oss_instances(self, storage, dataset_id, info=None, atid=None):
    """
    根据oss导入数据
    """
    celery_id = self.request.id

    # 获取 数据集对象
    data_set = get_dataset_by_id(dataset_id)
    if data_set is None:
        msg = "数据集不存在"
        logger.info(f"Error: id={ celery_id }, { msg }")
        raise Exception(msg)
    logger.info(f"Info: id={ celery_id }, oss input to dataset, name={ data_set.name }, type={data_set.data_set_type.name}")

    try:
        bucket = storage["bucket"]
        bucket_path = storage["path"]
        if data_set.data_set_type.name !="video":
            bucket_path = bucket_path if bucket_path.endswith("/") else bucket_path + "/"

            logger.info(f"Info: id={celery_id}, start loop path, bucket={bucket}, path={bucket_path}")
            paths, count = loop_paths(bucket, bucket_path)
            logger.info(f"Info: id={celery_id}, end loop path, bucket={bucket}, path={bucket_path}, count={count}")
        else:
            minio_video_bucket = storage["minio_video_bucket"]
            minio_client = OssFile()
            data = minio_client.get_object(bucket, bucket_path)
            # logger.info(data)
            # logger.info(data.data)
            video_name, extend_name = os.path.splitext(os.path.basename(bucket_path))
            tmp_file = TmpFile(f"{video_name}_{int(time.time() * 1000)}{extend_name}")
            tmp_file.write_video(data.data)
            bucket_path, video_fps = video2frame(tmp_file.file_path, data_set.name, minio_video_bucket)
            if bucket_path is not None:
                paths, count = loop_paths(minio_video_bucket, bucket_path, video_frame=True)
            else:
                return None
            logger.info(f"Info: 视频数据创建id={celery_id}, end loop path, bucket={bucket}, bucket_path={bucket_path}")
            tmp_file.remove()
            data_set.update_instance({"error_message": video_fps})
        create_instances(data_set, paths)
        return None
    except Exception as e:
        logger.info(f"Error: id={ celery_id }, error={ e }")
        dataset_error(data_set, e)
        raise Exception(str(e))


def video2frame(video_src_path, data_set_name, minio_video_bucket, interval=1):
    video_obj = Video(video_src_path)
    success = False
    if video_obj.video_cap.isOpened():
        success = True
    else:
        logger.info("视频读取失败")
        return None, None
    base_file_path = f"video2frame/{data_set_name}"
    # 生成临时文件
    suffix = video_obj.extend_name.replace('.', '')

    # 将数据写入文件
    frame_index = 0
    frame_count = 0
    start = time.time()
    error_count = 0
    while success and frame_index<video_obj.frame_count:
        success, frame = video_obj.video_cap.read()
        if frame_index % interval==0:
            # resize_frame = cv2.resize(frame, (frame_width, frame_height), interpolation=cv2.INTER_AREA)
            frame_path = os.path.join(base_file_path, "%d.jpg"%frame_count)
            path = f"video_frame_{data_set_name}_{int(time.time() * 1000)}.jpg"
            tmp_file = TmpFile(path, is_video_pic=True)
            write_res = tmp_file.write(frame, type="video")
            if not write_res:
                error_count+=1
                logger.info(f"{data_set_name} write frame failed , frame index {frame_index} error count {error_count}, frame total {video_obj.frame_count}")
                continue
            tmp_res = write2mio(minio_video_bucket, frame_path, tmp_file.file_path)
            if tmp_res:
                tmp_file.remove_pic(path)
            frame_count += 1
        frame_index += 1
    logger.info(f"video to frame total time {time.time()-start}")
    video_obj.video_cap.release()
    return base_file_path+"/", video_obj.fps


def read_instances(file_path, data_set_type, duplicate=True, is_web_file=False, is_json=False):
    """
    """
    # 读取文件
    if is_web_file:
        web_file = URLFile(file_path)
        df, err = web_file.read()
    else:
        tmp_file = TmpFile(file_path, mode="read")
        df, err = tmp_file.read()
        # 删除临时文件
        tmp_file.remove()
    if err is not None:
        return None, err

    try:
        # 转换数据
        if data_set_type == "text":
            df = text_data_file_trans(df, "text", duplicate=duplicate)
        elif data_set_type == "image":
            df = text_data_file_trans(df, "path", duplicate=duplicate)
        elif data_set_type == "voice":
            df = text_data_file_trans(df, "path", duplicate=duplicate)
        elif data_set_type == "video":
            df = text_data_file_trans(df, "path", duplicate=duplicate)
        elif data_set_type == "qa-top10":
            if not is_json:
                df = text_data_file_trans(df, "text", duplicate=duplicate)
        else:
            return None, "not support data set type"
        # 是否存在额外字段
        if not is_json:
            if "extra_info" in df.columns:
                instances = df[["data", "extra_info"]].to_dict("records")
            else:
                instances = df[["data"]].to_dict("records")
        else:
            instances = [{"data": {"text": data}} for data in df.get("text")]

        return instances, None
    except Exception as e:
        return None, e


@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def excel_instances(self, file_path, dataset_id, info=None, task_info=None, atid=None):
    """
    根据文件导入数据
    """
    celery_id = self.request.id
    # 获取 数据集对象
    data_set = get_dataset_by_id(dataset_id)
    if data_set is None:
        msg = "数据集不存在"
        logger.info(f"Error: id={celery_id}, {msg}")
        raise Exception(msg)
    logger.info(f"Info: id={celery_id}, excel input to dataset, name={data_set.name}")
    # if data_set.data_set_type.name=="qa-top10":
    #     deal_qa_instance(file_path, None, data_set_id=data_set.id, task_id=None)
    #     return None
    is_json = file_path.endswith("json")
    # 获取 instance
    instances, err = read_instances(file_path, data_set.data_set_type.name, duplicate=True, is_json=is_json)
    if err is not None:
        logger.info(f"Error: id={celery_id}, error={err}")
        dataset_error(data_set, err)
        raise Exception(err)

    # 创建实例
    count = create_instances(data_set, instances)
    if count==0:
        logger.info(f"Info: id={celery_id}, {file_path} instance all repeat")
    # count = len(instances)
    logger.info(f"Info: id={celery_id}, read instance finished, count={count}")
    return None


@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def web_file_instances(self, file_path, web_params, data_set_id=None, task_id=None, info=None, atid=None):
    """
    根据文件导入数据
    """
    celery_id = self.request.id
    if web_params.get("dataType")=="qa-top10":
        deal_qa_instance(file_path, web_params, data_set_id=data_set_id, task_id=task_id)
        return None
    with db.atomic() as transaction:
        try:
            label_task = None
            # 1、创建 数据集对象
            data_set = DataSet.create_instance(web_params) if data_set_id is None else DataSet.get_or_none(
                DataSet.id == data_set_id)
            is_json = file_path.endswith("json")
            # 获取 instance
            instances, err = read_instances(file_path, web_params.get("dataType"), duplicate=False, is_web_file=True, is_json=is_json)
            if err is not None:
                logger.info(f"Error: id={celery_id}, error={err}")
                dataset_error(data_set, err)
                raise Exception(err)
            count = len(instances)
            logger.info(f"Info: id={celery_id}, read instance finished, count={count}")

            data_set_id = data_set.id
            # 2、创建数据集实例
            insert_count = create_instances(data_set, instances)
            amount = insert_count
            if web_params.get("append_flag"):
                amount = data_set.amount+amount
            data_set.update_instance({"is_usable": True, "amount": amount})
            # 3、更新任务

            if task_id:
                label_task = LabelTask.get_or_none(LabelTask.id == task_id)
                if web_params.get("append_flag") and label_task.gmt_begin is not None:
                    label_task.append_nodes(insert_count)
                    insert_count = insert_count+label_task.amount

                label_task.update_instance({"data_set": data_set_id, "amount": insert_count})


            # return task.to_dict()
        except Exception as e:
            # 异常回滚，并删除创建的任务
            transaction.rollback()
            if task_id and label_task:
                label_task.delete_instance()
            raise Exception(str(e))

    return None

def deal_qa_instance(file_path, web_params, data_set_id=None, task_id=None):
    file_stream = URLFile.get_web_file(file_url=file_path, stream=True)
    total_size = int(file_stream.headers.get("Content-Length"))
    logger.info(f"web file size: {total_size}")
    headers = {
        "Range": "bytes=%d-" % 0
    }
    chunk_instance = []
    count = 0
    start = time.time()
    chunk_start = start
    chunk_size = 1024
    record_num = 0
    label_task = None
    with db.atomic() as transaction:
        try:
            # 1、创建 数据集对象
            data_set = DataSet.create_instance(web_params) if data_set_id is None else DataSet.get_or_none(
                DataSet.id == data_set_id)
            data_set_id = data_set.id
            for chunk in file_stream.iter_lines(chunk_size):
                if chunk:
                    if count == 0:
                        count += 1
                        continue
                    if count == chunk_size+1:
                        # 2、创建数据集实例
                        insert_num = create_instances(data_set, chunk_instance)
                        count = 1
                        chunk_instance = []
                        logger.info(f"{record_num} record cost time: {time.time() - chunk_start}")
                        record_num += insert_num
                        chunk_start = time.time()
                        if web_params.get("append_flag"):
                            with db.atomic():
                                label_task = LabelTask.get_or_none(LabelTask.id == task_id)
                                if label_task and label_task.gmt_begin is None:
                                    continue
                                label_task.append_nodes(insert_num)
                    count += 1
                    chunk_data = pd.read_csv(StringIO(chunk.decode()), header=0, names=None, encoding="utf-8")
                    chunk_instance.append({"data": {"text": chunk_data.columns[0]}, "extra_info": chunk_data.columns[1]})
            if count>1:
                insert_num = create_instances(data_set, chunk_instance)
                record_num += insert_num
                if web_params.get("append_flag"):
                    with db.atomic():
                        label_task = LabelTask.get_or_none(LabelTask.id == task_id)
                        if label_task and label_task.gmt_begin is not None:
                            label_task.append_nodes(insert_num)
            data_set.update_instance({"is_usable": True,"amount": record_num})
            # 3、更新任务
            if task_id and label_task is not None:
                label_task.update_instance({"data_set": data_set_id, "amount": record_num})
        except Exception as e:
            # 异常回滚，并删除创建的任务
            transaction.rollback()
            if task_id and label_task:
                label_task.delete_instance()
            raise Exception(str(e))
    logger.info(f"total record cost time: {time.time() - start}")
    return None


@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def append_instances(self, file_path, dataset_id, update_tasks, web_params=None, info=None, atid=None):
    """
    追加数据
    """
    celery_id = self.request.id

    # 获取 数据集对象
    data_set = get_dataset_by_id(dataset_id)
    if data_set is None:
        msg = "数据集不存在"
        logger.info(f"Error: id={ celery_id }, { msg }")
        raise Exception(msg)
    logger.info(f"Info: id={ celery_id }, append instance to dataset, name={ data_set.name }")
    
    # 获取 instance
    instances, err = read_instances(file_path, data_set.data_set_type.name, duplicate=False)
    if err is not None:
        logger.info(f"Error: id={ celery_id }, { err }")
        raise Exception(err)
    count = len(instances)
    logger.info(f"Info: id={celery_id}, read instance finished, count={count}")

    # 第一步：追加数据
    logger.info(f"Info: id={celery_id}, start append instance, count={count}")
    with db.atomic():
        insert_count = data_set.create_and_combine_instances(instances).get("insert_num")
    logger.info(f"Info: id={celery_id}, end append instance, count={insert_count}")
    if insert_count<=0:
        logger.info(f"Info: id={celery_id}, append instance failed, {file_path} instance is None or repeat")
        return None
    # 第二步：判断是否更新任务
    update_tasks = [get_task_by_id(task_id) for task_id in update_tasks]
    # 第三步；更新任务节点
    logger.info(f"Info: id={celery_id}, start append task, count={insert_count}")
    with db.atomic():
        for task in update_tasks:
            if task is None:
                continue
            # if task.gmt_begin is None:
            #     continue
            logger.info(f"append task nodes {task}, nodes {insert_count}")
            task.append_nodes(insert_count)
            task.update_instance({"amount": task.amount+insert_count})
    # 更新数据集节点数据量
    data_set.update_instance({"amount": data_set.amount+insert_count})

    logger.info(f"Info: id={celery_id}, end append task, count={insert_count}")

    return None


@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def merge_dataset(self, dataset_id, merge_ids, info=None, atid=None):
    """
    追加数据
    """
    celery_id = self.request.id

    # 获取 数据集对象
    data_set = get_dataset_by_id(dataset_id)
    if data_set is None:
        msg = "数据集不存在"
        logger.info(f"Error: id={ celery_id }, { msg }")
        raise Exception(msg)
    logger.info(f"Info: id={ celery_id }, start merge dataset")
    
    # 获取所有 instance
    logger.info(f"Info: id={celery_id}, start get instance")
    instances = []
    with db.atomic():
        for mid in merge_ids:
            mds = get_dataset_by_id(mid)
            if mds is None:
                raise Exception("合并数据集不存在")
            logger.info(f"Info: id={ celery_id }, start get instance, dataset name={ mds.name }")
            instances.extend([{"data": instance.data} for instance in mds.instances])
            logger.info(f"Info: id={celery_id}, end get instance, dataset name={mds.name}")
    logger.info(f"Info: id={celery_id}, end get instance")
    # 插入数据
    logger.info(f"Info: id={celery_id}, start insert data")
    create_instances(data_set, instances)
    logger.info(f"Info: id={celery_id}, end insert data")

    return None


def config_task_operator(task, operator_ids):
    """
    """
    # 删除已经存在的任务和操作人员信息
    task.delete_task_operators()
    # 获取所有操作人员，如果操作人员不存在，直接报错
    operators = [User.get_or_none(uid) for uid in operator_ids]
    if not all(operators):
        return "operator not exist"
    # 组织数据
    task_operator_params = [{"task": task, "operator": user} for user in operators]
    try:
        LabelTaskOperator.create_instances(task_operator_params)
    except Exception as e:
        return e


@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def config_task(self, task_id, operator_ids, info=None, atid=None):
    """
    """
    celery_id = self.request.id

    task = get_task_by_id(task_id)
    if task is None:
        msg = "标注任务不存在"
        logger.info(f"Error: id={ celery_id }, { msg }")
        raise Exception(msg)
    logger.info(f"Info: id={ celery_id }, config task, name={ task.name }")
    
    blind_check_type = task.blind_check_type
    blind_check_rate = task.blind_check_rate

    with db.atomic() as transaction:
        try:
            # 配置任务和操作者 start -------------- 这个操作待定---------------
            logger.info(f"Info: id={celery_id}, config task operator")
            err = config_task_operator(task, operator_ids)
            if err is not None:
                transaction.rollback()
                logger.info(f"Error: id={celery_id}, {err}")
                task.config_error(err)
                raise Exception(err)
            # 配置任务和操作者 end -------------- 这个操作待定---------------

            # 划分 node
            logger.info(f"Info: id={celery_id}, split nodes")
            nodes = [{"data": x} for x in task.data_set.instances]

            # 删除已存 node
            task.delete_nodes()

            # 如果盲审方式为 2（单一），则将盲审率置为 0
            check_rate = blind_check_rate if blind_check_type == 1 else 0
            task.split_nodes(nodes, check_rate)
        except Exception as e:
            logger.exception(e)
            transaction.rollback()
            msg = f"create node failed [{ str(e) }]"
            logger.info(f"Error: id={ celery_id }, { msg }")
            task.config_error(msg)
            raise Exception(msg)
        
        task.config_success()
        logger.info(f"Info: id={celery_id}, config task success")

    return None
