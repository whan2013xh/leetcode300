# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-11-15
    FileName   : delete_task.py
    Author     : Mustom
    Descreption: 
"""
from celery.app.control import Control
from celery.result import AsyncResult

from ..app import app, celery_control
from .utils import get_dataset_by_id, get_task_by_id, logger_begin_end, LunarTask

from lunar.db import db
from lunar.models import LabelNode, LabelTaskOperator, \
    DataInstance, AsyncTask
from lunar.logger import logger


@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def delete_dataset(self, dataset_id, info=None, atid=None):
    """
    删除数据集
    """
    celery_id = self.request.id

    # 删除数据集
    logger.info(f"Info: id={ celery_id }, start delete dataset instance")
    with db.atomic():
        DataInstance.delete().where(DataInstance.data_set_id == dataset_id).execute()
    logger.info(f"Info: id={ celery_id }, end delete dataset instance")
    return None


@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def delete_label_task(self, task_id, info=None, atid=None):
    """
    删除标注任务
    """
    celery_id = self.request.id

    # 删除 节点、操作人员信息、任务
    logger.info(f"Info: id={ celery_id }, start delete task node and operator")
    with db.atomic():
        LabelNode.delete().where(LabelNode.task_id == task_id).execute()
        LabelTaskOperator.delete().where(LabelTaskOperator.task_id == task_id).execute()
    logger.info(f"Info: id={ celery_id }, start delete task node and operator")
    return None


@app.task(bind=True, ignore_result=True, base=LunarTask)
@logger_begin_end
def delete_async_task(self, async_id, task_id=None, data_set_id=None, user_name=None, info=None, atid=None):
    """
    删除同步任务
    """
    celery_id = self.request.id
    # 取消异步任务
    async_task = AsyncTask.get_or_none(AsyncTask.id == async_id)
    # 停止任务
    if async_task is not None and async_task.status in ["PENDING", "STARTED", "RETRY"]:
        celery_control.revoke(str(async_task.async_id), terminate=True)

    # 获取任务
    # 如果任务不存在，直接返回None，表示成功
    data_set = get_dataset_by_id(data_set_id)

    # 修改异步任务
    logger.info(f"Info: id={ celery_id }, start delete async task")
    # 异步删除任务对应的节点、操作人员等数据
    with db.atomic():
        # 修改异步任务状态
        async_task.update_instance({"status": "REVOKE"})
        # 删除任务对应的node
        LabelNode.delete().where(LabelNode.task_id == task_id).execute()
        # 删除任务分配的操作人员
        LabelTaskOperator.delete().where(LabelTaskOperator.task_id == task_id).execute()
        logger.info(f"{user_name} delete task: id={task_id}")
        # 判断任务的数据集是否关联其他任务，如果不存在则删除数据集
        if not data_set.exist_task():
            # 删除数据集对应的实例
            DataInstance.delete().where(DataInstance.data_set_id == data_set.id).execute()
            # 删除数据集
            data_set.delete_instance()
            logger.info(f"{user_name} delete data set: name={ data_set.name}")
    logger.info(f"Info: id={ celery_id }, end delete async task")
    return None


