# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-11-12
    FileName   : config.py
    Author     : Mustom
    Descreption: 
"""
from kombu import Exchange, Queue

from lunar.config import config as lunar_config


class Config(object):
    ## 基础设置
    timezone = "Asia/Shanghai"
    broker_url = lunar_config["broker_url"]
    result_backend = lunar_config["backend_url"]
    ## 状态相关
    # 该配置设置为 True 时，才会出现 STARTED 状态
    task_track_started = True
    ## include
    include = [
        "lunar.celery.task"
    ]

    ## 并发、内存相关设置
    # 每个worker最大执行任务数，当worker执行任务数达到最大后会自动销毁重建（释放内存资源）
    # worker_max_tasks_per_child = 5
    # # celery worker并发数，通常不用设置，默认和系统核数一致
    # worker_prefetch_multiplier = 4
    # CELERY_TASK_RESULT_EXPIRES = 24 * 60 * 60
    task_time_limit = 3 * 60 * 60

    ## 队列配置
    task_queues = (
        Queue(name="import", exchange=Exchange("import"), routing_key="import_router"),
        Queue(name="export", exchange=Exchange("export"), routing_key="export_router"),
        Queue(name="delete", exchange=Exchange("delete"), routing_key="delete_router")
    )
    task_routes = {
        'lunar.celery.task.import_task.*': 'import',
        'lunar.celery.task.export_task.*': 'export',
        'lunar.celery.task.delete_task.*': 'delete'
    }
