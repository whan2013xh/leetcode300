# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-05-21
    FileName: mio.py
    Author: Mustom
    Descreption: 
"""
import os
import json
from datetime import timedelta
from io import BytesIO
from minio import Minio
from lunar.config import config
from lunar.logger import logger

minio_endpoint = config["minio_endpoint"]
minio_secure = config["minio_secure"]
minio_access_key = config["minio_access_key"]
minio_secret_key = config["minio_secret_key"]

minio_link_endpoint = config["minio_link_endpoint"]
minio_link_secure = config["minio_link_secure"]

class OssFile(object):
    """
    处理 MinIO 文件类
    """

    # def __init__(self, endpoint, access_key="ADMIN",secret_key="CEPSXHKPSWRATKCL", secure=False):
    def __init__(self):
        """
        Args:
            endpoint:
            access_key:
            secret_key:
            secure:
            bucket:
        """
        self.minioClient = Minio(endpoint=minio_endpoint,
                                 access_key=minio_access_key,
                                 secret_key=minio_secret_key,
                                 secure=minio_secure)
    
    @staticmethod
    def link(bucket, path, expiry=timedelta(days=7)):
        """
        """
        try:
            linkClient = Minio(endpoint=minio_link_endpoint,
                                access_key=minio_access_key,
                                secret_key=minio_secret_key,
                                secure=minio_link_secure)
            return linkClient.presigned_get_object(bucket, path, expires=expiry), None
        except Exception as e:
            return None, str(e)
    
    def presigned_get_object(self, bucket, path, expiry=timedelta(days=7)):
        """
        """
        try:
            return self.minioClient.presigned_get_object(bucket, path, expires=expiry), None
        except Exception as e:
            return None, str(e)
    
    def fput_object(self, bucket, path, file_path, content_type):
        """
        保存对象
        Args:
            bucket: 桶名称
            path: 文件路径
            file_path: 文件路径
            content_type: 文本类型
        """
        try:
            with open(file_path, "rb") as file_data:
                file_stat = os.stat(file_path)
                self.minioClient.put_object(
                    bucket, path, file_data,
                    file_stat.st_size, content_type=content_type
                )
            return None
        except Exception as e:
            return str(e)
    
    def put_object(self, bucket, path, bs, content_type):
        """
        保存对象
        Args:
            bucket: 桶名称
            path: 文件路径
            bs: bytes类型数据
            content_type: 文本类型
        """
        try:
            size = len(bs)
            self.minioClient.put_object(
                bucket, path, BytesIO(bs), 
                size, content_type=content_type
            )
            return None
        except Exception as e:
            return str(e)
    
    # 获取对象
    def get_object(self, bucket, path):
        """
        获取 minio 的 对象，对象类型：urllib3.response.HTTPResponse
        """
        data = None
        try:
            data = self.minioClient.get_object(bucket, path)
        except Exception as err:
            logger.info(err)
        
        return data
    
    # 获取某个路径下的所有路径
    def get_paths(self, bucket, prefix=None, recursive=False):
        """
        获取 bucket 下的 path 路径下的所有文件，返回其路径
        """
        if bucket is None:
            return []
        objs = self.minioClient.list_objects(
            bucket, prefix=prefix, recursive=recursive
        )
        return objs


def get_img_object(request):
    path = request.args["path"]
    spills = [spill for spill in path.split("/") if spill.strip()]
    bucket_name = spills[0]
    object_name = "/".join(spills[1:])
    file_name = spills[-1]
    minio_client = OssFile()
    data = minio_client.get_object(bucket_name, object_name)
    return data, file_name


def get_minio_object(path):
    """
    根据路径，获取 minIO 对象
    """
    spills = [spill for spill in path.split("/") if spill.strip()]
    bucket_name = spills[0]
    object_name = "/".join(spills[1:])
    minio_client = OssFile()
    data = minio_client.get_object(bucket_name, object_name)
    return data

    
def object2file(file_path, obj):
    """
    将对象写入文件
    """
    with open(file_path, 'wb') as fp:
        for d in obj.stream(32 * 1024):
            fp.write(d)


def object2json(obj):
    """
    将对象写入json
    """
    result = {}

    cont = obj.read()
    if cont != b'' and cont != '':
        result = json.loads(cont)
        
    return result

def get_json_object(path):
    """
    通过 minIO 路径，获取json文件
    """
    obj = get_minio_object(path)
    return object2json(obj)
