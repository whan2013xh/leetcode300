from enum import Enum
import peewee
import time

from lunar.db import db
from lunar.models.base import BaseModel


class RoleType(Enum):
    ADMIN = "admin"
    MANAGER = "manager"
    OPERATOR = "operator"
    DEMANDER = "demander"
    OPERATORLDE = "operatorldr"


class Role(BaseModel):
    name = peewee.CharField(unique=True)

    class Meta:
        table_name = "lunar_role"


class User(BaseModel):
    name = peewee.CharField(unique=True)
    role = peewee.ForeignKeyField(Role, backref="users")
    allow_sso = peewee.BooleanField(default=False)
    sso_email = peewee.CharField(default="no-email")

    class Meta:
        table_name = "lunar_user"

    def to_dict(self):
        d = super().to_dict()
        d["role_name"] = self.role.name
        return d

    def to_basic_dict(self):
        res = {
            "id": self.id,
            "name": self.name
        }
        return res

    def is_group_user(self, group):
        """
        判断当前用户是否属于指定组
        """
        if group is None:
            return False
        group_user = GroupUser.get_or_none(
            (GroupUser.group == group) &
            (GroupUser.user == self) &
            (GroupUser.is_deleted == False)
        )
        return bool(group_user)

    def check_group(self, group_name=None):
        """
        获取指定名称的组
        """
        # 如果指定的group name 为None，则使用当前用户所在组
        if group_name is None:
            group_name = self.name
        group = Group.get_or_none(
            (Group.name == group_name) &
            (Group.is_deleted == False)
        )
        # 如果组不存在，直接返回
        if group is None:
            return group
        # 判断当前用户是否属于组
        flag = self.is_group_user(group)

        return group if flag else None


class Group(BaseModel):
    name = peewee.CharField(unique=True)
    info = peewee.CharField(default="")
    is_deleted = peewee.BooleanField(default=False)
    last_operator = peewee.ForeignKeyField(User, backref="group_users", null=True)
    is_private = peewee.BooleanField(default=False)

    class Meta:
        table_name = "lunar_group"

    def sync_user(self, users):
        """
        同步用户
        """
        return GroupUser.sync_user(self, users)


class GroupUser(BaseModel):
    group = peewee.ForeignKeyField(Group, backref="group_users")
    user = peewee.ForeignKeyField(User, backref="group_users")
    is_deleted = peewee.BooleanField(default=False)
    last_operator = peewee.ForeignKeyField(User, backref="group_user", null=True)


    class Meta:
        table_name = "lunar_group_user"

    @classmethod
    def sync_user(cls, group, users):
        """
        同步用户
        """
        # 同步时间
        cur_time = int(time.time() * 1000)
        # 首先删除该用户组下的用户
        cls.update({"is_deleted": True, "gmt_modified": cur_time}).where(cls.group == group).execute()
        # 同步用户
        for user in users:
            data = {
                "group": group, "user": user, "is_deleted": False,
                "gmt_create": cur_time, "gmt_modified": cur_time
            }
            cls.insert(**data).on_conflict(
                preserve=[cls.gmt_modified, cls.is_deleted]
            ).execute()
        return len(users)

    @classmethod
    def delete_group_user(cls, group_id, user_ids, last_operator_id):
        """
        删除用户，支持批量删除,目前为逻辑删除，方便误删除数据恢复
        """
        # 同步时间
        cur_time = int(time.time() * 1000)
        # 首先删除该用户组下的用户
        with db.atomic():
            # 如果未指定了删除用户的列表，则按照用户组编号对全部的用户进行删除
            if user_ids:
                update_res = cls.update({"is_deleted": True, "gmt_modified": cur_time, "last_operator_id": last_operator_id}).where(
                    (cls.group == group_id) & (cls.user in user_ids)
                    ).execute()
            else:
                update_res = cls.update(
                    {"is_deleted": True, "gmt_modified": cur_time, "last_operator_id": last_operator_id}).where(
                    (cls.group == group_id)).execute()
        return update_res

    @classmethod
    def get_private_group(cls, user_id):
        group_users = cls.select().where((cls.user==user_id) & (cls.is_deleted==False))
        for group_user in group_users:
            if group_user.group.is_private:
                return group_user.group.id
        return None
