"""Base model class"""

import peewee
import datetime

import time
import json

from lunar.db import db
from lunar.utils import execute_time


class MyJSONField(peewee.CharField):
    field_type = 'MyJSON'

    def db_value(self, value):
        if value is not None:
            return json.dumps(value)

    def python_value(self, value):
        if value is "":
            return ""
        if value is not None:
            return json.loads(value)


class BaseModel(peewee.Model):
    gmt_create = peewee.BigIntegerField()
    gmt_modified = peewee.BigIntegerField()

    class Meta:
        database = db

    @classmethod
    def create_instance(cls, data: dict):
        cur_time = int(time.time() * 1000)
        data["gmt_create"] = cur_time
        data["gmt_modified"] = cur_time
        instance = cls(**data)
        instance.save()
        return instance

    @classmethod
    def create_instances(cls, data: list):
        length = len(data)
        if length == 0:
            return {"insert_num": len(data)}
        for batch in peewee.chunked(data, 1000):
            cls.add_time(batch)
            cls.insert_many(batch).execute()
        return {"insert_num": length}
    
    @classmethod
    def add_time(self, batch: list, value=None):
        value = value if value is not None else int(time.time() * 1000)
        for x in batch:
            x["gmt_create"] = value
            x["gmt_modified"] = value

    @classmethod
    def _custom_select(cls, fields: list = None):
        """
        Function to define fields that simple search, override it when you need custom query
        :param fields:
        :return:
        """
        if fields is None:
            fields = []
        result = cls.select(*fields)
        return result

    @classmethod
    def generate_expressions(cls, raw_expressions: dict):
        if len(raw_expressions) == 0:
            expressions = [None]
        else:
            validated_expressions = {}
            for key, value in raw_expressions.items():
                # 判断 key 是否为类字段、属性
                if key not in cls.__dict__:
                    continue
                # 将布尔类型的字符串转换为布尔类型
                if isinstance(value, list) and value:
                    value = value[0]
                validated_expressions[key] = cls.transform_bool(key, value)
            # 判断 validated_expressions 是否为空
            if not validated_expressions:
                expressions = [None]
            else:
                expressions = [cls.__dict__[key].field == value for key, value in validated_expressions.items()]
        return expressions

    @classmethod
    def transform_bool(cls, key, value):
        """
        trans value from string to type that Field need
        :param key: Field name
        :param value:
        :return:
        """
        if isinstance(cls.__dict__[key].field, peewee.BooleanField):
            d = {"false": False, "False": False, "true": True, "True": True}
            value = d.get(value, bool(value))
            # value = [d.get(ve, bool(ve)) for ve in value]
            return value
        else:
            return value

    @classmethod
    def _simple_search(cls, fields: list = None, expressions: list = None):
        if expressions is None:
            expressions = [None]

        if fields is None:
            fields = []
        else:
            fields = [cls.__dict__[f].field for f in fields]
        ms = cls._custom_select(fields)
        result = ms.where(*expressions)  # todo need test
        return result

    @classmethod
    def simple_search(cls, fields: list = None, raw_expressions: dict = None):
        if raw_expressions is None:
            expressions = [None]
        else:
            expressions = cls.generate_expressions(raw_expressions)
        result = cls._simple_search(fields, expressions)
        return result

    def update_instance(self, data: dict):
        for key in data.keys():
            if key != "id":
                self.__data__[key] = data[key]
        self.gmt_modified = int(time.time() * 1000)
        self.save()
        return self

    def to_dict(self):
        d = self.__data__
        return d


class BaseSetMixin(object):
    instance_resource = BaseModel
    set_key = "set"

    def create_and_combine_instances(self, raw_data_instances: list):
        for x in raw_data_instances:
            x[self.set_key] = self.id
        return self.instance_resource.create_instances(raw_data_instances)

    @classmethod
    def create_set_and_instance(cls, set_params: dict, instances: list):
        with db.atomic():
            cur_time = int(time.time() * 1000)
            set_params["gmt_create"] = cur_time
            set_params["gmt_create"] = cur_time
            new_set = cls(**set_params)
            new_set.save()
            new_set.create_and_combine_instances(instances)
        return new_set

    def delete_set(self):
        self.instance_resource.delete().where(self.instance_resource.__dict__[self.set_key].field == self.id).execute()
        self.delete_instance()
