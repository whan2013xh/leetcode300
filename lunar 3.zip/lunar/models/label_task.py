import math
import time
import peewee
import pandas as pd
from enum import Enum
from datetime import datetime

from lunar.models.base import MyJSONField
from lunar.models.user import User, Group
from lunar.models.dataset import DataInstance, DataSet, LabelTaskType
from lunar.models.base import BaseModel, BaseSetMixin
from lunar.utils import cal_begin_and_end_mill_timestamp
from lunar.data import PreLabelData


class Domain(Enum):
    """
    业务领域
    """
    IOT = "iot"

    @classmethod
    def list_(cls):
        return list(cls._value2member_map_.keys())


class NodeStatus(Enum):
    """
    节点状态类型
    """
    NOT_LABEL = 0
    LABELED = 1
    # 跳过
    JUMP = 2
    # 丢弃
    ABANDON = 3
    # 质检不一致
    CHECK_ERROR = 4
    # 切词错误
    CUT_WORD_ERROR = 5


class LabelTask(BaseModel, BaseSetMixin):
    """"""
    gmt_begin = peewee.BigIntegerField(null=True)
    gmt_end = peewee.BigIntegerField(null=True)
    name = peewee.CharField(unique=True)
    task_type = peewee.ForeignKeyField(LabelTaskType, backref="tasks")
    data_set = peewee.ForeignKeyField(DataSet, backref="tasks")
    use_pre_label = peewee.BooleanField(default=False)
    task_template = MyJSONField(default="")
    owner = peewee.ForeignKeyField(Group, backref="tasks")
    is_completed = peewee.BooleanField(default=False)
    info = peewee.CharField(default="")
    blind_check_type = peewee.IntegerField(null=True)
    blind_check_rate = peewee.IntegerField(null=True)
    is_usable = peewee.BooleanField(default=False)
    error_message = peewee.CharField(default="")
    domain = peewee.CharField(null=False, default=Domain.IOT.value)
    amount = peewee.IntegerField(default=0)
    reference_size = peewee.IntegerField(default=0)

    set_key = "task"

    class Meta:
        table_name = "lunar_label_task"

    def get_origin_data(self):
        """
        获取所有原始数据
        """
        return self.data_set.get_origin_data()

    def have_pre_label_data(self):
        """
        """
        if not self.use_pre_label:
            self.use_pre_label = True
            self.gmt_modified = int(time.time() * 1000)
            self.save()

    def get_labels(self):
        """
        获取所有标签
        """
        if self.task_type.name not in ["text_classify", "reapu"]:
            return []
        labels = self.task_template["labels"]
        return [ele["value"] for ele in labels]

    def get_rules(self, raw_expression=None):
        """
        获取所有规则
        """
        if self.task_type.name != "text_classify":
            return []
        if raw_expression is None:
            return LabelRule.select().where(LabelRule.task_id == self.id)
        raw_expression["task_id"] = self.id
        return LabelNode.simple_search(raw_expressions=raw_expression)

    def get_priority(self):
        """
        获取所有标签权重
        """
        if self.task_type.name != "text_classify":
            return None
        labels = self.task_template["labels"]
        return {ele["value"]:int(ele.get("priority",0)) for ele in labels if ele.get("priority") is not None}

    def append_nodes(self, insert_count=0):
        """
        追加节点,只支持同时对一个数据集进行单次追加
        """
        if insert_count>0:
            instances = DataInstance.select(DataInstance.id).where(DataInstance.data_set==self.data_set.id).order_by(DataInstance.id.desc()).limit(insert_count)
        else:
            instances = LabelNode.update_by_task(self.id, self.data_set.id)
        if instances:
            nodes = [{"data": node} for node in instances]
            # 如果盲审方式为 2（单一），则将盲审率置为 0
            check_rate = self.blind_check_rate if self.blind_check_type == 1 else 0
            self.split_nodes(nodes, check_rate)
            self.is_completed = False
            self.gmt_modified = int(time.time() * 1000)
            self.save()

    def data_set_num(self):
        """
        数据集长度
        """
        return DataInstance.select().where(
            (DataInstance.data_set_id == self.data_set.id)
        ).count()

    def config_success(self):
        """
        """
        cur_time = int(time.time() * 1000)

        self.gmt_begin = cur_time
        self.gmt_modified = cur_time
        self.amount = LabelNode.select().where(LabelNode.task_id == self.id).count()
        self.is_usable = True
        self.save()

    def config_error(self, error_message):
        """
        """
        self.error_message = error_message
        self.gmt_modified = int(time.time() * 1000)
        self.save()

    def config(self, info, blind_check_type, blind_check_rate):
        """
        """
        self.info = info
        self.blind_check_type = blind_check_type
        self.blind_check_rate = blind_check_rate
        self.gmt_modified = int(time.time() * 1000)
        self.save()

    def cal_blind_check_accuracy(self, operator=None):
        """
        计算盲审一致率
        """
        # 构建条件
        ms = LabelTaskOperator.select().where(LabelTaskOperator.task == self)
        if operator is not None:
            ms.where(LabelTaskOperator.operator == operator)
        # 查询
        ltos = [lto for lto in ms]
        # 质检数量
        check_nums = sum([lto.check_num for lto in ltos])
        # 质检正确数量
        checkout_nums = sum([lto.checkout_num for lto in ltos])
        if not check_nums:
            return 0.0
        return round(checkout_nums * 1.0 / check_nums, 3)

    def get_unchecked_num(self, operator=None):
        """
        获取 还需要被质检的节点数量
        """
        # 构建条件
        ms = LabelNode.select().where((LabelNode.task == self) & (LabelNode.is_blind_check==1) & (LabelNode.status!=4) & (LabelNode.has_been_check==0))
        # ms = LabelTaskOperator.select().where(LabelTaskOperator.task == self)
        # if operator is not None:
        #     ms.where(LabelTaskOperator.operator == operator)
        # # 查询
        # ltos = [lto for lto in ms]
        # # 标注过的盲审节点数量
        # blind_nums = sum([lto.blind_num for lto in ltos])
        # if not blind_nums:
        #     return 0
        # # 质检数量
        # check_nums = sum([lto.check_num for lto in ltos])

        #return blind_nums - check_nums
        return ms.count()

    def delete_task_operators(self):
        """
        删除 本次任务关联的 task_operator 对象
        """
        [v.delete_instance() for v in self.task_operators]

    def delete_nodes(self):
        """
        删除 本次任务关联的 node 对象
        """
        [v.delete_instance() for v in self.nodes]

    def have_labeled(self):
        """
        已经存在标注数据
        """
        labeled_nodes = [node for node in self.nodes if node.is_labeled]
        if labeled_nodes:
            return True
        return False

    def had_completed(self):
        """
        判断本次任务是否完成
        完成的定义：标注完成（gmt_end 不为空），质检节点也全部质检完成
        注意：交叉 和 单一 两种检验方式的不同，检查任务是否完成的标准也不同
        """
        # 如果 开始时间 或者 盲审方式 为空，则表示任务肯定没完成
        if self.gmt_begin is None or self.blind_check_type is None:
            return False
        # 如果 结束时间 为空，也表示任务没有完成
        if self.gmt_end is None:
            return False
        # 判断任务是否还有需要质检的节点，任务未完成
        if self.get_unchecked_num():
            return False
        if self.nodes.select(LabelNode.status==NodeStatus.CHECK_ERROR.value):
            return False
        return True

    def split_nodes(self, nodes, blind_check_rate=0):
        # nodes 转 DataFrame
        df = pd.DataFrame(nodes)
        # 添加 task
        df["task"] = self
        # 初始化 is_blind_check 为 False
        df["is_blind_check"] = False
        # 抽样盲审节点
        gdf = self.blind_check_sample(df, blind_check_rate)
        # 标识原始数据中的盲审节点
        df.loc[gdf.index, "is_blind_check"] = True
        # 将原始数据和抽样数据结合起来
        df = pd.concat([df, gdf], sort=False)
        nodes = df.to_dict(orient="records")
        LabelNode.create_instances(nodes)

    @staticmethod
    def blind_check_sample(df, blind_check_rate=0):
        n = math.ceil(len(df) * blind_check_rate / 100)
        sdf = df.sample(n, replace=False)
        sdf["is_blind_check"] = True
        return sdf

    def check_complete(self):
        cur_time = int(time.time() * 1000)
        self.gmt_modified = cur_time
        self.is_completed = True
        self.save()

    def label_complete(self):
        cur_time = int(time.time() * 1000)
        self.gmt_modified = cur_time
        self.gmt_end = cur_time
        self.save()

    def complete(self):
        self.is_completed = True
        self.save()
        LabelNode.update(is_locked=True).where(LabelNode.task == self).execute()
        return self.to_dict()

    def to_dict(self):
        d = super().to_dict()
        return d

    def to_detailed_dict(self):
        d = self.to_dict()
        update_dict = {
            "data_set_type": self.data_set.data_set_type.name,
            "task_type_name": self.task_type.info,
            "data_set_name": self.data_set.name,
            "owner_name": self.owner.name,
            # "data_length": DataInstance.select().where(DataInstance.data_set_id == self.data_set.id).count(),
            # "data_length": LabelNode.select().where(LabelNode.task_id == self.id).count(),
            "data_length": self.amount,
            "task_operators": [x.operator.to_dict() for x in self.task_operators],
            "rules": [x.to_dict() for x in self.get_rules()]
        }
        d.update(update_dict)
        return d


class LabelTaskOperator(BaseModel):
    """
    任务和操作用户对应表
    """
    task = peewee.ForeignKeyField(LabelTask, backref="task_operators")
    operator = peewee.ForeignKeyField(User, backref="task_operators")
    label_num = peewee.IntegerField(default=0)
    blind_num = peewee.IntegerField(default=0)
    check_num = peewee.IntegerField(default=0)
    checkout_num = peewee.IntegerField(default=0)

    class Meta:
        table_name = "lunar_label_task_operator"

    def commit(self, is_blind_check=False):
        # 标注数量+1
        self.label_num += 1
        # 如果是盲审节点，标注的盲审节点数量+1
        if is_blind_check:
            self.blind_num += 1
        # 修改时间
        self.gmt_modified = int(time.time() * 1000)
        # 保存修改
        self.save()

    def check(self, qualified):
        """
        只有质检正确的节点才会进入该函数
        """
        # 质检数量+1
        self.check_num += 1
        # 如果qualified为true，质检正确的数量+1
        if qualified:
            self.checkout_num += 1
        # 修改时间
        self.gmt_modified = int(time.time() * 1000)
        # 保存修改
        self.save()


class LabelNode(BaseModel):
    """"""
    task = peewee.ForeignKeyField(LabelTask, backref="nodes")
    data = peewee.ForeignKeyField(DataInstance, backref="labels")
    label_data = MyJSONField(default={})
    is_labeled = peewee.BooleanField(default=False)
    data_disqualified = peewee.BooleanField(default=False)
    is_locked = peewee.BooleanField(default=False)
    is_blind_check = peewee.BooleanField(default=False)
    has_been_check = peewee.BooleanField(default=False)
    checked_label_qualified = peewee.IntegerField(default=-1)
    # todo 此修改是否合适
    # last_operator_id = peewee.IntegerField(default=0)
    last_operator = peewee.ForeignKeyField(User, backref="nodes", null=True)
    status = peewee.IntegerField(default=0)
    notes = peewee.CharField(default="")
    cut_word_notes = peewee.CharField(default="")
    check_operator_id = peewee.ForeignKeyField(User, backref="nodes", null=True)


    # operator_id = peewee.ForeignKeyField(User)

    class Meta:
        table_name = "lunar_label_node"

    @classmethod
    def get_node(cls, id=None, task_id=None, is_labeled=None, \
                 last_operator_id=None, data_ids=None, in_data=True):
        expression = []
        if id is not None:
            expression.append(cls.id == id)
        if task_id is not None:
            expression.append(cls.task_id == task_id)
        if is_labeled is not None:
            expression.append(cls.is_labeled == is_labeled)
        if last_operator_id is not None:
            expression.append(cls.last_operator_id == last_operator_id)
        if data_ids:
            if not in_data:
                clause = cls.data_id.not_in(data_ids)
            else:
                clause = cls.data_id.in_(data_ids)
            expression.append(clause)

        return cls.get_or_none(*expression)

    @classmethod
    def select_nodes(cls, id=None, task_id=None, is_labeled=None, \
                     last_operator_id=None, fields=None, distinct=False, \
                     data_ids=None, in_data=True, is_blind_check=None, \
                     has_been_check=None, checked_label_qualified=None, \
                     data_disqualified=None, status=None, check_operator_id=None):
        select_fields = []
        if fields is not None:
            select_fields = [getattr(cls, field) for field in fields]

        ms = cls.select(*select_fields)
        if distinct:
            ms = ms.distinct()

        expression = []
        if id is not None:
            expression.append(cls.id == id)
        if task_id is not None:
            expression.append(cls.task_id == task_id)
        if is_labeled is not None:
            expression.append(cls.is_labeled == is_labeled)
        if last_operator_id is not None:
            ms = ms.where(cls.last_operator_id == last_operator_id)
        if is_blind_check is not None:
            ms = ms.where(cls.is_blind_check == is_blind_check)
        if has_been_check is not None:
            ms = ms.where(cls.has_been_check == has_been_check)
        if checked_label_qualified is not None:
            ms = ms.where(cls.checked_label_qualified == checked_label_qualified)
        if data_disqualified is not None:
            ms = ms.where(cls.data_disqualified == data_disqualified)
        if status is not None:
            ms = ms.where(cls.status == status)
        if check_operator_id is not None:
            ms = ms.where(cls.check_operator_id == check_operator_id)
        if data_ids:
            if not in_data:
                clause = cls.data_id.not_in(data_ids)
            else:
                clause = cls.data_id.in_(data_ids)
            expression.append(clause)

        return ms.where(*expression)

    @classmethod
    def update_by_task(cls, task_id, data_set_id):
        """
        更新 task 节点
        """
        data_ids = cls.select(cls.data_id).where(
            cls.task_id == task_id
        )
        data_ids = [x.data_id for x in data_ids]
        return DataInstance.select().where(
            (DataInstance.data_set_id == data_set_id) &
            (DataInstance.id.not_in(data_ids))
        )

    def update_instance(self, data: dict):
        """
        更新node信息，只更改一次修改时间
        """
        for key in data.keys():
            if key != "id":
                self.__data__[key] = data[key]
        if self.gmt_modified is None:
            self.gmt_modified = int(time.time() * 1000)
        self.save()
        return self

    @classmethod
    def num_by_task(cls, task_id):
        """
        根据task id查询当前任务节点数
        """
        return cls.select().where(cls.task_id == task_id).count()

    @classmethod
    def remain_num_by_task(cls, task_id):
        """
        根据task id查询当前任务未标注节点数
        """
        return cls.select().where(
            (cls.task_id == task_id) &
            (cls.is_labeled == False)
        ).count()

    @classmethod
    def labeled_num_by_task(cls, task_id, bmts=-1, emts=-1):
        """
        """
        ms = cls.select().where(
            (cls.task_id == task_id) &
            (cls.is_labeled == True)
        )
        if bmts < 0 or emts < 0:
            return ms.count()
        return ms.where(cls.gmt_modified.between(bmts, emts)).count()

    @classmethod
    def today_labeled_num_by_task(cls, task_id, user_id):
        """
        获取user在task中，当天的标注量
        """
        # 当日时间戳
        today_date_str = datetime.strftime(datetime.now(), "%Y-%m-%d")
        # 当日开始和结束的毫秒级时间戳
        bmts, emts = cal_begin_and_end_mill_timestamp(today_date_str)
        return cls.select().where(
            (cls.task_id == task_id) &
            (cls.is_labeled == True) &
            (cls.last_operator_id == user_id) &
            (cls.gmt_modified.between(bmts, emts))
        ).count()

    @classmethod
    def user_labeled_count(cls, task_id, user_id, today=False):
        if not today:
            return cls.select().where(
                (cls.task_id == task_id) &
                (cls.is_labeled == True) &
                (cls.last_operator_id == user_id)
            ).count()
        else:
            # 当日时间戳
            today_date_str = datetime.strftime(datetime.now(), "%Y-%m-%d")
            # 当日开始和结束的毫秒级时间戳
            bmts, emts = cal_begin_and_end_mill_timestamp(today_date_str)
            return cls.select().where(
                (cls.task_id == task_id) &
                (cls.is_labeled == True) &
                (cls.last_operator_id == user_id) &
                (cls.gmt_modified.between(bmts, emts))
            ).count()

    @classmethod
    def user_blind_count(cls, task_id, user_id, today=False):
        if not today:
            return cls.select().where(
                (cls.task_id == task_id) &
                (cls.is_blind_check == True) &
                (cls.last_operator_id == user_id)
            ).count()
        else:
            # 当日时间戳
            today_date_str = datetime.strftime(datetime.now(), "%Y-%m-%d")
            # 当日开始和结束的毫秒级时间戳
            bmts, emts = cal_begin_and_end_mill_timestamp(today_date_str)
            return cls.select().where(
                (cls.task_id == task_id) &
                (cls.is_blind_check == True) &
                (cls.last_operator_id == user_id) &
                (cls.gmt_modified.between(bmts, emts))
            ).count()

    def assign_to(self, operator=None, check_operator=None):
        if operator is not None:
            self.last_operator = operator
            self.gmt_modified = int(time.time() * 1000)
        if check_operator is not None:
            self.check_operator_id = check_operator

        self.save()

    def commit(self, label_data, status=None, notes=None, is_blind_check=False, cut_word_notes=None):
        """
        节点提交，如果选择丢弃，修改status为3，is_label为1，label_data为空
        如果跳过，修改status为2，is_label为1
        如果是切词错误，修改status为5，is_label为1
        如果是质检不一致，修改status为4，data_disqualified为1，checked_label_qualified为0，has_been_check为1
        如果标注成功，is_label为1，修改status为1，data_disqualified为0
        """
        # 增加标注数据
        self.label_data = label_data
        # 修改数据为已标注
        # self.is_labeled = True if status!=NodeStatus.JUMP.value else False
        # 如果提交了标注状态就修改为对应状态，如果没有而且之前状态为默认值则修改为已标注
        if status:
            self.status = status
        elif self.status == NodeStatus.NOT_LABEL.value:
            self.status = NodeStatus.LABELED.value
        if notes:
            self.notes = notes
        if cut_word_notes:
            self.cut_word_notes = cut_word_notes
        # 修改是否为盲审节点
        self.is_blind_check = is_blind_check
        # data_disqualified 字段置为 False，提交及默认该数据质量没问题
        self.data_disqualified = False if status != NodeStatus.CHECK_ERROR.value else True

        if self.has_been_check:
            self.has_been_check = False
            self.check_operator_id = 0
        # 如果当前节点是第一次提交数据，需要修改如下数据
        if not self.is_labeled:
            # 更新 task_operator 数据
            lto = LabelTaskOperator.get(
                (LabelTaskOperator.task == self.task) &
                (LabelTaskOperator.operator == self.last_operator)
            )
            lto.commit(is_blind_check=is_blind_check)
            self.gmt_modified = int(time.time() * 1000)
            # 更新最后标注人和修改时间
            self.is_labeled = True
        # 保存修改
        self.save()

    def check(self, qualified, check_operator_id):
        """
        质检提交
        """
        # 修改 数据标注是否正确 字段
        check_flag = True if qualified == NodeStatus.LABELED.value else False
        # 如果已经质检过再次提交不修改checked_label_qualified
        if not self.has_been_check and self.checked_label_qualified==-1:
            self.checked_label_qualified = check_flag
        self.status = qualified
        self.data_disqualified = False if qualified != NodeStatus.CHECK_ERROR.value else True
        # 修改 数据是否被质检 字段
        self.has_been_check = True
        # 修改时间
        self.check_operator_id = check_operator_id
        # 当前节点为盲审节点并且质检结果正确，需要修改如下数据
        if self.is_blind_check:
            lto = LabelTaskOperator.get(
                (LabelTaskOperator.task == self.task) &
                (LabelTaskOperator.operator == self.last_operator)
            )
            lto.check(check_flag)
        # 保存数据
        self.save()

    def reset(self):
        """
        重置节点
        """
        self.label_data = {}
        self.is_labeled = False
        self.data_disqualified = False
        self.has_been_check = False
        self.checked_label_qualified = False
        self.last_operator_id = 0
        self.save()

    def to_dict(self):
        d = super().to_dict()
        d["name"] = self.task.name
        d["task_template"] = self.task.task_template
        return d

    def to_check(self):
        """
        输出给质检
        """
        d = {}
        d["id"] = self.id
        d["data"] = self.data.data
        d["label_data"] = self.label_data
        d["task_template"] = self.task.task_template
        return d

    def to_look(self):
        d = super().to_dict()
        d["name"] = self.task.name
        d["data"] = self.data.data
        d["label_data"] = self.label_data
        d["task_template"] = self.task.task_template
        d["pre_label_task_data"] = self.get_pre_label_data()[0] if self.get_pre_label_data() else None
        return d

    def get_pre_label_data(self, use_model=False):
        """
        """
        task = self.task

        use_pre_label = task.use_pre_label
        task_type = task.task_type.name
        task_data_type = task.data_set.data_set_type.name
        task_data = self.data.data
        empty_res = []
        if not use_pre_label:
            return empty_res
        if not task_data:
            return empty_res
        # 创建预标注
        pld = PreLabelData(
            task_type,
            rules=task.get_rules(),
            labels=task.get_labels(),
            use_model=use_model
        )
        data, err = pld.get_data(task_data_type, task_data)
        return data if err is None else empty_res


LabelTask.instance_resource = LabelNode


class LabelRuleType(Enum):
    KEYWORD = "keyword"
    REGULAR = "regular"
    HEURISTIC = "heuristic"
    NER = "ner"
    TEXTBLOB = "textblob"
    SNOWNLP = "snownlp"


class LabelRule(BaseModel):
    """"""
    type = peewee.CharField()
    num = peewee.IntegerField()
    task = peewee.ForeignKeyField(LabelTask, backref="rules")
    match_label = peewee.CharField()
    not_match_label = peewee.CharField()
    params = MyJSONField(default="")
    contain = peewee.CharField()

    class Meta:
        table_name = "lunar_label_rule"

    @classmethod
    def get_task(cls, task_id):
        """
        """
        return LabelTask.get_or_none(LabelTask.id == task_id)

    @classmethod
    def max_num(cls, task_id):
        """
        根据任务获取最大的num
        """
        ms = cls.select(cls.num).distinct().where(cls.task_id == task_id)
        ms = ms.order_by(cls.num.desc())
        return ms[0].num if ms else 0

    def to_file(self):
        return {
            "num": self.num,
            "type": self.type,
            "match_label": self.match_label,
            "not_match_label": self.not_match_label,
            **self.params
        }
