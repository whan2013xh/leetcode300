

from lunar.models.base import BaseModel
from lunar.models.user import Role, User, RoleType, Group, GroupUser
from lunar.models.dataset import DataSetType, DataSet, DataInstance
from lunar.models.label_task import LabelTaskType, LabelTask, LabelNode, \
    LabelTaskOperator, LabelRule, LabelRuleType, NodeStatus
from lunar.models.async_task import AsyncTask

reg_models = [User, Role, Group, GroupUser,
              DataSet, DataInstance, DataSetType,
              LabelNode, LabelTask, LabelTaskType, LabelTaskOperator, LabelRule, NodeStatus]
