import time
import peewee

from lunar.models.base import BaseModel, BaseSetMixin
from lunar.models.user import Group
from lunar.models.base import MyJSONField
from lunar.utils import uuid5_hash
from lunar.logger import logger


class DataSetType(BaseModel):
    name = peewee.CharField(unique=True)
    info = peewee.CharField(default="")

    class Meta:
        table_name = "lunar_data_set_type"
    
    def to_basic_dict(self):
        res = {
            "id": self.id,
            "name": self.name
        }
        return res


class LabelTaskType(BaseModel):
    name = peewee.CharField()
    bind_data_type = peewee.ForeignKeyField(DataSetType, backref="label_task_types")
    info = peewee.CharField(default="")

    class Meta:
        table_name = "lunar_label_task_type"
    
    @classmethod
    def get_types_by_bind_id(cls, bind_data_type_id, pk=False):
        result = cls.select().where(cls.bind_data_type_id == bind_data_type_id)
        if pk:
            return [x.id for x in result]
        return result


class DataSet(BaseModel, BaseSetMixin):
    """"""
    name = peewee.CharField(unique=True)
    data_set_type = peewee.ForeignKeyField(DataSetType, backref='data_sets')
    owner = peewee.ForeignKeyField(Group, backref="data_sets")
    is_usable = peewee.BooleanField(default=False)
    error_message = peewee.CharField(default="")
    info = peewee.CharField(default="")
    amount = peewee.IntegerField(default=0)
    minio_path = peewee.CharField(default="")

    set_key = "data_set"

    class Meta:
        table_name = "lunar_data_set"
    
    @property
    def length(self):
        return DataInstance.select().where(DataInstance.data_set == self).count()
    
    def get_origin_data(self, field="text", limit=1000):
        """
        获取该数据集下的所有数据
        """
        instances = []
        for offset in range(0, self.length, limit):
            tmp_instances = DataInstance.select().\
                                        where(DataInstance.data_set == self).\
                                        order_by(DataInstance.id.asc()).\
                                        offset(offset).limit(limit)
            instances.extend([instance.data[field] for instance in tmp_instances])
        return instances
    
    def execute_success(self):
        """
        执行成功
        """
        self.amount = DataInstance.select().where(DataInstance.data_set_id == self.id).count()
        self.is_usable = True
        self.save()
    
    def execute_error(self, error_message, append=False):
        """
        执行错误
        """
        self.error_message = error_message
        if not append:
            self.is_usable = False
        self.save()
    
    def to_detailed_dict(self):
        d = self.to_dict()
        update_dict = {
            "data_set_type": self.data_set_type.name,
            # "data_length": DataInstance.select().where(DataInstance.data_set_id == self.id).count(),
            "data_length": self.amount,
            "owner": self.owner.name,
            "tasks": [t.to_dict() for t in self.tasks]
        }
        d.update(update_dict)
        return d
    
    def to_basic_dict(self):
        res = {
            "id": self.id,
            "name": self.name
        }
        return res
    
    def exist_task(self, task=None, other_task_label=None):
        tasks = self.tasks
        if task is None and other_task_label is None:
            return bool(self.tasks)
        return task in tasks if other_task_label is None else len(self.tasks)>1


class DataInstance(BaseModel):
    """"""
    data = MyJSONField(default="")
    data_set = peewee.ForeignKeyField(DataSet, backref="instances")
    extra_info = MyJSONField(default="")
    frame_index = peewee.IntegerField(default=0)
    data_code = peewee.CharField(unique=True)

    class Meta:
        table_name = "lunar_data_instance"

    def is_tasked(self):
        """
        是否已被分配到某个task
        """
        labels = self.labels
        return True if labels else False

    def is_labeled(self):
        """
        是否已被标注
        """
        if not self.is_tasked():
            return False
        # 如果被分配到某个task，说明，label是存在的
        labels = self.labels

        return labels[0].is_labeled

    @classmethod
    def create_instance(cls, data: dict):
        cur_time = int(time.time() * 1000)
        data["gmt_create"] = cur_time
        data["gmt_modified"] = cur_time
        data["data_code"] = uuid5_hash(f"{data.get('data')}_{data.get('data_set')}")
        # instance = cls(**data)
        instance, _ = cls.get_or_create(**data)
        # instance.save()
        return instance

    @classmethod
    def create_instances(cls, data: list):
        length = len(data)

        if length == 0:
            return {"insert_num": len(data)}
        count = 0
        for batch in peewee.chunked(data, 1000):
            cls.add_time(batch)
            tmp_length = cls.insert_many(batch).on_conflict(
             update={cls.data_code:cls.data_code}).execute()
            count+=tmp_length
            # cls.replace_many(batch).execute()
        logger.info(f"data set instance insert_num {count}, lemgth {length}")
        return {"insert_num": count}

    @classmethod
    def add_time(self, batch: list, value=None):
        value = value if value is not None else int(time.time() * 1000)
        for x in batch:
            x["gmt_create"] = value
            x["gmt_modified"] = value
            x["data_code"] = uuid5_hash(f"{x.get('data')}_{x.get('data_set')}")


DataSet.instance_resource = DataInstance
