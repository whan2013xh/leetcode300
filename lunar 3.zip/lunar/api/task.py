from lunar.api.async_task import AsyncTaskApi
from lunar.api.base import PeeweeApi, SetApi, json_response
from lunar.models import LabelNode, LabelTask, LabelTaskType, \
    User, LabelTaskOperator, DataSet, RoleType, AsyncTask, \
    Group, GroupUser, NodeStatus, DataSetType, DataInstance
from lunar import auth
from lunar.utils import response_normalize, format_mill_timestamp, \
    cal_begin_and_end_mill_timestamp, uuid5_hash
from lunar.logger import logger
from lunar.config import config
import time
from itertools import groupby
import os
import sys
import pathlib
import json
import copy
from datetime import timedelta, datetime

import numpy as np
from peewee import fn

sys.path.append(str(pathlib.Path(__file__).parents[2]))
from lunar.db import db
from lunar.mio import OssFile
from lunar.fileio import RequestFile, TmpFile, URLFile
from lunar.utils import get_current_begin_mill_timestamp, to_bool
from lunar.nlp.autolabel.label_data import snorkel_predict_pd
from lunar.celery.task import config_task, export_task, delete_label_task, \
    export_snorkel_task, excel_instances, delete_async_task, delete_dataset, web_file_instances
from lunar.data import get_pre_label_data, segement
from lunar.nlp.nlp_basic import segment_text, parse_text


def snorkel_file(request):
    """
    """
    data, _ = LabelTaskApi()._snorkel_file(request, None)
    if not data:
        return None
    if len(data) == 1 and "msg" in data:
        return None
    if "data" not in data:
        return None
    return data["data"]


# @auth.authorized
def export_rule(request):
    """
    """
    data, _ = LabelTaskApi()._export_rule(request, request.args.get("id"))
    if not data:
        return []
    if len(data) == 1 and "msg" in data:
        return []
    if "data" not in data:
        return []
    return data["data"]


# @auth.authorized
def export_labeled_data(request):
    data, _ = LabelTaskApi()._export(request, request.args.get("id"))
    if not data:
        return [], "empty"
    if len(data) == 1 and "msg" in data:
        return [], "empty"
    if "instances" not in data:
        return [], "empty"
    return data["instances"], data["name"]


# @auth.authorized
def stat_task(request):
    data, _ = LabelTaskApi()._stat_task(request, page=False)
    if not data:
        return []
    if len(data) == 1 and "msg" in data:
        return []
    if "data" not in data:
        return []
    return data["data"]


# @auth.authorized
def stat_task_operator(request):
    data, _ = LabelTaskApi()._stat_task_operator(request, page=False)
    if not data:
        return []
    if len(data) == 1 and "msg" in data:
        return []
    if "data" not in data:
        return []
    return data["data"]


class LabelTaskApi(SetApi):
    """
    标注任务API入口
    """
    _resource = LabelTask
    decorators = [auth.authorized, response_normalize, json_response]
    extract_action = {
        "post": ["update", "config_task", "stat_task_operator", "stat_task",
                 "create_task", "snorkel_file", "snorkel", "cascade_delete", "cascade_create", "export_task",
                 "cascade_append"],
        "get": ["complete", "export", "stat_single_task", "task_for_user",
                "next_node", "check_for_user", "next_check", "labeled_node",
                "oss_export", "detailed_list", "export_rule", "next_multi_node", "next_qa_node", "get_home_pages",
                "next_video_node", "get_task_list", "modify_label_node", "modify_label_node2", "modify_instance_code"]
    }
    url_name = _resource.__name__
    # 返回数据字段
    # export_fields = ["id", "nodes"]
    export_instance_fields = ["data_set_id", "data", "data_set"]
    export_label_fields = ["id", "data_id", "data", "task_id", "last_operator_id",
                           "label_data", "is_labeled", "has_been_check", "data_disqualified"]
    # 创建任务时必备字段
    required_fields = ["name", "task_type", "data_set", "task_template", "owner_id"]
    # 文本和非文本名称
    export_excel_types = ["text", "qa-top10"]
    export_json_types = ["image", "voice", "video"]

    def _modify_instance_code(self, request, resource_id):
        ms = DataInstance.select().where(DataInstance.data_code == None).order_by(DataInstance.data_set)
        total = ms.count()
        page = 1000
        count = 0
        for i in range(total // page + 1):
            page_records = ms.limit(page).offset(i)
            for record in page_records:
                code = uuid5_hash(f"{record.data}_{record.data_set_id}_{str(count)}")
                count += 1
                record.data_code = code
                record.save()
            logger.info(f"modify_instance_code count: {i * page}")
        return {"count": total}, 200

    def _modify_label_node(self, request, resource_id):
        import math
        params = request.args
        task_id = params.get("task_id")
        ms = LabelNode.select().where(
            (LabelNode.task == task_id) & (LabelNode.is_labeled == True) & (LabelNode.notes != "change_range") & (
                    LabelNode.status != 3))
        total = ms.count()
        page = 1000
        pages= math.ceil(total/page)
        for i in range(pages):
            page_records = ms.limit(page).offset(i)
            for record in page_records:
                label_data = record.label_data
                if record.id == 2998262:
                    print()
                slots = label_data.get("slots")
                if slots is None or len(slots) < 1:
                    continue
                for slot in slots:
                    range_info = slot.get("range")
                    range_info[1] += 1
                    slot["range"] = range_info
                record.notes = "change_range0928"
                record.save()
            logger.info(f"change label node count: {i * page}")
        return {"count": total}, 200

    def _modify_label_node2(self, request, resource_id):
        params = request.args
        task_id = params.get("task_id")
        value = "value"
        ms = LabelNode.select().where(
            (LabelNode.task == task_id) & (LabelNode.is_labeled == True)  & (
                    LabelNode.status != 3)).order_by(LabelNode.id)
        total = ms.count()
        # tmp = LabelNode.select().where(LabelNode.id==3045377)
        logger.info(f"total {total}")
        page = 1000
        count = 0
        res = []
        import math
        pages = math.ceil(total/page)
        total_ids = []
        for i in range(pages):
            page_records = ms.limit(page).offset(i * page)
            # tmp_list = [record.to_dict() for record in page_records]
            for record in page_records:
                flag = False
                label_data = record.label_data
                slots = label_data.get("slots")
                total_ids.append(record.id)
                if slots is None or len(slots) < 1:
                    continue
                for slot in slots:
                    range_info = slot.get("range")
                    if range_info[1] - range_info[0] < len(slot.get("value")):
                        flag = True
                        continue
                        # range_info[1] += 1
                        # slot["range"] = range_info
                if flag:
                    res.append(record.id)
                    record.notes = "change_range0928"
                    record.data_disqualified = True
                    record.status = 3
                    record.save()
                    count += 1

            logger.info(f"change label node page{i} count: {i * page},total {pages}")
            logger.info(f"change  count: {count}")
        logger.info(f"real total {len(list(set(res)))}")
        logger.info(f"change  count: {count}, total {len(total_ids)}, real {len(list(set(total_ids)))}")
        return {"count": total}, 200

    def _get_home_pages(self, request, resource_id, time_scope=7):
        """
        获取首页需要展示的信息，包括活跃人数、任务数量、标注节点
        """
        # 1、获取活跃用户
        cur_day = int(time.mktime(datetime.now().date().timetuple())) * 1000
        last_week_day = int(time.mktime((datetime.now() - timedelta(days=7)).date().timetuple())) * 1000
        active_users = User.select().where(User.gmt_modified.between(last_week_day, cur_day)).count()
        # 2、获取可执行任务和任务总数
        total_tasks = LabelTask.select().where((LabelTask.is_usable == True))
        tasks_num = total_tasks.count()
        active_tasks = tasks_num - total_tasks.where((LabelTask.is_completed == True)).count()
        # 3、获取带标注数据量
        # total_nodes = LabelNode.select().where(1 == 1).count()
        active_nodes = LabelNode.select().where(LabelNode.is_labeled == False).count()
        # 4、获取过去一周文本、图像标注量
        text_info = []
        image_info = []
        task_ids = LabelNode.select(LabelNode.task).distinct().where(
            (LabelNode.gmt_modified.between(last_week_day, cur_day)) &
            (LabelNode.is_labeled == True)
        )
        active_task_ids = [task_id.task.id for task_id in task_ids if task_id.task is not None]

        text_task_types = LabelTaskType.select().where(LabelTaskType.bind_data_type != 1)
        text_type_ids = [task_type.id for task_type in text_task_types]
        # image_task_types = LabelTaskType.select().where(LabelTaskType.bind_data_type==1)
        # image_type_ids = [task_type.id for task_type in image_task_types]
        text_task_ids = []
        image_task_ids = []
        if len(task_ids) > 0:
            for task_id in active_task_ids:
                cur_task = LabelTask.select().where(LabelTask.id == task_id)
                if cur_task[0].task_type.id in text_type_ids:
                    text_task_ids.append(task_id)
                else:
                    image_task_ids.append(task_id)

        for i in range(1, time_scope + 1):
            begin_time = int(time.mktime((datetime.now() - timedelta(days=i)).date().timetuple())) * 1000
            begin_end = int(time.mktime((datetime.now() - timedelta(days=(i - 1))).date().timetuple())) * 1000 - 1
            label_text_num = LabelNode.select().where(
                (LabelNode.task.in_(text_task_ids)) & (LabelNode.is_labeled == True) & (
                    LabelNode.gmt_modified.between(begin_time, begin_end))).count()
            label_image_num = LabelNode.select().where(
                (LabelNode.task.in_(image_task_ids)) & (LabelNode.is_labeled == True) & (
                    LabelNode.gmt_modified.between(begin_time, begin_end))).count()
            text_info.append(label_text_num)
            image_info.append(label_image_num)
        task_records = LabelTask.select(LabelTask.task_type_id, fn.COUNT(1).alias("task_nums"),
                                        fn.SUM(LabelTask.amount).alias("amount")).where(
            LabelTask.is_usable == True).group_by(LabelTask.task_type)
        task_infos = {record.task_type_id: record.task_nums for record in task_records}
        node_infos = {record.task_type_id: record.amount for record in task_records}
        task_info = {
            "pic_normal": task_infos.get(2, 0) + task_infos.get(3, 0) + task_infos.get(4, 0) + task_infos.get(5, 0),
            "pic_ocr": task_infos.get(9, 0) + task_infos.get(10, 0),
            "text_classify": task_infos.get(6, 0),
            "reapu": task_infos.get(1, 0),
            "video": task_infos.get(11, 0) + task_infos.get(12, 0) + task_infos.get(13, 0) + task_infos.get(14, 0),
        }
        task_info["others"] = sum(list(task_infos.values())) - sum(list(task_info.values()))
        sum_info = {
            "total": sum(list(node_infos.values())),
            "pic": node_infos.get(2, 0) + node_infos.get(3, 0) + node_infos.get(4, 0) + node_infos.get(5,
                0) + node_infos.get(9, 0) + node_infos.get(10, 0),
            "text": node_infos.get(1, 0) + node_infos.get(6, 0) + node_infos.get(7, 0) + node_infos.get(8,
                0) + node_infos.get(15, 0) + node_infos.get(16, 0) + node_infos.get(17, 0),
            "video": node_infos.get(11, 0) + node_infos.get(12, 0) + node_infos.get(13, 0) + node_infos.get(14, 0)
        }
        page_info = {
            "user_nums": active_users,
            "total_tasks": tasks_num,
            "active_tasks": active_tasks,
            "total_nodes": sum(list(node_infos.values())),
            "active_nodes": active_nodes,
            "text_info": text_info,
            "image_info": image_info,
            "task_info": task_info,
            "sum_info": sum_info
        }
        return page_info, 200

    def _snorkel(self, request, resource_id):
        """
        使用弱监督标注文件，并导出文件
        """
        user = request.headers["user"]
        # 获取参数
        req_data = self.get_request_json(request)
        # 获取任务 id
        task_id = req_data["id"]
        task = self._resource.get_or_none(self._resource.id == task_id)
        if task is None:
            return {"msg": "task not exist"}, 200
        # 获取该任务下的所有规则
        rules = task.get_rules()
        if rules is None:
            return {"msg": "rule not exist"}, 200
        if rules.count() < 3:
            return {"msg": "rule quantity insufficient"}, 200
        # 获取 labels
        labels = task.get_labels()
        if not labels:
            return {"msg": "label not exist"}, 200
        # 异步执行 snorkel 标注
        file_path = f"lunar/export/{user.name}/snorkel_{task.name}.xlsx"
        # 获取bucket
        bucket = config["minio_bucket"]
        url, err = OssFile().presigned_get_object(bucket, file_path, expiry=timedelta(days=7))
        if err is not None:
            return {"msg": err}, 200
        task_name = f"导出自动标注任务数据【任务名称：{task.name}, 下载路径: {url}】"
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = f"导出任务规则{task.name}" + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        result = export_snorkel_task.delay(task.id, file_path, info=info, atid=id)
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})
        return {"path": url, "async_id": result.id, "name": task.name}, 200

    def _snorkel_file(self, request, resource_id):
        """
        使用弱监督标注文件，并导出文件
        """
        req_data = self.get_request_form(request)
        # 获取任务 id
        task_id = req_data["id"]
        task = self._resource.get_or_none(self._resource.id == task_id)
        if task is None:
            return {"msg": "task not exist"}, 200
        # 获取带标注文件
        snorke_file = request.files.get("snorkelFile")
        if snorke_file is None:
            return {"msg": "file not exist"}, 200
        # 获取该任务下的所有规则
        rules = task.get_rules()
        if rules is None:
            return {"msg": "rule not exist"}, 200
        if rules.count() < 3:
            return {"msg": "rule quantity insufficient"}, 200
        # 获取文件数据
        file_data, err = RequestFile(snorke_file).read()
        if err is not None:
            return {"msg": err}, 200
        if "text" not in file_data:
            return {"msg": "`text` field is required"}, 200
        # 获取 labels
        labels = task.get_labels()
        if not labels:
            return {"msg": "label not exist"}, 200
        # 执行 snorkel 标注
        rules = [x.to_dict() for x in rules]
        preds, probs, seg_list, hits = snorkel_predict_pd(rules, labels, file_data, use_model=True)
        # 组织返回数据
        data = {
            "text": file_data["text"].tolist(),
            "label": preds,
            "probability": [max(prob) if len(set(prob)) != 1 else -1 for prob in probs],
            "hits": [{k: [x[1] for x in v] for k, v in groupby(sorted(ld, key=lambda x: x[0]), key=lambda x: x[0])} for
                     ld in hits],
            "segment": [" ".join(seg) for seg in seg_list]
        }
        return {"data": data}, 200

    def _create_task(self, request, resource_id):
        """
        通过上传 task_template
        """
        owner = request.headers["user"]
        data = self.get_request_form(request, only=True)
        # check key exists
        params, err = self.check_data(data, owner, template=False)
        if err is not None:
            return {"msg": err}, 200
        # 检查 file
        files = self.get_request_files(request)
        template_file = files.get("templateFile")
        if template_file is None:
            return {"msg": "template file not exist"}, 200
        # 获取文件数据
        request_file = RequestFile(template_file, schema_type="excel")
        file_data, err = request_file.read(keep_default_na=False)
        if err is not None:
            return {"msg": err}, 200
        # 检查格式是否正确
        try:
            # 一级标签
            if 'slot_key' not in file_data.columns:
                keys, values = file_data["key"].tolist(), file_data["value"].tolist()
                if 'priority' in file_data.columns:
                    prioritys = file_data["priority"].tolist()
                    params["task_template"] = {
                        "labels": [{"key": k, "value": v, "priority": priority} for k, v, priority in
                                   zip(keys, values, prioritys)]}
                else:
                    params["task_template"] = {"labels": [{"key": k, "value": v} for k, v in zip(keys, values)]}
            else:
                first_label_key, first_label_value, second_label_key, second_label_value = \
                    file_data["label_key"].tolist(), file_data["label_value"].tolist(), \
                    file_data["slot_key"].tolist(), file_data["slot_value"].tolist()
                label_info = []
                visited_labels = []
                sub_label = []
                current_label = None
                last_label = None
                # 二级标签
                for label_key, label_value, second_key, second_value in zip(first_label_key, first_label_value,
                                                                            second_label_key, second_label_value):
                    if label_key not in visited_labels:
                        visited_labels.append(label_key)
                        last_label = current_label
                        current_label = {"key": label_key, "value": label_value}
                        if last_label:
                            if params.get("task_type").name not in ["reapu", "text_sequence"]:
                                last_label["sub_label"] = sub_label
                            else:
                                last_label["slots"] = sub_label
                            label_info.append(last_label)
                            sub_label = []
                    if second_key:
                        sub_label.append({"key": second_key, "value": second_value})
                params["task_template"] = {"labels": label_info}
        except:
            return {"msg": "file format error, `key` and `value` is required"}, 200

        # execute
        try:
            r = self._resource.create_instance(params)
            return r.to_dict(), 200
        except Exception as e:
            logger.exception(e)
            return {"msg": f"create data_instances failed"}, 200

    def _export_rule(self, request, resource_id):
        """
        导出规则数据
        """
        # 判断任务是否存在
        task = self._resource.get_or_none(self._resource.id == resource_id)
        if task is None:
            return {"msg": "task not exist"}, 200
        # 判断规则是否存在
        rules = task.get_rules()
        if not rules:
            return {"msg": "task rule not exist"}, 200
        # 组织返回数据
        data = [x.to_file() for x in rules]

        return {"data": data, "size": len(data)}, 200

    def _detailed_list(self, request, resource_id=None):
        """
        数据集详细信息列表
        """
        user = request.headers["user"]
        # 获取当前用户权限
        role_type = user.role.name
        # 请求数据
        req_args = request.args
        text = req_args.get("text", "")
        # limit
        limit = req_args.get("limit")
        limit = int(limit) if limit and limit.isdigit() else 10
        # offset
        offset = req_args.get("offset")
        offset = int(offset) if offset and offset.isdigit() else 0
        # data_set_type_id
        data_set_type_id = req_args.get("data_set_type_id")

        # 开始构建搜索条件
        expressions = []
        expressions.append(self._resource.data_set != -1)
        # 获取任务种类
        if data_set_type_id is not None:
            # task_type_ids = LabelTaskType.get_types_by_bind_id(data_set_type_id, pk=True)
            # 获取图片和视频标注任务
            task_type = LabelTaskType.select().where(LabelTaskType.bind_data_type.in_([1, 4]))
            task_type_ids = [label_task_type.id for label_task_type in task_type]
            expressions.append(self._resource.task_type_id.in_(task_type_ids))
        else:
            task_type_ids = [label_task.id for label_task in
                             LabelTaskType.select().where(LabelTaskType.bind_data_type.not_in([1, 4]))]
            expressions.append(self._resource.task_type_id.in_(task_type_ids))

        if role_type == RoleType.OPERATORLDE.value:
            task_operators = LabelTaskOperator.select().where(LabelTaskOperator.operator == user.id)
            task_ids = [task_operator.task.id for task_operator in task_operators]
            expressions.append(self._resource.id.in_(task_ids))
            if text:
                expressions.append(self._resource.name ** f"%{text}%")
        elif role_type != RoleType.ADMIN.value and role_type != RoleType.MANAGER.value:
            # 如果是非 admin 和 manager 权限，只能搜索当前用户的数据
            group_ids = [group_user.group.id for group_user in user.group_users]
            expressions.append(self._resource.owner_id.in_(group_ids))
            if text:
                expressions.append(self._resource.name ** f"%{text}%")
        else:
            if text:
                gms = Group.select().where(Group.name ** f"%{text}%")
                gids = [x.id for x in gms]
                expressions.append(
                    (self._resource.name ** f"%{text}%") |
                    (self._resource.owner_id.in_(gids))
                )
        if expressions:
            tms = self._resource.select().where(*expressions)
        else:
            tms = self._resource.select()

        total = tms.count()
        ptms = tms.order_by(self._resource.id.desc()).limit(limit).offset(offset)
        data = [x.to_detailed_dict() for x in ptms]

        return {"total": total, "data": data, "limit": limit, "offset": offset}, 200

    def _get_task_list(self, request, resource_id=None):
        """
        数据集详细信息列表
        """
        # 请求数据
        req_args = request.args
        name = req_args.get("name", "")
        # limit
        limit = req_args.get("limit")
        limit = int(limit) if limit and limit.isdigit() else 10
        # offset
        offset = req_args.get("offset")
        offset = int(offset) if offset and offset.isdigit() else 0
        # data_set_type_id
        task_type = req_args.get("taskType")
        group = req_args.get("owner")
        group_info = Group.select().where((Group.name == group) & (Group.is_deleted == 0))
        if len(group_info) < 1:
            return {"msg": "group not exist"}, 200

        # 开始构建搜索条件
        expressions = []
        expressions.append(self._resource.owner == group_info[0].id)
        expressions.append(self._resource.data_set != -1)
        # 获取任务种类
        if task_type is not None:
            # task_type_ids = LabelTaskType.get_types_by_bind_id(data_set_type_id, pk=True)
            # 获取图片和视频标注任务
            task_type = LabelTaskType.select().where(LabelTaskType.name == task_type)
            if len(task_type) < 1:
                return {"msg": "task type not correct"}, 200
            expressions.append(self._resource.task_type_id == task_type[0].id)

        if name:
            expressions.append(self._resource.name ** f"%{name}%")
        if req_args.get("data_set_id"):
            expressions.append(self._resource.data_set == req_args.get("data_set_id"))
        if req_args.get("use_pre_label"):
            expressions.append(self._resource.use_pre_label == 1)
        if expressions:
            tms = self._resource.select().where(*expressions)
        else:
            tms = self._resource.select()

        total = tms.count()
        ptms = tms.order_by(self._resource.id.desc()).limit(limit).offset(offset)
        data = []
        for task_info in ptms:
            res = {
                "id": task_info.id,
                "async_id": 0,
                "status": "success",
                "name": task_info.name,
                "data_type": task_info.data_set.data_set_type.name,
                "task_type": task_info.task_type.info,
                "domain": task_info.domain
            }
            data.append(res)
        # data = [x.to_detailed_dict() for x in ptms]

        return {"data": {"total": total, "tasks": data, "limit": limit, "offset": offset}}, 200

    def _oss_export(self, request, resource_id):
        """
        导出标注数据到 对象存储
        """
        owner = request.headers["user"]
        data, code = self._export(request, resource_id)
        if not data:
            return {"msg": f"unknown error."}, 200
        if len(data) == 1 and "msg" in data:
            return data, code
        if "instances" not in data:
            return data, code
        instances = data["instances"]
        if not instances:
            return {"msg": f"data for exporting not exist."}, 200

        # 导出一个总的文件
        name = data["name"]
        export_name = name + "_export.json"
        tmp_name = name + "_" + owner.name + "_" + str(int(time.time() * 1000))

        # 存储桶
        file_path = instances[0]["data"].get("path")
        if not file_path:
            return {"msg": f"the task not support oss export."}, 200
        spills = file_path.split("/")
        bucket = spills[1]
        path_dir = "/".join(spills[2:-1])
        object_name = os.path.join(path_dir, export_name)
        # 写入临时文件
        # data_str = json.dumps(data, ensure_ascii=False, indent=4)
        tmp_file = TmpFile(tmp_name)
        tmp_file.write_json(data)
        request.headers["tmp_file_path"] = tmp_file.file_path

        err = OssFile().fput_object(
            bucket, object_name, tmp_file.file_path,
            content_type="application/json"
        )

        return {
                   "msg": f"export into oss successfully, total={len(instances)}",
                   "success": True
               }, 200

    def _labeled_node(self, request, resource_id):
        """
        返回一个已经被标注的节点
        不区分该节点是否被质检，按id返回第一个被标注的节点
        """
        # 查看任务是否存在
        try:
            task = self._resource.get_by_id(resource_id)
        except Exception as e:
            logger.info(e)
            return {"msg": f"the task not exist: id={resource_id}"}, 200
        # 查看任务是否开始
        if task.gmt_begin is None:
            return {"msg": f"the task has not started: name={task.name}"}, 200
        # 获取已经标注的节点
        labeled_nodes = [node for node in task.nodes if node.is_labeled]
        if labeled_nodes is None:
            return {"msg": f"the task has not labeled: name={task.name}"}, 200

        return labeled_nodes[0].to_check(), 200

    def _next_check(self, request, resource_id=None):
        """
        生成一个质检节点
        交叉（对应数字为 1）：返回两个节点的相应信息
        单一（对应数字为 2）：返回一个节点的相应信息（根据每个操作人的已标注数据和盲审率，生成相应数量的盲审节点）
        """
        # 检查任务是否存在
        task = self._resource.get_or_none(self._resource.id == resource_id)
        user = request.headers.get("user")
        if task is None:
            return {"msg": "task not exist"}, 200
        # 如果任务已经 complete，直接返回
        if task.is_completed:
            return {"msg": "task had checked completely"}, 200
        # 返回
        num = 10 if task.task_type.name == "text_classify" else 1
        return self._next_check_nodes(task, num=num, operator=user)

    def _next_check_nodes(self, task, num, operator=None):
        nodes, err = self._get_check_nodes(task, num, operator)
        if err is not None:
            return {"msg": err}, 200

        # 组织返回数据
        res = {
            "task_id": task.id,
            "task_name": task.name,
            "task_type": task.task_type.name,
            "blind_check_type": task.blind_check_type,
            "data_type": task.task_type.bind_data_type.name,
            "task_template": task.task_template,
            "nodes": [node.to_check() for node in nodes]
        }
        return res, 200

    def _get_check_nodes(self, task, num, operator):
        # 盲审方式 和 盲审率：盲审方式
        blind_check_type = task.blind_check_type
        # 根据 质检方式
        if blind_check_type == 1:
            nodes = self._next_cross_check(task, operator=operator)
        elif blind_check_type == 2:
            nodes = self._next_single_check(task, num, operator=operator)
        else:
            return None, "blind check type not exist"
        if nodes is None:
            flag = task.had_completed()
            if flag:
                task.check_complete()
                return None, "task had checked completely"
            else:
                return None, "check data not exist"

        return nodes, None

    def _next_cross_check(self, task, operator=None):
        """
        生成两个交叉检验方式的节点
        """
        # 还未被质检的盲审节点
        not_check_nodes = LabelNode.select_nodes(
            task_id=task.id, is_labeled=True,
            is_blind_check=True, has_been_check=False
        ).order_by(LabelNode.gmt_modified.asc())
        # 排序
        not_check_nodes = sorted(not_check_nodes, key=lambda x: x.data_id)
        # 分组
        ngb = groupby(not_check_nodes, key=lambda x: x.data_id)
        for _, l in ngb:
            nodes = list(l)
            if len(nodes) != 2:
                continue
            if nodes[0].label_data == nodes[1].label_data:
                continue
            return nodes
        return None

    def _next_single_check(self, task, num, operator=None):
        """
        返回一个单一检查方式的节点
        """
        # 查找已经被置为盲审节点，但是被未被质检的节点
        # 单一检查方式中，如果一个节点是盲审节点，表示该节点已经被标注了
        start1 = time.time()
        # num = 5 if num<5 else num
        unassigned_nodes = LabelNode.select_nodes(
            task_id=task.id, is_blind_check=True
        ).limit(num)
        logger.info(
            f"next_single_check : {round((time.time() - start1) * 1000, 2)}ms")
        if not unassigned_nodes:
            return None
        unassigned_nodes = LabelNode.select_nodes(
            task_id=task.id, is_blind_check=True, check_operator_id=operator.id, has_been_check=False
        ).limit(num)
        if unassigned_nodes:
            return unassigned_nodes
        start2 = time.time()
        # 循环获取节点
        while 1:
            # 获取未标注的节点中，还未分配给其他操作人的节点
            not_check_nodes = LabelNode.select_nodes(
                task_id=task.id, is_blind_check=True, has_been_check=False, check_operator_id=0
            ).order_by(LabelNode.gmt_modified.asc()).limit(num)
            if not not_check_nodes.count():
                return None
            logger.info(
                f"next_single_check 4 : {round((time.time() - start2) * 1000, 2)}ms")
            # 锁定，如果发生错误，则循环
            try:
                unassigned_nodes = not_check_nodes.for_update(nowait=True)
                # node_ids = [node.id for node in unassigned_nodes]
                logger.info(
                    f"next_single_check 3 : {round((time.time() - start2) * 1000, 2)}ms")
                # LabelNode.update({"check_operator_id":operator.id}).where((LabelNode.task_id==task.id)&(LabelNode.is_blind_check==True)&(LabelNode.id in node_ids))
                start3 = time.time()

                for unassigned_node in unassigned_nodes:
                    unassigned_node.assign_to(check_operator=operator.id)
                    # logger.info(
                    #     f"next_single_check 7 : {round((time.time() - start3) * 1000, 2)}ms")
                    # unassigned_node.check_operator_id = operator.id
                    # unassigned_node.save()
                return unassigned_nodes
            except Exception as e:
                logger.info(e)
                continue

    def _check_for_user(self, request, resource_id=None):
        """
        返回所有需要质检的任务及任务信息
        """
        # 查询任务
        ms, limit, offset = self._get_page_params_with_name(request)
        if ms is None:
            return {"msg": "limit or offset must be int"}, 200
        # 筛选出未完成的任务
        ms = ms.where(
            (self._resource.is_completed == False) &
            (self._resource.blind_check_rate > 0)
        )
        # 统计总量
        total = ms.count()
        # 分页
        ms = ms.order_by(self._resource.gmt_begin.desc()).limit(limit).offset(offset)
        # 循环组织返回数据：任务名称、盲审方式、盲审率、盲审一致率、数据量、待质检数据量
        data = [
            {
                "id": task.id, "name": task.name,  # 任务 ID，名称
                "task_begin": task.gmt_begin, "node_length": task.amount,  # 开始时间、数据量
                "blind_check_type": task.blind_check_type,  # 盲审方式
                "blind_check_rate": task.blind_check_rate,  # 盲审类型
                "blind_check_accuracy": task.cal_blind_check_accuracy(),  # 盲审一致率
                "remain_check_length": task.get_unchecked_num(),  # 待质检
                # 添加质检不一致数量
                "check_error_num": self._get_error_num(task.id),
                "reference_size": task.reference_size
            }
            for task in ms
        ]

        return {"total": total, "limit": limit, "data": data}, 200

    def _next_multi_node(self, request, resource_id=None):
        """
        返回一个未标注的节点
        """
        # 获取任务
        num = int(request.args.get("num", 10))
        task = self._resource.get_or_none(self._resource.id == resource_id)
        if task is None:
            return {"msg": "task not exist"}, 200
        # 检查任务的 gmt_end 字段，如果这个字段存在值（不为None），则表示该任务已经完成，不需要做后面的工作了
        if task.gmt_end:
            return {"msg": "task had labeled completely"}, 200
        # 获取操作人
        operator = request.headers["user"]
        # 返回节点
        #   如果任务类型为 文本分类 ，则每次返回 10 条数据
        #   如果任务类型不为 文本分类，则每次返回一条数据
        return self._next_label_nodes(request, task, operator, num=num)

    def _next_node(self, request, resource_id=None):
        """
        返回一个未标注的节点
        """
        # 获取任务
        task = self._resource.get_or_none(self._resource.id == resource_id)
        if task is None:
            return {"msg": "task not exist"}, 200
        # 检查任务的 gmt_end 字段，如果这个字段存在值（不为None），则表示该任务已经完成，不需要做后面的工作了
        if task.gmt_end:
            return {"msg": "task had labeled completely"}, 200
        # 获取操作人
        operator = request.headers["user"]
        # 返回节点
        #   如果任务类型为 文本分类 ，则每次返回 10 条数据
        #   如果任务类型不为 文本分类，则每次返回一条数据
        return self._next_label_nodes(request, task, operator, num=1)

    def _next_qa_node(self, request, resource_id=None):
        """
        返回一个未标注的文本匹配节点
        """
        # 获取任务
        task = self._resource.get_or_none(self._resource.id == resource_id)
        if task is None:
            return {"msg": "task not exist"}, 200
        # 检查任务的 gmt_end 字段，如果这个字段存在值（不为None），则表示该任务已经完成，不需要做后面的工作了
        if task.gmt_end:
            return {"msg": "task had labeled completely"}, 200
        # 获取操作人
        operator = request.headers["user"]
        nodes, err = self._get_label_nodes(request, task, operator, num=1)
        if err is not None:
            return {"msg": err}, 200
        node_info = nodes[0].to_dict()
        data_instance = DataInstance.get_or_none(DataInstance.id == node_info.get("data"))
        if data_instance is None:
            return {"msg": " data instance not exist"}, 200

        # use_pre_label = task.use_pre_label
        # task_type = task.task_type.name
        task_data_type = task.data_set.data_set_type.name

        node_data = data_instance.data
        questions = node_data.get("text")
        answer = json.loads(list(data_instance.extra_info.values())[0])
        answer_question = [answer_info.get("label_text") for answer_info in answer]
        answer_label = [answer_info.get("user_label") for answer_info in answer]

        result = {
            "id": node_info.get("id"),  # 节点 id
            "task_id": task.id,  # 任务 id
            "task_name": task.name,  # 任务名称
            "task_type": task.task_type.name,  # 任务类型
            "task_question": questions,  # 任务问题
            "task_answer": answer_question,  # 任务回答
            "user_label": answer_label,
            "task_data_type": task_data_type,  # 任务数据类型
            "use_pre_label": task.use_pre_label,  # 是否使用预标注数据
            "task_template": task.task_template,  # 任务预存的模板
            "task_status": 2  # 任务状态
        }
        # 返回节点
        #   如果任务类型为 文本分类 ，则每次返回 10 条数据
        #   如果任务类型不为 文本分类，则每次返回一条数据
        return result, 200

    def _next_video_node(self, request, resource_id=None):
        """
        返回视频标注节点，返回视频地址，图片地址，
        """
        # 获取任务
        watch_flag = request.args.get("watch_flag")
        task = self._resource.get_or_none(self._resource.id == resource_id)
        if task is None:
            return {"msg": "task not exist"}, 200
        # 检查任务的 gmt_end 字段，如果这个字段存在值（不为None），则表示该任务已经完成，不需要做后面的工作了
        # if task.gmt_end:
        #     return {"msg": "task had labeled completely"}, 200
        # label_nodes = LabelNode.select().where((LabelNode.task == resource_id) & (LabelNode.is_labeled == 0)).count()
        # if not watch_flag and label_nodes <= 0:
        #     return {"msg": "task had labeled completely"}, 200
        labeled_nodes = LabelNode.select().where((LabelNode.task == resource_id) & (LabelNode.is_labeled == 1))
        instance_ids = [node.data.frame_index for node in labeled_nodes]
        if not watch_flag and instance_ids:
            last_frame_index = max(instance_ids)
        else:
            last_frame_index = 0
        # 获取操作人
        operator = request.headers["user"]
        update_info = LabelNode.update({"last_operator": operator.id}).where(LabelNode.task == resource_id).execute()
        data_set = task.data_set
        result = task.to_dict()
        result["minio_path"] = data_set.minio_path
        result["fps"] = int(data_set.error_message) if data_set.error_message else 0
        result["frame_path"] = os.path.join(config.get("minio_video_bucket"), f"video2frame/{data_set.name}/")
        result["frame_count"] = data_set.amount
        result["last_label_frame"] = last_frame_index

        return result, 200

    def _next_label_nodes(self, request, task, operator, num):
        """
        返回多个节点
        """
        nodes, err = self._get_label_nodes(request, task, operator, num)
        if err is not None:
            return {"msg": err}, 200

        data = []

        use_pre_label = task.use_pre_label
        task_type = task.task_type.name
        task_data_type = task.data_set.data_set_type.name
        # 分词
        start = time.time()
        task_datas = [node.data.data for node in nodes]
        node_extra_infos = [node.data.extra_info for node in nodes if
                            node.data.extra_info and 'label' in node.data.extra_info]
        # seg_task_datas = segement(task_datas, task.domain, task_data_type, task_type)
        seg_task_datas = task_datas
        logger.info(
            f"{request.method} {request.path} {request.query_string} segement: {round((time.time() - start) * 1000, 2)}ms")
        # 获取预标注数据
        start = time.time()
        if node_extra_infos:
            pre_label_datas = node_extra_infos
        else:
            pre_label_datas, err = get_pre_label_data(task, task_datas, use_pre_label, use_model=False)
            if err is not None:
                return {"msg": err}, 200
        logger.info(
            f"{request.method} {request.path} {request.query_string} pre data: {round((time.time() - start) * 1000, 2)}ms")

        start = time.time()
        for task_data, pre_label_data, node in zip(seg_task_datas, pre_label_datas, nodes):
            # if task_data.get("path") is not None:
            #     replace_path = task_data.get("path").replace(" ","%20")
            #     task_data["path"] = replace_path
            data.append({
                "id": node.id,  # 节点 id
                "task_id": task.id,  # 任务 id
                "task_name": task.name,  # 任务名称
                "task_type": task_type,  # 任务类型
                "task_data": task_data,  # 任务数据
                "task_data_type": task_data_type,  # 任务数据类型
                "use_pre_label": task.use_pre_label,  # 是否使用预标注数据
                "pre_label_task_data": pre_label_data,  # 预标注数据
                "task_template": task.task_template,  # 任务预存的模板
                "task_status": 2,  # 任务状态
                "reference_size": task.reference_size  # 参照物大小
            })
        logger.info(
            f"{request.method} {request.path} {request.query_string} combine data: {round((time.time() - start) * 1000, 2)}ms")

        if num != 1:
            return {"data": data, "total": len(data)}, 200

        return data[0], 200

    def _get_label_nodes(self, request, task, operator, num):
        """
        """
        # 获取盲审方式
        blind_check_type = task.blind_check_type
        # 根据任务的盲审方式，采用相应的返回节点策略节点
        start = time.time()
        if blind_check_type == 1:
            nodes, task_status = self._next_cross_nodes(task, operator, num)
        elif blind_check_type == 2:
            nodes, task_status = self._next_single_nodes(task, operator, num)
        else:
            return None, "blind check type not exist"
        end = time.time()
        logger.info(
            f"{request.method} {request.path} {request.query_string} get nodes: {round((end - start) * 1000, 2)}ms")
        # 如果返回的节点是 None，分两种情况
        # 当 task_status = 0 时，表示所有节点都已经标注完成，
        # 当 task_status = 1 时，表示所有节点都已经分配出去了
        if nodes is None:
            if task_status == 0:
                task.label_complete()
                return None, "task had labeled completely"
            elif task_status == 1:
                return None, "task had been assigned completely"
            else:
                return None, "unkown error"
        return nodes, None

    def _next_cross_nodes(self, task, operator, num):
        """
        返回一个交叉检验方式的节点
        交叉检查方式，需要考虑节点数据相同的情况，返回的节点数据，不能和已标注的所有数据重复
        """
        # 获取所有未标注的节点
        remain_count = LabelNode.select_nodes(
            task_id=task.id, is_labeled=False
        ).limit(1).count()
        if not remain_count:
            return None, 0
        # 获取未标注的节点中属于当前操作者的节点
        operator_nodes = LabelNode.select_nodes(
            task_id=task.id, is_labeled=False, last_operator_id=operator.id
        ).limit(num)
        if operator_nodes.count():
            return operator_nodes, 2
        # 获取当前用户已标注的节点
        labeled_nodes = LabelNode.select_nodes(
            task_id=task.id, is_labeled=True,
            last_operator_id=operator.id,
            fields=["data"], distinct=True)
        data_ids = [ldn.data_id for ldn in labeled_nodes]
        # 循环获取节点
        while True:
            # 获取未标注的节点中，还未分配给其他操作人的节点
            unassigned_nodes = LabelNode.select_nodes(
                task_id=task.id, is_labeled=False,
                last_operator_id=0, data_ids=data_ids, in_data=False
            ).limit(num)
            if not unassigned_nodes.count():
                return None, 1
            # 锁定，如果发生错误，则循环
            try:
                unassigned_nodes = unassigned_nodes.for_update(nowait=True)
                for unassigned_node in unassigned_nodes:
                    unassigned_node.assign_to(operator=operator)
                return unassigned_nodes, 2
            except Exception as e:
                logger.info(e)
                continue

    def _next_single_nodes(self, task, operator, num):
        """
        返回一个单一检验方式的节点
        单一检查方式，不需要考虑节点数据相同的情况
        """
        # 获取未标注的节点中属于当前操作者的节点
        operator_nodes = LabelNode.select_nodes(
            task_id=task.id, is_labeled=False, last_operator_id=operator.id
        ).limit(num)
        if operator_nodes.count():
            return operator_nodes, 2
        # 获取未标注的节点中，还未分配给其他操作人的节点
        unassigned_nodes = LabelNode.select_nodes(
            task_id=task.id, last_operator_id=0
        ).limit(num)
        if not unassigned_nodes.count():
            return None, 1
        # 循环获取节点
        while True:
            try:
                unassigned_nodes = unassigned_nodes.for_update(nowait=True)
                for unassigned_node in unassigned_nodes:
                    unassigned_node.assign_to(operator=operator)
                return unassigned_nodes, 2
            except Exception as e:
                logger.info(e)
                continue

    def _stat_task_operator_index(self, ms, bmts=-1, emts=-1):
        """
        统计 任务-操作者 在某一时间段内的指标：
            标注任务名称、操作人名称、标注量、盲审条数、盲审一致率、标出率、标注时长
        """
        data = []
        for x in ms:
            tmp = {}
            # 添加任务id
            tmp["task_id"] = x.task.id
            # 添加标注任务名称
            tmp["task_name"] = x.task.name
            # 添加标注任务开始时间
            tmp["task_begin"] = x.task.gmt_begin
            # 添加标注人id
            tmp["operator_id"] = x.operator.id
            # 添加标注任务名称
            tmp["operator_name"] = x.operator.name
            # 添加标注量、盲审条数、盲审一致率、标出率、标注时长
            node_stat = LabelNodeApi.stat_labeled(x.task, x.operator, bmts, emts)
            tmp["labeled_num"] = node_stat[0]  # 标注量
            tmp["blind_check_num"] = node_stat[1]  # 盲审条数
            tmp["blind_check_accuracy"] = node_stat[2]  # 盲审一致率 = 盲审正确率 = 标注准确率
            tmp["markout_rate"] = node_stat[3]  # 标出率：标注的数据中，合格的数据所占比例
            tmp["labeled_minutes"] = node_stat[4]  # 标注时长：目前没计算，默认 -1
            # 保存
            data.append(tmp)

        return data

    def _parse_task_operator_from_select(self, request, ms, bmts=-1, emts=-1, page=True):
        """
        从 select 对象中解析 任务-操作者 所需的指标
        """
        params = self.get_request_json(request)
        # 获取时间上符合要求的所有任务
        res_ms = LabelTaskOperator.select().where(LabelTaskOperator.task.in_(ms))
        # res_ms# 获取搜索信息：模糊搜索任务名
        name = params.get("name", "")  # 默认为 ""
        if name and name.strip():
            res_ms = res_ms.join(LabelTask, on=(LabelTaskOperator.task_id == LabelTask.id)) \
                .join(User, on=(LabelTaskOperator.operator_id == User.id)).where(
                (LabelTask.name ** f"%{name}%") |
                (User.name ** f"%{name}%")
            )
        # 计算符合要求的总任务
        total = res_ms.count()
        # 获取分页信息
        limit = params.get("limit", 10)  # 默认为 10
        offset = params.get("offset", 0)  # 默认为 0
        if page:
            res_ms = res_ms.order_by(LabelTaskOperator.id.desc()).limit(limit).offset(offset)
        # 组织返回数据：标注任务名称、标注人、标注量、盲审条数、盲审一致率、标出率、标注时长
        data = self._stat_task_operator_index(res_ms, bmts, emts)
        return {"total": total, "limit": limit, "data": data}, 200

    def _stat_task_operator(self, request, resource_id=None, page=True):
        """
        统计 LabelTaskOperator
        """
        return self._stat(request, self._parse_task_operator_from_select, page=page)

    def _stat(self, request, parse_func, page=True):
        """
        """
        params = self.get_request_json(request)
        # 日期信息
        begin_date = params.get("begin_date", "")  # 默认为 ""
        end_date = params.get("end_date", "")  # 默认为 ""
        # 如果开始和结束日期不存在，返回所有的任务
        if not begin_date and not end_date:
            # 不存在开始和结束日期的时候，统计任务应当统计已经配置了标注人的任务（gmt_begin != None）
            ms = self._resource.select().where(self._resource.gmt_begin != None)
            return parse_func(request, ms, page=page)
        # 如果开始和结束日期存在，返回在该时间段内有标注的任务
        elif begin_date and end_date:
            bmts, _ = cal_begin_and_end_mill_timestamp(begin_date)
            _, emts = cal_begin_and_end_mill_timestamp(end_date)
            if bmts < 0 or emts < 0:
                return {"msg": f"the format of date error."}, 200
            # 某个时间段内，已经存在标注 node 的任务
            tasks = LabelNodeApi.stat_labeled_tasks_between_date(bmts, emts)
            if not tasks:
                return {"msg": f"the task not exist from {begin_date} to {end_date}."}, 200
            # 此时，已经存在标注 node 的任务，肯定已经配置过标注人了（gmt_begin != None）
            ms = self._resource.select().where(self._resource.id.in_(tasks))
            return parse_func(request, ms, bmts, emts, page=page)
        # 开始和结束日期是一对，不能只存在一个，此时，直接返回
        else:
            return {"msg": f"the begin and end date should both exist."}, 200

    def _stat_task_index(self, ms, bmts=-1, emts=-1):
        """
        统计 任务 在某一时间段内的指标：
            标注任务名称、任务类型、数据量（所有）、开始时间、标注人员（所有）、已标注（时间段内）、待标注（所有）
        """
        data = []
        for task in ms:
            tmp = {}
            # 添加任务 id
            tmp["task_id"] = task.id
            # 添加任务名称
            tmp["task_name"] = task.name
            # 添加任务开始时间
            tmp["task_begin"] = task.gmt_begin
            # 添加任务类型
            tmp["task_type"] = task.task_type.info
            # 添加数据量
            # tmp["data_length"] = LabelNode.num_by_task(task.id)
            tmp["data_length"] = task.amount
            # 添加开始时间
            # begin_timestamp = task.gmt_begin if task.gmt_begin else task.gmt_create
            tmp["begin_date"] = format_mill_timestamp(task.gmt_begin, "%Y-%m-%d")
            # 添加标注人员数量
            tmp["operator_num"] = task.task_operators.count()
            # 添加已标注：bmts -> emts 时间段内的标注数据，如果 bmts 或 emts 其中一个的值小于 0，则返回所有已标注
            tmp["labeled_length"] = LabelNode.labeled_num_by_task(task.id, bmts, emts)
            # 添加待标注
            tmp["remain_length"] = LabelNode.remain_num_by_task(task.id)

            data.append(tmp)

        return data

    def _parse_task_from_select(self, request, ms, bmts=-1, emts=-1, page=True):
        """
        从 select 对象中解析 任务 所需的指标
        """
        params = self.get_request_json(request)
        # 获取搜索信息：模糊搜索任务名
        name = params.get("name", "")  # 默认为 ""
        if name and name.strip():
            ms = ms.where(self._resource.name ** f"%{name}%")
        # 计算符合要求的总任务
        total = ms.count()
        # 获取分页信息
        limit = params.get("limit", 10)  # 默认为 10
        offset = params.get("offset", 0)  # 默认为 0
        if page:
            ms = ms.order_by(self._resource.gmt_begin.desc()).limit(limit).offset(offset)
        # 组织返回数据：任务名称、任务类型、数据量、开始时间、标注人员、已标注数量、待标注数量
        data = self._stat_task_index(ms, bmts, emts)
        return {"total": total, "limit": limit, "data": data}, 200

    def _stat_task(self, request, resource_id=None, page=True):
        """
        统计任务
        """
        return self._stat(request, self._parse_task_from_select, page=page)

    def _select_between_date(self, ms, begin_date, end_date):
        """
        在开始和结束日期中搜索
        """
        if begin_date and end_date:  # 当开始和结束日期都存在时，才进行下面的操作
            bmts, _ = cal_begin_and_end_mill_timestamp(begin_date)
            _, emts = cal_begin_and_end_mill_timestamp(end_date)
            if bmts < 0 or emts < 0:
                return None
            ms = ms.where(self._resource.gmt_begin.between(bmts, emts))
        elif begin_date and not end_date:
            bmts, _ = cal_begin_and_end_mill_timestamp(begin_date)
            if bmts < 0:
                return None
            ms = ms.where(self._resource.gmt_begin >= bmts)
        else:
            _, emts = cal_begin_and_end_mill_timestamp(end_date)
            if emts < 0:
                return None
            ms = ms.where(self._resource.gmt_begin <= emts)

        return ms

    def _get_error_num(self, task_id, last_operator=None):
        """
        获取质检不一致节点个数
        """
        error_nodes = LabelNode.select().where(
            (LabelNode.task == task_id) & (LabelNode.status == NodeStatus.CHECK_ERROR.value))
        if last_operator:
            error_nodes = error_nodes.where((LabelNode.last_operator == last_operator))
        return error_nodes.count()

    def _task_for_user(self, request, resource_id=None):
        """
        按任务统计相关信息
        该页面只能显示当前用户的所有相关任务统计信息
        可以通过任务名模糊搜索
        """
        # 获取用户
        user = request.headers["user"]
        # 获取任务名，如果任务名为空，则选择该用户下的所有任务
        # task_operators = LabelTaskOperator.select().where(LabelTaskOperator.operator == user)
        task_ids = [task_op.task_id for task_op in user.task_operators]
        # 对name进行模糊搜索并返回搜索结果及分页信息
        ms, limit, offset = self._get_page_params_with_name(request)
        if ms is None:
            return {"msg": "limit or offset must be int"}, 200
        ms = ms.where(self._resource.id.in_(task_ids))
        # 计算总返回数
        total = ms.count()
        # 分页返回
        ms = ms.order_by(self._resource.gmt_begin.desc()).limit(limit).offset(offset)
        # 组织返回数据：项目名称、项目类型、数据量、待标注、今日标注量
        data = []
        for task in ms:
            tmp = {}
            # 添加任务 id
            tmp["task_id"] = task.id
            # 添加任务名称
            tmp["task_name"] = task.name
            # 添加任务要求
            tmp["task_info"] = task.info
            # 添加任务开始时间
            tmp["task_begin"] = task.gmt_begin
            # 添加任务类型
            tmp["task_type"] = task.task_type.info
            # 添加任务数据集类型
            tmp["data_set_type"] = task.data_set.data_set_type.name
            # 添加数据量
            # tmp["data_length"] = LabelNode.num_by_task(task.id)
            tmp["data_length"] = task.amount
            # 添加待标注
            tmp["remain_length"] = LabelNode.remain_num_by_task(task.id)
            # 添加今日标注量
            tmp["today_labeled"] = LabelNode.today_labeled_num_by_task(task.id, user.id)
            # 添加用户ID
            tmp["operator_id"] = user.id

            # 添加质检不一致数量
            tmp["check_error_num"] = self._get_error_num(task.id, user.id)
            # 添加任务参考物
            tmp["reference_size"] = task.reference_size

            data.append(tmp)

        return {"total": total, "limit": limit, "data": data}, 200

    def _add_operator(self, task, operator_ids):
        """
        增加标注人
        """
        # 获取新增的标注人
        task_operator_ids = [task_op.operator_id for task_op in task.task_operators]
        new_operator_ids = [uid for uid in operator_ids if uid not in task_operator_ids]
        if not new_operator_ids:
            return {"msg": f"all operators had exist."}, 200
        # 配置标注人
        with db.atomic() as transaction:
            task_operator_flag = self._config_task_operator(task, new_operator_ids)
            if not task_operator_flag:
                transaction.rollback()
                return {"msg": f"the operator not exist or insert sql execute error."}, 200
        return task.to_dict(), 200

    def _config_task(self, request, resource_id=None):
        """
        配置标注人
        步骤：
            配置任务和操作映射表
            划分子任务
            生成 node（包括需要交叉盲审的部分）
        """
        # 获取配置信息：标注人、标注要求说明、盲审率、盲审方式
        config_info = self.get_request_json(request)
        # 标注的操作者
        operator_ids = config_info.get("operator_ids", [])
        if not operator_ids:
            # 如果操作人员列表为空，直接返回
            return {"msg": "the operator set is empty"}, 200
        # 获取当前task
        try:
            task = self._resource.get_by_id(resource_id)
        except:
            return {"msg": "label task not exist"}, 200
        # 查看此时该任务已经开始，或者已经存在标注后的数据，此时，只能进行增加标注人的操作
        if task.gmt_begin or task.have_labeled():
            # 增加标注人
            return self._add_operator(task, operator_ids)
        # 如果任务的数据集不能使用，直接返回
        data_set = task.data_set
        if not data_set:
            return {"msg": f"data set not exist"}, 200
        if not data_set.is_usable:
            return {"msg": f"data set is not usable"}, 200
        # 盲审率
        blind_check_rate = config_info.get("blind_check_rate", 0)
        if not (0 <= blind_check_rate <= 100):
            return {"msg": f"the blind check rate format error: {blind_check_rate}"}, 200
        # 盲审方式，1表示交叉，2表示单一
        blind_check_type = config_info.get("blind_check_type", 1)
        if blind_check_type not in [1, 2]:
            return {"msg": f"the blind check type error: {blind_check_type}"}, 200

        # 更新任务信息：标注要求、盲审方式和盲审率
        info = config_info.get("info", "")
        task.config(info, blind_check_type, blind_check_rate)
        task_name = f"配置标注人【任务名称：{task.name}】"
        # 异步调用任务
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = task_name + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        result = config_task.delay(task.id, operator_ids, info=info, atid=async_task.id)
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})
        return task.to_dict(), 200

    def _config_task_operator(self, task, operator_ids):
        """
        配置任务和操作者
        """
        # 获取任务和操作者的对应
        task_operator_params = []
        for uid in operator_ids:
            try:
                operator = User.get_by_id(uid)
                task_operator_params.append({"task": task, "operator": operator})
            except Exception as e:
                logger.info(e)
                return False
        # 批量插入数据
        try:
            LabelTaskOperator.insert_many(task_operator_params).execute()
        except Exception as e:
            logger.info(e)
            return False

        return True

    def _stat_single_task(self, request, resource_id=None):
        """
        根据任务统计相关数据
        """
        # 获取当前task
        try:
            task = self._resource.get_by_id(resource_id)
        except:
            return {"msg": f"task {resource_id} not exists"}, 200
        # 获取当前 task 有关的节点
        label_nodes = task.nodes

        # 总节点数
        total_count = len(label_nodes)

        # 剩余节点数（还未被标记）
        remaining_nodes = [node for node in label_nodes if not node.is_labeled]
        remaining_count = len(remaining_nodes)

        # 盲审合格率
        # blind_check_nodes = [node for node in label_nodes if node.is_blind_check]
        bc_pass_rate = None

        # 计算质检通过率
        has_check_nodes = [node for node in label_nodes if node.has_been_check]
        qualified_nodes = [node for node in label_nodes if node.checked_label_qualified]
        if not has_check_nodes:
            qc_pass_rate = None
        else:
            qc_pass_rate = len(qualified_nodes) / len(has_check_nodes) * 1.0

        res = {
            "total": total_count,  # 总节点数
            "remain": remaining_count,  # 剩余节点数（未被标记）
            "bc_pass_rate": bc_pass_rate,  # 盲审合格（当前未统计）
            "qc_pass_rate": qc_pass_rate  # 质检合格率
        }

        return res, 200

    def _update(self, request, resource_id=None):
        """
        更新任务配置
        目前只支持更新`预定义类型`部分
        """
        # 查看任务是否存在
        try:
            task = self._resource.get_by_id(resource_id)
        except Exception as e:
            logger.info(e)
            return {"msg": f"the task of id={resource_id} not exists"}, 200
        # 查看此时该任务下是否存在已标注数据，如果存在，则不能再次进行配置
        # 取消该逻辑
        # if task.have_labeled():
        #     return {"msg": f"the task had labeled, can't config again: {resource_id}."}, 200
        # 获取预定义类型数据
        try:
            task_template = self.get_request_json(request)["task_template"]
        except Exception as e:
            logger.info(e)
            return {"msg": f"the config info of id={resource_id} not exists"}, 200
        # 更新配置
        task.task_template = task_template
        task.reference_size = self.get_request_json(request).get("reference_size")
        task.save()

        return task.to_dict(), 200

    def _export(self, request, resource_id=None):
        """
        通过 LabelTask id 导出数据
        """
        user = request.headers["user"]
        # 查看任务是否存在
        try:
            label_task = self._resource.get_by_id(resource_id)
        except Exception as e:
            logger.info(e)
            return {"msg": f"task not exist"}, 200
        label_task_name = label_task.name
        # 生成链接
        dataset_type = label_task.data_set.data_set_type.name
        if dataset_type in self.export_json_types:
            file_path = f"lunar/export/{user.name}/task_{label_task_name}.json"
        elif dataset_type in self.export_excel_types:
            file_path = f"lunar/export/{user.name}/task_{label_task_name}.xlsx"
        else:
            return {"msg": "export type not support"}, 200
        # 获取 bucket
        bucket = config["minio_bucket"]
        url, err = OssFile.link(bucket, file_path)
        if err is not None:
            return {"msg": err}, 200
        task_name = f"导出标注任务数据【任务名称：{label_task_name}, 下载路径: {url}】"
        # 组织消息
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name,
            "webhook": request.args.get("webhook")
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = f"导出标注任务数据{label_task_name}" + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        # 异步导出, 这个代码可能有问题，返回值是为None
        result = export_task.delay(label_task.id, file_path, atid=async_task.id, info=info)
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})

        return {"data": {"path": url, "async_id": async_task.id, "name": os.path.basename(file_path),
                         "status": async_task.status, "region": "web"}}, 200

    def _export_task(self, request, resource_id=None):
        """
        通过 LabelTask id 导出数据
        """
        user = request.headers["user"]
        params = self.get_request_json(request)
        # 查看任务是否存在
        try:
            label_task = self._resource.get_by_id(params.get("id"))
        except Exception as e:
            logger.info(e)
            return {"msg": f"task not exist"}, 200
        label_task_name = label_task.name
        # 生成链接
        dataset_type = label_task.data_set.data_set_type.name
        if dataset_type in self.export_json_types:
            file_path = f"lunar/export/{user.name}/task_{label_task_name}.json"
        elif dataset_type in self.export_excel_types:
            file_path = f"lunar/export/{user.name}/task_{label_task_name}.xlsx"
        else:
            return {"msg": "export type not support"}, 200
        # 获取 bucket
        bucket = config["minio_bucket"]
        url, err = OssFile.link(bucket, file_path)
        if err is not None:
            return {"msg": err}, 200
        task_name = f"导出标注任务数据【任务名称：{label_task_name}, 下载路径: {url}】"
        # 组织消息
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name,
            "webhook": request.args.get("webhook")
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = f"导出标注任务数据{label_task_name}" + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        # 异步导出, 这个代码可能有问题，返回值是为None
        result = export_task.delay(label_task.id, file_path, atid=async_task.id, info=info)
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})

        return {"data": {"path": url, "async_id": async_task.id, "name": os.path.basename(file_path),
                         "status": async_task.status, "region": "web"}}, 200

    def _create_group_user(self, group_name, user):
        with db.atomic() as transaction:
            try:
                # 创建用户
                # 日期
                cur_time = int(time.time() * 1000)
                # 创建组和用户
                # 创建组
                group_info = {
                    "name": group_name,
                    "defaults": {"gmt_create": cur_time, "gmt_modified": cur_time, "info": "auto create group",
                                 "last_operator_id": user.id, "is_private": 1}
                }
                group, _ = Group.get_or_create(**group_info)
                # 创建组和用户的映射
                group_user_info = {
                    "group": group, "user": user,
                    "defaults": {"gmt_create": cur_time, "gmt_modified": cur_time, "last_operator_id": user.id}
                }
                GroupUser.get_or_create(**group_user_info)
            except Exception as e:
                transaction.rollback()
                logger.info(e)
                return None
        return group

    def _cascade_create(self, request, resource_id=None):
        """
        根据web文件异步创建数据集和标注任务
        """
        params = self.get_request_json(request)
        file_path = params.get("data")
        task_name = params.get("name")
        # 判断用户组是否存在
        group_name = params.get("owner")
        group = Group.get_or_none((Group.name == group_name) & (Group.is_deleted == 0))
        user = request.headers["user"]
        if group is None:
            group = self._create_group_user(group_name, user)
            if group is None:
                return {"msg": "create group failed"}, 200
        # 获取数据集类型
        data_set_type = DataSetType.get_or_none(DataSetType.name == params.get("dataType"))
        if not data_set_type:
            return {"msg": "data set type not exist"}, 200
        # 获取任务类型
        task_type = LabelTaskType.get_or_none(LabelTaskType.name == params.get("taskType"))
        if task_type.bind_data_type.id!=data_set_type.id:
            logger.info("data set type does not match task_type")
            return {"msg": "data set type does not match task_type"}, 200
        params["data_set_type"] = data_set_type.id
        params["owner"] = group.id
        params["task_type_id"] = task_type.id
        # 读取数据
        url_file = URLFile.get_web_file(file_path, stream=True)
        if url_file is None or url_file.status_code != 200:
            return {"msg": "web file not exist"}, 200

        # 创建异步任务
        # 将文件写入临时文件
        # meta_name, ext = os.path.splitext(web_file.name)
        # tmp_file_name = meta_name + "_" + str(int(time.time() * 1000)) + ext
        # tmp_file = TmpFile(tmp_file_name)
        # err = tmp_file.write(file_data, type=ext.replace(".", ""))
        # if err is not None:
        #     return {"msg": err}, 200

        task_info = {
            "name": params.get("name"),
            "info": params.get("info"),
            "owner": params.get("owner"),
            "task_type_id": params.get("task_type_id"),
            "data_set": -1,
            "use_pre_label": params.get("usePreLabel"),
            "task_template": params.get("taskTemplate"),
            "domain": params.get("domain")
        }
        async_task_name = f"web方式创建任务【任务名称：{task_name}】"
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": async_task_name,
            "webhook": params.get("webhook")
        }
        # 创建空的标注任务
        with db.atomic():
            task = LabelTask.create_instance(task_info)
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = async_task_name + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        result = web_file_instances.delay(str(file_path), params, task_id=task.id, info=info, atid=async_task.id)
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})

        return {"data": {"id": task.id, "async_id": async_task.id, "status": async_task.status,
                         "name": task_name,
                         "data_type": params.get("dataType"), "task_type": params.get("taskType"),
                         "domain": params.get("domain")}}, 200

    def _cascade_append(self, request, resource_id=None):
        """
        根据web文件异步追加数据集和标注任务
        """
        params = self.get_request_json(request)
        file_path = params.get("data")
        task_id = params.get("id")

        task = LabelTask.get_or_none((LabelTask.id == task_id))
        if task is None:
            return {"msg": f"task {task_id} not exist"}, 200
        params["owner"] = task.owner
        task_name = task.name
        # 读取数据
        url_file = URLFile.get_web_file(file_path, stream=True)
        if url_file is None or url_file.status_code != 200:
            return {"msg": "web file not exist"}, 200

        async_task_name = f"web方式追加数据【任务名称：{task_name}】"
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": async_task_name,
            "webhook": params.get("webhook")
        }

        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = async_task_name + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        params["append_flag"] = True
        params["dataType"] = task.data_set.data_set_type.name
        result = web_file_instances.delay(str(file_path), params, task_id=task.id, data_set_id=task.data_set.id, info=info,
                                    atid=async_task.id)
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})

        return {"data": {"id": task.id, "async_id": async_task.id, "status": async_task.status,
                         "name": task_name,
                         "data_type": params.get("dataType"), "task_type": params.get("taskType"),
                         "domain": params.get("domain")}}, 200

    def _cascade_delete(self, request, resource_id=None):
        """
        删除异步任务, 如果异步任务没执行完成，则先取消， 同时删除对应的标注任务和相关数据集
        """
        # 获取参数
        params = self.get_request_json(request)
        async_id = params.get("async_id")
        task_id = params.get("task_id")
        # 获取未删除的同步任务
        old_async_task = AsyncTask.get_or_none((AsyncTask.id == async_id) & (AsyncTask.status != "REVOKE"))
        if old_async_task is None:
            return {"msg": " async task not exist!"}, 200

        # 判断任务是否存在
        # 任务不存在，直接返回成功
        task = self._resource.get_or_none(self._resource.id == task_id)
        if task is None:
            return {"data": {"id": task_id, "async_id": async_id}}, 200
        # 获取当前用户
        user = request.headers["user"]
        # 当前用户是否属于数据集的拥有者（组）
        is_gu = user.is_group_user(task.owner)
        if user.role.name != RoleType.ADMIN.value and \
                (not is_gu or user.role.name == RoleType.OPERATOR.value):
            return {"msg": f"not authorization"}, 200
        task_name = task.name

        # 删除任务
        with db.atomic():
            task.delete_instance()
            logger.info(f"{user.name} delete task: name={task.name}")
        async_task_name = f"删除任务【任务名称：{task_name}】"
        # 开启异步任务
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": async_task_name,
            "webhook": params.get("webhook")
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = async_task_name + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        async_task.save()
        # 删除异步任务和数据集（如果数据集关联其他任务则不删除），异步删除任务对应的节点、操作人员等数据
        result = delete_async_task.delay(async_id, task_id, task.data_set.id, user.name, info=info, atid=async_task.id)
        logger.info(f"{user.name} delete task [{task_name}]")

        # 更新异步任务
        async_task.update_instance({"async_id": result.id})

        return {"data": {"id": task_id, "async_id": async_task.id, "status": async_task.status, "name": task_name}}, 200

    def check_data(self, data, user, template=True):
        """
        检查数据是否符合要求，
        """
        fields = self.required_fields if template else [field for field in self.required_fields if
                                                        field != "task_template"]
        for x in fields:
            if x not in data:
                return None, f"{x} is required, please check data format"

        params = {key: value for key, value in data.items() if key in fields}
        # use_pre_label 默认为 False
        params["use_pre_label"] = data.get("use_pre_label", False)
        # 添加所有者
        # group_name = data.get("group_name")
        role_type = user.role.name
        group_ids = GroupUser.get_private_group(user.id)
        if role_type != RoleType.ADMIN.value and role_type != RoleType.MANAGER.value:
            group_ids = data.get("owner_id")
            user_group_list = GroupUser.select().where(
                (GroupUser.user == user.id) & (GroupUser.is_deleted == 0) & (GroupUser.group == group_ids))
            if not user_group_list:
                return None, f"user does not belong to this group"

        params["owner"] = group_ids
        # 检查数据集是否存在，是否可用
        data_set_id = data["data_set"]
        data_set = DataSet.get_or_none(DataSet.id == data_set_id)
        if data_set is None:
            return None, f"data set not exist: {data_set}"
        if not data_set.is_usable:
            return None, f"data set is not usable: {data_set}"
        params["data_set"] = data_set
        params["amount"] = data_set.amount
        # 检查任务类型是否存在
        task_type_name = data["task_type"]
        task_type = LabelTaskType.get_or_none(LabelTaskType.name == task_type_name)
        if task_type is None:
            return None, f"not found label_task_type named {task_type_name}"
        params["task_type"] = task_type
        # 检查任务名称是否存在
        task = self._resource.get_or_none(
            (self._resource.name == params["name"])
        )
        if task is not None:
            return None, f"task has already exist: {data['name']}"
        params["reference_size"] = data.get("reference_size")
        if params["reference_size"] is None:
            params["reference_size"] = 0
        return params, None

    def _post(self, request, resource_id=None):
        """
        只生成任务，不进行子任务和节点的划分
        """
        owner = request.headers["user"]
        data = self.get_request_json(request)
        # check key exists
        params, err = self.check_data(data, owner)
        if err is not None:
            return {"msg": err}, 200

        # execute
        try:
            r = self._resource.create_instance(params)
            return r.to_dict(), 200
        except Exception as e:
            logger.exception(e)
            return {"msg": f"create data_instances failed"}, 200

    async def delete(self, request, resource_id):
        """
        删除标注任务
        """
        # 判断任务是否存在
        task = self._resource.get_or_none(self._resource.id == resource_id)
        if task is None:
            return {"msg": "task not exist"}, 200
        # 当前用户
        user = request.headers["user"]
        # 当前用户是否属于数据集的拥有者（组）
        is_gu = user.is_group_user(task.owner)
        if user.role.name != RoleType.ADMIN.value and \
                (not is_gu or user.role.name == RoleType.OPERATOR.value):
            return {"msg": f"not authorization"}, 200
        task_name = f"删除标注任务【任务名称：{task.name}】"
        # 异步删除任务对应的节点、操作人员等数据
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = task_name + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        result = delete_label_task.delay(task.id, info=info, atid=async_task.id)
        # 删除任务
        task.delete_instance()
        logger.info(f"{user.name} delete task: name={task.name}")
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})
        return {"async_id": result.id, "name": task.name}, 200

    def _get_list(self, request):
        """
        在base基础上主要添加根据数据集名称进行模糊搜索的功能
        """
        ms, limit, offset = self._get_page_params_with_name(request)
        if ms is None:
            return {"msg": "limit or offset must be int"}, 200

        rs = [x.to_detailed_dict() for x in ms.order_by(self._resource.id.desc()).limit(limit).offset(offset)]
        total = ms.count()
        return {"total": total, "limit": limit, "data": rs}, 200

    def _complete(self, request, resource_id):
        logger.info(f"complete task_id {resource_id}")
        task = self._resource.get_or_none(self._resource.id == resource_id)
        if task is None:
            return {"msg": f"cannot find task {resource_id}"}, 200
        else:
            logger.info(task.id)
            task.complete()
            return task.to_dict(), 200


class LabelNodeApi(PeeweeApi):
    _resource = LabelNode
    decorators = [auth.authorized, response_normalize, json_response]
    extract_action = {
        "post": ["check", "commit", "qualified_nbt", "multi_commit", "video_commit", "label_video_node",
                 "multi_label_video_node",
                 "label_key_frame"],
        "get": ["reset", "disqualify", "stat", "search", "check_error_task", "transfer_data", "get_label_data"]
    }
    url_name = _resource.__name__

    def _transfer_data(self, request, resource_id):
        params = request.args
        type = params.get("method")
        # 1、创建群组
        try:
            if type == "user":
                users = User.select()
                for user in users:
                    user_id = user.id
                    # 日期
                    cur_time = int(time.time() * 1000)
                    with db.atomic() as transaction:
                        # 创建组
                        group_info = {
                            "id": user_id,
                            "name": user.name,
                            "defaults": {"gmt_create": cur_time, "gmt_modified": cur_time, "info": "auto create group",
                                         "last_operator_id": user.id, "is_private": 1}
                        }
                        group, _ = Group.get_or_create(**group_info)
                        # 创建组和用户的映射
                        group_user_info = {
                            "group": group, "user": user,
                            "defaults": {"gmt_create": cur_time, "gmt_modified": cur_time, "last_operator_id": user.id}
                        }
                        GroupUser.get_or_create(**group_user_info)
            elif type == "status":
                num = 1
                # 2、修改节点状态
                labeled_nodes = LabelNode.select().where(
                    (LabelNode.is_labeled == 1) & (LabelNode.data_disqualified == 0))
                check_error_nodes = LabelNode.select().where(
                    (LabelNode.has_been_check == 1) & (LabelNode.checked_label_qualified == 0))
                abandon_nodes = LabelNode.select().where((LabelNode.data_disqualified == 1))
                for node in labeled_nodes:
                    node.status = NodeStatus.LABELED.value
                    node.save()
                logger.info("labeled node end")
                for node in check_error_nodes:
                    node.status = NodeStatus.CHECK_ERROR.value
                    node.save()
                logger.info("check_error_nodes end")
                for node in abandon_nodes:
                    node.status = NodeStatus.ABANDON.value
                    node.save()
                logger.info("abandon_nodes end")
            # 3、修改数据集和任务的amount字段
            elif type == "amount":
                data_sets = DataSet.select()
                for data_set in data_sets:
                    amount = DataInstance.select().where(DataInstance.data_set == data_set.id).count()
                    data_set.amount = amount
                    data_set.tasks.amount = amount
                    data_set.save()
                    data_set.tasks.save()
        except Exception as e:
            logger.info(e)
            return {"msg": e}, 200
        return {"state": "success"}, 200

    def _multi_commit(self, request, resource_id):
        """
        标注提交多个节点
        """
        req_data = self.get_request_json(request)
        data = req_data["data"]

        with db.atomic() as transacaction:
            try:
                for ele in data:
                    node = LabelNode.get_by_id(ele["id"])
                    label_data = ele["label_data"]
                    self.commit_node(node, label_data)
            except Exception as e:
                transacaction.rollback()
                logger.info(e)
                return {"msg": e}, 200
        return {"total": len(data)}, 200

    def _search(self, request, resource_id):
        """
        搜索节点,支持按照起始时间、节点状态和文本查询
        """
        text = request.args.pop("text", [])
        task_id = request.args.get("task_id")
        task = LabelTask.get_or_none(LabelTask.id == task_id)
        task_type = task.task_type.name
        params = request.args
        # 日期信息
        begin_date = params.get("begin_date", "")  # 默认为 ""
        end_date = params.get("end_date", "")  # 默认为 ""

        status = params.get("status")
        if status == NodeStatus.CHECK_ERROR.value:
            return {"msg": "status cannot be CHECK_ERROR"}, 200

        last_operator_id = request.args.get("last_operator_id")
        ms, limit, offset = self._get_page_params(request)
        if ms is None:
            return {"msg": "limit or offset must be int"}, 200
        # 排除掉质检不一致的节点
        if status:
            ms = ms.where(self._resource.status == status)
        else:
            ms = ms.where((self._resource.status != NodeStatus.CHECK_ERROR.value))
        # 如果开始和结束日期不存在，返回所有的任务
        if begin_date and end_date:
            # 如果开始和结束日期存在，返回在该时间段内有标注的任务
            bmts, _ = cal_begin_and_end_mill_timestamp(begin_date)
            _, emts = cal_begin_and_end_mill_timestamp(end_date)
            if bmts < 0 or emts < 0:
                return {"msg": f"the format of date error."}, 200
            ms = ms.where(self._resource.gmt_modified.between(bmts, emts))
        if text:
            text = text[0]
            # 如果 last_operator_id 不为 None，或者 text 是数字，text 只能作为 id来搜索
            if last_operator_id is not None or text.isdigit():
                ms = ms.where(self._resource.id == text)
            else:
                users = User.select().where(User.name ** f"%{text}%")
                user_ids = [x.id for x in users]
                ms = ms.where(self._resource.last_operator_id.in_(user_ids))

        total = ms.count()
        page_ms = ms.order_by(self._resource.id.desc()).limit(limit).offset(offset)
        # task_datas = [node.data.data for node in nodes]
        # seg_task_datas = parse_text(task_datas)
        result = []
        for node in page_ms:
            node_info = node.to_look()
            if task_type in ["reapu", "text_sequence"]:
                text = node_info["data"]
                node_info["data"] = {"text": " ".join(parse_text(text.get("text")))}
            elif task_type in ["text_match", "mrc", "faq", "qa"]:
                extra_info = json.loads(node.data.extra_info.get("info"))
                answer = [info.get("label_text") for info in extra_info]
                user_label = [info.get("user_label") for info in extra_info]
                node_info["data"] = {
                    "text": {"question": node_info["data"].get("text"), "answer": answer, "user_label": user_label}}
            result.append(node_info)

        # rs = [x.to_look() for x in page_ms]
        return {"total": total, "limit": limit, "data": result}, 200

    def _qualified_nbt(self, request, resource_id=None):
        """
        重置某个任务下被丢弃的节点
        """
        data = self.get_request_json(request)
        if not data:
            return {"msg": f"the request data is empty."}, 200
        task_id = data.get("task_id")
        task_id = task_id if isinstance(task_id, int) else None
        if task_id is None:
            return {"msg": f"the task id is required."}, 200
        task = LabelTask.get_or_none(LabelTask.id == task_id)
        if task is None:
            return {"msg": f"the task not exist."}, 200

        # 更新的数据
        update_data = {"is_labeled": False, "label_data": {}, "data_disqualified": False, "last_operator_id": 0}

        count = self._resource.update(update_data).where(
            (self._resource.task == task) &
            (self._resource.data_disqualified == True) &
            (self._resource.has_been_check == False)
        ).execute()
        return {"task": task.name, "total": count}, 200

    def _check(self, request, resource_id=None):
        """
        质检提交
        """
        data = self.get_request_json(request)
        user = request.headers["user"]
        if not data:
            return {"msg": f"check data not exist"}, 200
        # 循环遍历，以防出现不存在 node
        nodes = []
        for node_id, qualified in data.items():
            node = self._resource.get_or_none(self._resource.id == node_id)
            if node is None:
                return {"msg": f"node not exist"}, 200
            nodes.append((node, qualified))
        # 保存数据
        with db.atomic():
            for node, qualified in nodes:
                # 修改 node
                node.check(qualified, user.id)

        return {"data_length": len(nodes)}, 200

    @classmethod
    def stat_labeled(cls, task, operator, bmts=-1, emts=-1):
        """
        统计某个人在一段时间内在某个任务下：
            标注量、盲审条数、盲审一致率、标出率、标注时长
        """
        if bmts < 0 or emts < 0:
            ms = cls._resource.select().where(
                (cls._resource.task == task) &
                (cls._resource.is_labeled == True) &
                (cls._resource.last_operator == operator)
            )
        else:
            ms = cls._resource.select().where(
                (cls._resource.task == task) &
                (cls._resource.is_labeled == True) &
                (cls._resource.last_operator == operator) &
                (cls._resource.gmt_modified.between(bmts, emts))
            )
        # 标注量
        labeled_num = ms.count()
        if labeled_num == 0:
            return 0, 0, 0.0, 0.0, 0
        # 盲审条数
        blind_check_nodes = ms.where(cls._resource.is_blind_check == True)
        blind_check_num = blind_check_nodes.count()
        # 盲审一致率
        blind_check_yes_nodes = blind_check_nodes.where(cls._resource.checked_label_qualified == True)
        if not blind_check_num:
            blind_check_accuracy = 0.0
        else:
            blind_check_accuracy = round(blind_check_yes_nodes.count() * 1.0 / blind_check_num, 3)
        # 标出率
        qualified_nodes = ms.where(cls._resource.data_disqualified == False)
        if not labeled_num:
            markout_rate = 0.0
        else:
            markout_rate = round(qualified_nodes.count() * 1.0 / labeled_num, 3)
        # 标注时长
        # 所有修改时间
        labeled_ts = [x.gmt_modified for x in ms]
        # 将时间排序
        asc_ts = sorted(labeled_ts)
        # 获取时间差
        gap_ts = [10000] + [(asc_ts[i] - asc_ts[i - 1]) if (asc_ts[i] - asc_ts[i - 1]) < 90000 else 10000 \
                            for i in range(1, len(asc_ts))]
        labeled_minutes = round(sum(gap_ts) * 1.0 / 1000 / 60, 3)

        return labeled_num, blind_check_num, blind_check_accuracy, markout_rate, labeled_minutes

    @classmethod
    def stat_labeled_tasks_between_date(cls, bmts, emts):
        """
        统计两个日期（毫秒级时间戳）内的任务 id
        """
        ms = cls._resource.select(cls._resource.task).distinct().where(
            (cls._resource.gmt_modified.between(bmts, emts)) &
            (cls._resource.is_labeled == True)
        )
        return [x.task_id for x in ms]

    def _stat(self, request, resource_id=None):
        """
        根据节点统计相关数据
        """
        try:
            node = self._resource.get_by_id(resource_id)
        except:
            return {"msg": f"node {resource_id} not exists"}, 200

        # 节点最后更新时间
        last_modified_timestamp = node.gmt_modified
        # 节点最后操作人
        try:
            last_operator_name = node.last_operator.name
        except:
            last_operator_name = None

        res = {
            "last_modified_timestamp": last_modified_timestamp,  # 节点最后更新时间
            "last_operator_name": last_operator_name,  # 节点最后操作人
        }

        return res, 200

    def _commit(self, request, resource_id):
        """
        提交标注数据
        """
        node = self._resource.get_or_none(self._resource.id == resource_id)

        if node is None:
            return {'msg': f"node not exist"}, 200
        # 如果当前节点的 is_locked 字段为 True，则拒绝写入
        if node.is_locked:
            return {'msg': f"the node of id={resource_id} is locked, refuse write"}, 200
        label_data = self.get_request_json(request)
        logger.info(label_data)
        with db.atomic() as transaction:
            try:
                # 提交数据
                status = label_data.pop("status", None)
                notes = label_data.pop("notes", None)
                cut_word_notes = label_data.pop("cut_word_notes", None)
                self.commit_node(node, label_data, status=status, notes=notes, cut_word_notes=cut_word_notes)
            except Exception as e:
                transaction.rollback()
                logger.info(e)
                return {'msg': f"label data commit error."}, 200

        return node.to_dict(), 200

    @staticmethod
    def commit_node(node, label_data, status=None, notes=None, cut_word_notes=None):
        # 如果当前节点所在任务为单一质检方式，则选择当前节点是否标识为盲审节点
        blind_check_type = node.task.blind_check_type
        blind_check_rate = node.task.blind_check_rate
        is_blind_check = node.is_blind_check
        if blind_check_type == 2 and not node.is_blind_check and np.random.randint(2):
            # 当前用户已标注的数据
            culc = LabelNode.user_labeled_count(node.task_id, node.last_operator.id, today=True)
            # 当前用户盲审节点数
            cubc = LabelNode.user_blind_count(node.task_id, node.last_operator.id, today=True)
            if cubc * 100 / (culc + 1) < blind_check_rate:
                is_blind_check = True
        # 提交 node 数据
        node.commit(label_data, is_blind_check=is_blind_check, status=status, notes=notes,
                    cut_word_notes=cut_word_notes)

    def _multi_label_video_node(self, request, resource_id=None):
        """
        视频批量标注，视频当前帧标记好后，点击批量标注，之后得所有帧都会标注上当前信息
        """
        label_datas = self.get_request_json(request)
        user = request.headers["user"]
        task = LabelTask.get_or_none(LabelTask.id == label_datas.get("task_id"))
        if task is None:
            return {"msg": "task not exist"}, 200
        # 检查任务的 gmt_end 字段，如果这个字段存在值（不为None），则表示该任务已经完成，不需要做后面的工作了
        if task.gmt_end:
            return {"msg": "task had labeled completely"}, 200
        if not task.data_set.error_message:
            return {"msg": "video fps cannot be none"}, 200
        fps = int(task.data_set.error_message)
        update_info = []
        frame_index = label_datas.get("frame_index")
        frame_data_instances = DataInstance.select().where(
            (DataInstance.data_set == task.data_set.id) & (DataInstance.frame_index >= frame_index))
        if len(frame_data_instances) <= 0:
            logger.info(f"video frame {frame_index} not find")
            return {"msg": f"video frame not find"}, 200
        label_data = label_datas.get("label_data")
        group_id = label_data.get("data")[0].get("groupId")
        status = label_datas.pop("status")
        for frame_data_instance in frame_data_instances:
            label_node = self._resource.get_or_none(
                (self._resource.data == frame_data_instance.id) & (LabelNode.task == task.id))
            # label_data["cut_word_notes"] = frame_data_instance.frame_index
            if label_node.label_data.get("data") is not None and label_node.label_data.get("data"):
                group_ids = [label.get("groupId") for label in label_node.label_data.get("data")]
                if group_id in group_ids:
                    group_index = group_ids.index(group_id)
                    label_node.label_data["data"][group_index] = label_data.get("data")[0]
                else:
                    label_node.label_data["data"].append(label_data.get("data")[0])
                commit_label_data = {"data": label_node.label_data.get("data")}
            else:
                commit_label_data = label_data

            self.commit_node(label_node, commit_label_data, status=status,
                             cut_word_notes=frame_data_instance.frame_index)
            label_info = label_node.to_dict()
            update_info.append(label_info)
        return {"label_info": update_info, "total": len(update_info)}, 200

    def _label_video_node(self, request, resource_id=None):
        """
        视频单帧标注
        """
        label_datas = self.get_request_json(request)
        user = request.headers["user"]
        task = LabelTask.get_or_none(LabelTask.id == label_datas.get("task_id"))
        if task is None:
            return {"msg": "task not exist"}, 200
        # 检查任务的 gmt_end 字段，如果这个字段存在值（不为None），则表示该任务已经完成，不需要做后面的工作了
        if task.gmt_end:
            return {"msg": "task had labeled completely"}, 200
        if not task.data_set.error_message:
            return {"msg": "video fps cannot be none"}, 200
        fps = int(task.data_set.error_message)
        update_info = []
        frame_index = label_datas.get("frame_index")
        frame_data_instance = DataInstance.select().where(
            (DataInstance.data_set == task.data_set.id) & (DataInstance.frame_index == frame_index))
        if len(frame_data_instance) <= 0:
            logger.info(f"video frame {frame_index} not find")
            return {"msg": f"video frame not find"}, 200
        label_data = label_datas.get("label_data")
        label_node = self._resource.get_or_none(
            (self._resource.task == task.id) & (self._resource.data == frame_data_instance[0].id))
        # if label_node.label_data.get("data") is not None:
        #     label_data["data"].append(label_node.label_data.get("data"))
        status = label_datas.pop("status")
        self.commit_node(label_node, label_data, status=status, cut_word_notes=frame_data_instance[0].frame_index)
        label_info = label_node.to_dict()
        update_info.append(label_info)
        return {"label_info": update_info, "total": len(update_info)}, 200

    def _label_key_frame(self, request, resource_id=None):
        """
        关键帧标注
        """
        label_datas = self.get_request_json(request)
        user = request.headers["user"]
        task = LabelTask.get_or_none(LabelTask.id == label_datas.get("task_id"))
        if task is None:
            return {"msg": "task not exist"}, 200
        # 检查任务的 gmt_end 字段，如果这个字段存在值（不为None），则表示该任务已经完成，不需要做后面的工作了
        if task.gmt_end:
            return {"msg": "task had labeled completely"}, 200
        if not task.data_set.error_message:
            return {"msg": "video fps cannot be none"}, 200
        fps = int(task.data_set.error_message)
        start_frame_info = label_datas.get("start_pos")
        end_frame_info = label_datas.get("end_pos")
        start_frame = label_datas.get("start_frame")
        end_frame = label_datas.get("end_frame")
        start_frame_pos = start_frame_info.get("bbox")
        if start_frame_pos:
            end_frame_pos = end_frame_info.get("bbox")
            label_type = "bbox"
        elif start_frame_info.get("point"):
            start_frame_pos = start_frame_info.get("point")
            end_frame_pos = end_frame_info.get("point")
            label_type = "point"
        else:
            start_frame_pos = start_frame_info.get("segmentation")
            end_frame_pos = end_frame_info.get("segmentation")
            label_type = "segmentation"
        # 计算关键帧之间的轨迹
        if label_type == "point":
            x_start_pos = start_frame_pos[0]
            y_start_pos = start_frame_pos[1]
            x_end_pos = end_frame_pos[0]
            y_end_pos = end_frame_pos[1]
            x_trace = list(np.linspace(x_start_pos, x_end_pos, abs(end_frame - start_frame) + 1))
            y_trace = list(np.linspace(y_start_pos, y_end_pos, abs(end_frame - start_frame) + 1))
        else:
            x_start_pos = [pos[0] for pos in start_frame_pos]
            y_start_pos = [pos[1] for pos in start_frame_pos]
            x_end_pos = [pos[0] for pos in end_frame_pos]
            y_end_pos = [pos[1] for pos in end_frame_pos]
            x_trace = np.transpose(
                np.array([list(np.linspace(x_start_pos[i], x_end_pos[i], abs(end_frame - start_frame) + 1)) for i in
                          range(len(x_start_pos))])).tolist()
            y_trace = np.transpose(
                np.array([list(np.linspace(y_start_pos[i], y_end_pos[i], abs(end_frame - start_frame) + 1)) for i in
                          range(len(y_start_pos))])).tolist()
        group_id = start_frame_info.get("groupId")
        trace_info = [copy.deepcopy(start_frame_info) for _ in range(abs(end_frame - start_frame) + 1)]

        for i in range(abs(end_frame - start_frame) + 1):
            if label_type == "point":
                trace_info[i][label_type] = [x_trace[i], y_trace[i]]
            else:
                trace_info[i][label_type] = list(map(lambda x: list(x), list(zip(x_trace[i], y_trace[i]))))
            if label_type == "bbox":
                box_pos = trace_info[i][label_type]
                first_pos = box_pos[0]
                x_diff = 0
                y_diff = 0
                for pos in box_pos[1:]:
                    if pos[0] != first_pos[0]:
                        x_diff = pos[0] - first_pos[0]
                    if pos[1] != first_pos[1]:
                        y_diff = pos[1] - first_pos[1]
                trace_info[i]["raw"] = first_pos + [x_diff, y_diff]

        # 将标注数据插入对应的节点
        label_instances = DataInstance.select().where((DataInstance.data_set == task.data_set.id) & (
            DataInstance.frame_index.between(start_frame, end_frame))).order_by(DataInstance.frame_index)
        label_result = []
        for index, label_instance in enumerate(label_instances):
            label_node = LabelNode.select().where((LabelNode.data == label_instance.id) & (LabelNode.task == task.id))[
                0]
            label_data = label_node.label_data
            # 如果存在相同groupid的框进行覆盖
            if label_data.get("data") is not None and label_data.get("data"):
                group_ids = [label.get("groupId") for label in label_data.get("data")]
                if group_id in group_ids:
                    group_index = group_ids.index(group_id)
                    label_data["data"][group_index] = trace_info[index]
                else:
                    label_data.get("data").append(trace_info[index])
                label_data = {"data": label_data.get("data")}
            else:
                label_data = {"data": [trace_info[index]]}
            label_node.update_instance(
                {"label_data": label_data, "status": 1, "last_operator": user.id, "is_labeled": True,
                 "cut_word_notes": label_instance.frame_index})
            label_node_info = label_node.to_dict()
            label_node_info["frame_index"] = label_instance.frame_index
            label_result.append(label_node_info)
        return {"total": abs(end_frame - start_frame) + 1, "label_info": label_result}, 200

    def _video_commit(self, request, resource_id=None):
        """
        视频提交，表示整个视频已经标注完成
        """
        label_datas = self.get_request_json(request)
        user = request.headers["user"]
        task = LabelTask.get_or_none(LabelTask.id == label_datas.get("task_id"))
        if task is None:
            return {"msg": "task not exist"}, 200
        # 检查任务的 gmt_end 字段，如果这个字段存在值（不为None），则表示该任务已经完成，不需要做后面的工作了
        if task.gmt_end:
            return {"msg": "task had labeled completely"}, 200
        if not task.data_set.error_message:
            return {"msg": "video fps cannot be none"}, 200
        count = self._resource.update({"status": 1, "last_operator": user.id, "is_labeled": True}).where(
            (self._resource.task == label_datas.get("task_id")) & (self._resource.status == 0)).execute()
        return {"total": count}, 200

    def _get_label_data(self, request, resource_id=None):
        label_datas = request.args
        user = request.headers["user"]
        task = LabelTask.get_or_none(LabelTask.id == label_datas.get("task_id"))
        if task is None:
            return {"msg": "task not exist"}, 200
        start_index = int(label_datas.get("start"))
        end_index = int(label_datas.get("end"))
        # fps = int(task.data_set.error_message)
        # start_index = int(start_time * fps)
        # start_index = int(end_time * fps)
        frame_instance = DataInstance.select().where(
            (DataInstance.data_set == task.data_set.id) & (
                DataInstance.frame_index.between(start_index, end_index))).order_by(DataInstance.frame_index)
        label_frame = [frame.labels.where(LabelNode.task == task.id)[0].to_dict() for frame in frame_instance if
                       frame.labels.where(LabelNode.task == task.id)[0].label_data]

        return {"label_info": label_frame, "total": len(label_frame)}, 200

    def _reset(self, request, resource_id):
        user = request.headers["user"]
        r = self._resource.get_by_id(resource_id)
        if user.id != r.last_operator_id:
            return {'msg': "not allowed"}, 200
        r.label_data = {}
        r.is_labeled = False
        r.save()
        return r.to_dict(), 200

    def _disqualify(self, request, resource_id):
        user = request.headers["user"]
        try:
            node = self._resource.get_by_id(resource_id)
        except Exception as e:
            logger.info(e)
            return {'msg': f"the node of id={resource_id} not exist."}, 200

        # 修改节点标记数据为空
        node.label_data = {}
        if not node.is_labeled:
            node.gmt_modified = int(time.time() * 1000)
        # 修改数据为已标注
        node.is_labeled = True
        # 标记数据为废弃
        node.data_disqualified = True
        node.status = NodeStatus.ABANDON.value
        # 最该最后操作人
        node.last_operator = user
        # 修改数据修改时间

        # 保存修改
        node.save()
        return node.to_dict(), 200

    def _get_one(self, request, resource_id):
        try:
            node = self._resource.get_by_id(resource_id)
        except Exception as e:
            logger.info(e)
            return {"msg": f"node not exists"}, 200
        return node.to_look(), 200

    def _get_list(self, request):
        user = request.headers["user"]
        ms, limit, offset = self._get_page_params(request)
        if ms is None:
            return {"msg": "limit or offset must be int"}, 200
        # 特殊处理
        current = request.args.get("current")
        current = to_bool(current, strict=True)
        if current:
            ms = ms.where(
                (self._resource.last_operator == user) &
                (self._resource.is_labeled == True) &
                (self._resource.data_disqualified == False) &
                (self._resource.gmt_modified >= get_current_begin_mill_timestamp())
            )

        total = ms.count()
        page_ms = ms.order_by(self._resource.id.asc()).limit(limit).offset(offset)
        rs = [x.to_look() for x in page_ms]
        return {"total": total, "limit": limit, "data": rs}, 200

    def _check_error_task(self, request, resource_id=None):
        """
        获取质检不一致任务列表
        """
        user = request.headers["user"]
        check_flag = request.args.get("check_flag")
        ms, limit, offset = self._get_page_params(request)
        if ms is None:
            return {"msg": "limit or offset must be int"}, 200
        # 特殊处理
        ms = ms.where(LabelNode.status == NodeStatus.CHECK_ERROR.value)
        # 区分是标注页面还是质检页面的质检不一致查询
        if not check_flag:
            ms = ms.where(LabelNode.last_operator == user.id)
        total = ms.count()
        page_ms = ms.order_by(self._resource.id.asc()).limit(limit).offset(offset)
        task_id = request.args.get("task_id")
        task = LabelTask.get_or_none(LabelTask.id == task_id)
        use_pre_label = task.use_pre_label
        task_datas = [node.data.data for node in page_ms]
        if not task_datas:
            return {"total": total, "limit": limit, "data": []}, 200
        task_type = task.task_type.name
        task_data_type = task.data_set.data_set_type.name
        # pre_label_datas, err = get_pre_label_data(task, task_datas, use_pre_label, use_model=False)
        # if err is not None:
        #     return {"msg": err}, 200
        rs = [x.to_look() for x in page_ms]
        data = []
        # for task_data, pre_label_data, node in zip(task_datas, pre_label_datas, page_ms):
        #     data.append({
        #         "id": node.id,  # 节点 id
        #         "task_id": task.id,  # 任务 id
        #         "task_name": task.name,  # 任务名称
        #         "task_type": task_type,  # 任务类型
        #         "task_data": task_data,  # 任务数据
        #         "task_data_type": task_data_type,  # 任务数据类型
        #         "use_pre_label": task.use_pre_label,  # 是否使用预标注数据
        #         "pre_label_task_data": pre_label_data,  # 预标注数据
        #         "task_template": task.task_template,  # 任务预存的模板
        #         "task_status": 2,  # 任务状态
        #         "reference_size": task.reference_size  # 参照物大小
        #     })
        return {"total": total, "limit": limit, "data": rs}, 200


class LabelNodeCheckApi(PeeweeApi):
    _resource = LabelNode
    decorators = [auth.authorized, response_normalize, json_response]
    extract_action = {"post": [], "get": ["check"]}
    url_name = "LabelNodeCheck"

    def _check(self, request, resource_id=None):
        qualified = request.args.get("qualified", None)
        if qualified is None:
            return {"msg": "must specific if qualified"}, 200
        node = self._resource.get_or_none(self._resource.id == resource_id)
        if node is None:
            return {"msg": f"cannot find node {resource_id}"}, 200

        if node.is_blind_check is False:
            return {'msg': f"it is not blind check node"}, 200
        node.has_been_check = True
        d = {"false": False, "False": False, "true": True, "True": True}
        qualified = d.get(qualified, bool(qualified))
        node.checked_label_qualified = qualified
        node.save()
        return node.to_dict(), 200

    def _get_list(self, request):
        user = request.headers['user']
        d = request.args
        try:
            limit = int(d.pop("limit", [0])[0])
            offset = int(d.pop("offset", [0])[0])
        except Exception as e:
            logger.info(e)
            return {"msg": "limit or offset must be int"}, 200
        d = {x: d[x][0] for x in d}
        d["is_blind_check"] = "True"
        ms = self._resource.simple_search(raw_expressions=d)
        if user.role.name == "operator":
            ms = ms.where(self._resource.last_operator_id == user.id)
        rs = [x for x in ms.order_by(self._resource.id.asc()).limit(limit).offset(offset).dicts()]
        total = ms.count()
        return {"total": total, "limit": limit, "data": rs}, 200
