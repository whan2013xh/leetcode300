from sanic.views import HTTPMethodView
from sanic import response
from lunar.models import BaseModel
from functools import wraps
from lunar.logger import logger
from lunar.utils import response_normalize


def json_response(func):
    @wraps(func)
    async def wrapper(*args, **kwargs):
        r = response.json(*await func(*args, **kwargs))
        return r

    return wrapper


class MethodForbidden(Exception):
    pass


class PeeweeApi(HTTPMethodView):
    _resource = BaseModel
    decorators = [response_normalize, json_response]
    extract_action = {"post": [], "get": []}
    url_name = _resource.__name__

    def get_request_files(self, request):
        """
        获取 request files
        """
        try:
            return request.files
        except Exception as e:
            logger.info(e)
            return None

    def get_request_form(self, request, only=False):
        """
        获取 request form
        """
        empty_dict = {}
        try:
            req_form = request.form
            if req_form:
                if only:
                    req_form = {k: v[0] for k, v in req_form.items()}
                return req_form
        except Exception as e:
            logger.info(e)
        return empty_dict

    def get_request_json(self, request):
        """
        获取 requset json
        """
        empty_dict = {}
        try:
            req_json = request.json
            if req_json:
                return req_json
        except Exception as e:
            logger.info(e)
        return empty_dict

    @classmethod
    def _forbid_method(cls, method_name):
        def _forbidden(*args, **kwargs):
            # raise MethodForbidden(f"the {method_name} method of class {cls.__name__} has been forbidden")
            return {"msg": f"the {method_name} method of class {cls.__name__} has been forbidden"}, 200

        return _forbidden

    @classmethod
    def forbid_methods(cls, method_names):
        for name in method_names:
            setattr(cls, name, cls._forbid_method(name))

    async def get(self, request, resource_id=None):
        action = request.args.pop("action", [None])[0]
        if action is None:
            return self._get(request, resource_id)
        else:
            if action in self.extract_action["get"]:
                action_name = "_" + action
                return getattr(self, action_name)(request, resource_id)
            else:
                return {"msg": f"not suport {action}"}, 200

    async def delete(self, request, resource_id):
        r = self._resource.get_by_id(resource_id)
        data = r.to_dict()
        r.delete_instance()
        return data, 200

    async def post(self, request, resource_id=None):
        action = request.args.pop("action", [None])[0]
        if action is None:
            return self._post(request, resource_id)
        else:
            if action in self.extract_action["post"]:
                action_name = "_" + action
                return getattr(self, action_name)(request, resource_id)
            else:
                return {"msg": f"not suport {action}"}, 200

    async def put(self, request, resource_id):
        # todo
        data = self.get_request_json(request)
        r = self._resource.get_by_id(resource_id)
        r.update_instance(data)
        return r.to_dict(), 200

    def _get(self, request, resource_id=None):
        if resource_id is None:
            # return a list of data instances if resource_id is None
            return self._get_list(request)
        else:
            return self._get_one(request, resource_id)

    def _post(self, request, resource_id=None):
        data = self.get_request_json(request)
        if isinstance(data, dict):
            r = self._resource.create_instance(data)
            return r.to_dict(), 200
        elif isinstance(data, list):
            length = len(data)
            self._resource.create_instances(data)
            return {"state": f"successful write {length} instance"}, 200
        else:
            return {"state": "input data structure incorrect"}, 200

    def _get_list(self, request):
        """
        分页获取数据
        """
        ms, limit, offset = self._get_page_params(request)
        if ms is None:
            return {"msg": "limit or offset must be int"}, 200
        rs = [x for x in ms.limit(limit).offset(offset).dicts()]
        total = ms.count()
        return {"total": total, "data": rs, "limit": limit, "offset": offset}, 200
    
    def _get_page_params(self, request):
        """
        获取请求的分页信息及搜索表达式
        limit 默认值为 10
        offset 默认值为 0
        """
        d = request.args
        try:
            limit = int(d.pop("limit", [10])[0])
            offset = int(d.pop("offset", [0])[0])
        except Exception as e:
            logger.info(e)
            return None, -1, -1

        ms = self._resource.simple_search(raw_expressions=d)
        return ms, limit, offset
    
    def _get_page_params_with_name(self, request):
        """
        获取带name模糊搜索的分页信息及搜索表达式
        """
        d = request.args
        try:
            limit = int(d.pop("limit", [10])[0])
            offset = int(d.pop("offset", [0])[0])
            name = d.pop("name", [None])[0]
        except Exception as e:
            logger.info(e)
            return None, -1, -1
        
        ms = self._resource.simple_search(raw_expressions=d)
        if name and name.strip():
            ms = ms.where(self._resource.name ** f"%{name}%")
        return ms, limit, offset

    def _get_one(self, request, resource_id):
        try:
            r = self._resource.get_by_id(resource_id)
            return r.to_dict(), 200
        except Exception as e:
            return {"msg": f"{resource_id} not exists"}, 200


class SetApi(PeeweeApi):
    def put(self, request, resource_id):
        data_instances = self.get_request_json(request)
        try:
            r = self._resource.get_by_id(resource_id)
        except Exception as e:
            return {"msg": f"id {resource_id} not exists"}, 200

        if isinstance(data_instances, list) is False:
            return {"msg": "only allow to append data instance"}, 200

        try:
            r.create_and_combine_instances(data_instances)
        except Exception as e:
            return {"msg": f"create data_instances failed"}, 200

        return {"msg": f"append {len(data_instances)} data instance"}, 200

    def delete(self, request, resource_id):
        try:
            r = self._resource.get_by_id(resource_id)
        except Exception as e:
            return {"msg": f"id {resource_id} not exists"}, 200
        r.delete_set()

        return {"msg": "success delete"}, 200
