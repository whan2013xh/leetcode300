# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-12-22
    FileName   : async_task.py
    Author     : Mustom
    Descreption: 
"""
import time

from celery.result import AsyncResult

from lunar.api.base import PeeweeApi, json_response
from lunar.celery import celery_backend
from lunar.models import AsyncTask
from lunar import auth
from lunar.utils import response_normalize, uuid5_hash
from lunar.logger import logger
from lunar.celery.task import delete_async_task
from lunar.celery import celery_control


class AsyncTaskApi(PeeweeApi):
    _resource = AsyncTask
    decorators = [auth.authorized, response_normalize, json_response]
    extract_action = {"post": ["revoke"], "get": ["check"]}
    url_name = _resource.__name__
    end_status = ["SUCCESS", "FAILURE", "REVOKED"]

    def _get(self, request, resource_id):
        """
        用户最后的操作时间
        """
        async_task = self._resource.get_or_none(self._resource.id == resource_id)
        if async_task is None:
            return {"msg": "async task not exist"}, 200
        status = async_task.status
        if status not in self.end_status:
            ar = AsyncResult(async_task.async_id, backend=celery_backend)
            update_data = {"status": ar.status, "gmt_modified": int(time.time() * 1000)}
            self._resource.update(update_data).where(self._resource.id == resource_id).execute()

        return async_task.to_dict(), 200

    def _revoke(self, request, resource_id=None):
        """
        取消异步任务
        """
        params = self.get_request_json(request)
        # 获取未删除的同步任务
        async_id = params.get("id")
        async_task = self._resource.get_or_none((self._resource.id == async_id) & (self._resource.status != "REVOKE"))
        if async_task is None:
            return {"msg": " async task not exist!"}, 200
        # 停止任务
        if async_task.status == "PENDING" or async_task.status == "started":
            celery_control.revoke(str(async_task.async_id), terminate=True)
        # 修改异步任务
        logger.info(f"Info: id={async_id}, start delete async task")
        # 异步删除任务对应的节点、操作人员等数据
        async_task.update_instance({"status": "REVOKE"})
        # 创建异步任务
        return {"data": {"id": async_task.id, "name": async_task.name, "async_id": async_task.async_id,
                         "status": async_task.status,
                         }}, 200

    def _check(self, request, resource_id):
        """
        查看任务
        """
        async_task = self._resource.get_or_none(self._resource.id == resource_id)
        if async_task is None:
            return {"msg": "async task not exist"}, 200
        return {"data": async_task.to_dict()}, 200
