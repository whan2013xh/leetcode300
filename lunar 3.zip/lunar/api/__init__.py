from lunar.api.base import json_response
from lunar.models import BaseModel, Role, User, Group, GroupUser, \
    DataSetType, DataSet, DataInstance, \
    LabelTaskType, LabelTask, LabelNode, \
    LabelRule, LabelRuleType
from lunar import auth
from lunar.api.async_task import AsyncTaskApi
from lunar.api.base import PeeweeApi
from lunar.api.dataset import DataSetApi
from lunar.api.task import LabelTaskApi, LabelNodeApi, LabelNodeCheckApi
from lunar.api.user import UserApi, GroupApi
from lunar.api.rule import LabelRuleApi
from lunar.utils import response_normalize

api_list = []
ls = locals()


def generate_normal_api(locals, resources, decorators):
    api_list = []
    for x in resources:
        api_class = type(x.__name__ + "Api", (PeeweeApi,),
                         {"_resource": x, "decorators": decorators, "url_name": x.__name__})
        locals[api_class.__name__] = api_class
        api_list.append(api_class)
    return api_list


# generate normal api class
api_list += generate_normal_api(ls, [Role, DataSetType, LabelTaskType, GroupUser],
                                [auth.authorized, response_normalize, json_response])
api_list += generate_normal_api(ls, [DataInstance],
                                [auth.authorized, response_normalize, json_response])
api_list.append(AsyncTaskApi)
api_list.append(DataSetApi)
api_list.append(LabelTaskApi)
api_list.append(LabelRuleApi)
api_list.append(LabelNodeApi)
api_list.append(UserApi)
api_list.append(GroupApi)
api_list.append(LabelNodeCheckApi)
