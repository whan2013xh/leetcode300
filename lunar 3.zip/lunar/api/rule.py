from datetime import timedelta
from itertools import groupby
import time

from lunar.mio import OssFile
from lunar.config import config
from lunar.fileio import RequestFile
from lunar.api.base import PeeweeApi, json_response
from lunar.models import LabelRule, LabelRuleType, LabelTask, AsyncTask
from lunar import auth
from lunar.utils import response_normalize, build_rules, \
    build_temp_rule, build_temp_rules, uuid5_hash
from lunar.logger import logger
from lunar.db import db
from lunar.nlp.autolabel.label_data import snorkel_predict_content, change_hit_label
from lunar.celery.task import export_rules, export_snorkel_task


class LabelRuleApi(PeeweeApi):
    _resource = LabelRule
    decorators = [auth.authorized, response_normalize, json_response]
    url_name = _resource.__name__
    extract_action = {
        "post": ["append", "import", "check", "edit", "detailed_list", "delete", "batch_delete"],
        "get": ["types", "export", "search", "run"]
    }
    
    @property
    def _label_types(self):
        return list(LabelRuleType._value2member_map_.keys())
    
    def _delete(self, request, resource_id):
        """
        批量删除
        """
        req_data = self.get_request_json(request)
        # 获取所有需要删除的 规则ID
        ids = req_data["ids"]
        self._resource.delete().where(self._resource.id.in_(ids)).execute()

        return {"delete_num": len(ids)}, 200
    
    def _detailed_list(self, request, resource_id):
        """
        规则详情列表
        """
        req_data = self.get_request_json(request)
        # limit offset 
        limit = req_data.pop("limit", 10)
        offset = req_data.pop("offset", 0)
        # 检查 task id
        ms = self._resource.simple_search(raw_expressions=req_data)
        rs = [x for x in ms.order_by(self._resource.id.asc()).limit(limit).offset(offset).dicts()]
        total = ms.count()
        return {"total": total, "limit": limit, "data": rs}, 200
    
    def _edit(self, request, resource_id):
        """
        修改规则
        """
        req_data = self.get_request_json(request)
        # 校验 ID
        rule_id = req_data["id"]
        rule = self._resource.get_or_none(self._resource.id == rule_id)
        if rule is None:
            return {"msg": "rule not exist"}, 200
        # 获取标签
        labels = rule.task.get_labels()
        # 校验
        rule_data = req_data["rule"][0]
        update_data, err = build_temp_rule(rule_data, labels, self._label_types, edit=True)
        if err is not None:
            return {"msg": err}, 200
        # 执行更新
        rule.update_instance(update_data)

        return rule.to_dict(), 200

    def _check(self, request, resource_id):
        """
        校验规则
        """
        req_data = self.get_request_json(request)
        # 获取 task_id
        task_id = req_data["task_id"]
        task = self._resource.get_task(task_id)
        if task is None:
            return {"msg": "task not exist"}, 200
        # 获取标签
        labels = task.get_labels()
        if not labels:
            return {"msg": "task labels not exist"}, 200
        if not isinstance(labels, list):
            return {"msg": "task labels format error"}, 200
        # 获取带校验文本
        text = req_data["text"]
        # 获取规则数据
        rule_data = req_data["rules"]
        # 构建临时规则
        rules, err = build_temp_rules(rule_data, labels, self._label_types)
        if err is not None:
            return {"msg": err}, 200
        # 弱监督一下
        preds, probs, hit_nums = snorkel_predict_content(rules, labels, [text], use_model=False)
        priority = task.get_priority()
        if priority is not None:
            labels, scores, _ = change_hit_label(hit_nums, priority)
            label = labels[0]
            score = scores[0]
        else:
            label = preds[0] if preds[0] in labels else None
            score = max(probs[0]) if len(set(probs[0])) != 1 else -1,
        # 组织返回数据
        res = {
            "label": label,
            "hits": {k: [x[1] for x in v] \
                for k, v in groupby(sorted(hit_nums[0], key=lambda x: x[0]), key=lambda x: x[0])},
            "score": score,
        }

        return res, 200

    def _types(self, request, resource_id):
        """
        所有规则类型
        """
        return {"types": self._label_types}, 200

    def _import(self, request, resource_id):
        """
        根据文件添加规则
        """
        # 判断请求数据是否存在
        data = self.get_request_form(request)
        if not data:
            return {"msg": f"request data not exist"}, 200
        # 判断任务ID是否存在
        task_id = data.get("task_id")
        if not task_id:
            return {"msg": f"required parameter not exist"}, 200
        task = self._resource.get_task(task_id)
        if task is None:
            return {"msg": f"task not exist"}, 200
        # 判断文件是否存在
        files = self.get_request_files(request)
        rule_file = files.get("ruleFile")
        if rule_file is None:
            return {"msg": f"request file not exist"}, 200
        rule_data, err = RequestFile(rule_file).read()
        if err is not None:
            return {"msg": err}, 200
        # 获取所有标签
        labels = task.get_labels()
        if not labels:
            return {"msg": "task labels not exist"}, 200
        if not isinstance(labels, list):
            return {"msg": "task labels format error"}, 200
        # 构建规则
        # max_num = self._resource.max_num(task_id)
        rules, err = build_rules(task, rule_data, labels, self._label_types)
        if err:
            return {"msg": str(err)}, 200
        # 插入数据
        self.create_rules(task, rules)

        return {"total": len(rules)}, 200

    def _export(self, request, resource_id):
        """
        通过 data_set_id 获取数据
        """
        user = request.headers["user"]
        params = request.args
        rule_ids = params.get("rule_ids")
        task_id = params.get("task_id")
        task = LabelTask.get_or_none(LabelTask.id==task_id)
        if task is None:
            return {"msg": "task not exist"}, 200
        choose_rules = self._resource.select().where(self._resource.task==task_id)
        if rule_ids is not None:
            rule_ids = rule_ids.split(",")
            choose_rules = choose_rules.where(self._resource.id.in_(rule_ids))
            rule_ids_name = "_".join(rule_ids)
        else:
            rule_ids_name = "all"
        if params.get("search_flag"):
            search_result = self.search_rule(params)
            rule_ids = [rule.id for rule in search_result]
            rule_ids_name = "search"
        if choose_rules is None:
            return {"msg": "rule not exist"}, 200
        # 异步导出
        file_path = f"lunar/export/{ user.name }/task_{ task.name }_rules_{rule_ids_name}.yml"
        # 获取bucket
        bucket = config["minio_bucket"]
        url, err = OssFile().link(bucket, file_path, expiry=timedelta(days=7))
        if err is not None:
            return {"msg": err}, 200
        task_name = f"导出任务规则【任务名称：{ task.name }, 下载路径: { url }】"
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = f"导出任务规则{task.name}"+"_"+uuid5_hash(f"{cur_time}")
        async_task = AsyncTask(gmt_create=cur_time, gmt_modified=cur_time, name=async_name)
        async_task.save()
        result = export_rules.delay(task_id, rule_ids, file_path, info=info, atid=async_task.id)
        # 更新异步任务
        async_task.async_id = result.id
        async_task.gmt_modified = int(time.time() * 1000)
        async_task.save()

        return {"path": url, "async_id": result.id, "name": task.name}, 200

    def _append(self, request, resource_id):
        """
        添加规则
        """
        # 判断请求数据是否存在
        data = self.get_request_json(request)
        if not data:
            return {"msg": f"request data is empty"}, 200
        # 判断任务ID是否存在
        task_id = data["task_id"]
        task = self._resource.get_task(task_id)
        if task is None:
            return {"msg": f"task not exist"}, 200
        # 判断规则数据是否存在
        rules = data["rules"]
        if not rules:
            return {"msg": f"the rule not exist"}, 200
        # 获取所有标签
        labels = task.get_labels()
        if not labels:
            return {"msg": "task labels not exist"}, 200
        if not isinstance(labels, list):
            return {"msg": "task labels format error"}, 200
        # 构建规则
        # max_num = self._resource.max_num(task_id)
        rules, err = build_rules(task, rules, labels, self._label_types)
        if err:
            return {"msg": str(err)}, 200
        # 插入数据
        self.create_rules(task, rules)
        
        return {"total": len(rules)}, 200
    
    def create_rules(self, task, rules):
        with db.atomic() as transaction:
            try:
                # 插入规则数据
                self._resource.create_instances(rules)
                # 修改任务是否存在预标注数据
                task.have_pre_label_data()
            except Exception as e:
                transaction.rollback()
                logger.info(e)

    def _search(self, request, resource_id):
        """
        搜索规则，支持对match_label、contain的模糊搜索
        """
        search_args = request.args
        task_id = search_args.get("task_id")
        limit = int(search_args.get("limit"))
        offset = int(search_args.get("offset"))
        if task_id is None:
            return {"msg": "task id cannot be none"}
        task = LabelTask.select().where(LabelTask.id==task_id)
        if task is None:
            return {"msg": f"task not exist"}, 200

        ms = self.search_rule(search_args)
        total = ms.count()
        ptms = ms.order_by(self._resource.id.desc()).limit(limit).offset(offset)
        data = [x.to_dict() for x in ptms]
        return {"total": total, "data": data, "limit": limit, "offset": offset}, 200

    def search_rule(self, search_args):
        """
        搜索规则构建搜索表达式
        """
        match_label = search_args.pop("match_label", [None])
        contain = search_args.pop("contain", [None])
        ms = self._resource.simple_search(raw_expressions=search_args)

        if match_label[0] is not None:
            ms = ms.where(self._resource.match_label ** f"%{match_label[0]}%")
        if contain[0] is not None:
            ms = ms.where(self._resource.contain ** f"%{contain[0]}%")
        return ms

    def _run(self, request, resource_id):
        """
        运行规则并导出数据，根据任务ID和规则，运行规则匹配所有的标注数据
        """
        user = request.headers["user"]
        params = request.args
        task_id = params.get("task_id")
        task = LabelTask.get_or_none(LabelTask.id == task_id)
        if task is None:
            return {"msg": "task not exist"}, 200

        # 异步导出
        file_path = f"lunar/export/{user.name}/task_{task.name}_rules_result_{time.strftime('%Y-%m-%d')}.xlsx"
        # 获取bucket
        bucket = config["minio_bucket"]
        url, err = OssFile().link(bucket, file_path, expiry=timedelta(days=7))
        if err is not None:
            return {"msg": err}, 200
        task_name = f"导出规则运行结果【任务名称：{task.name}, 下载路径: {url}】"
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = f"导出规则运行结果{task.name}" + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask(gmt_create=cur_time, gmt_modified=cur_time, name=async_name)
        async_task.save()
        result = export_snorkel_task.delay(task_id, file_path, info=info, atid=async_task.id)
        # 更新异步任务
        async_task.async_id = result.id
        async_task.gmt_modified = int(time.time() * 1000)
        async_task.save()

        return {"path": url, "async_id": result.id, "name": task.name}, 200



















