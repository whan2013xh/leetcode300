from lunar.db import db
from lunar.api.base import PeeweeApi, json_response
from lunar.models import User, Role, Group, GroupUser, RoleType
from lunar import auth
from lunar.utils import response_normalize, get_period_mill_timestamp
from lunar.logger import logger
import time


class UserApi(PeeweeApi):
    _resource = User
    _relation = GroupUser
    decorators = [auth.authorized, response_normalize, json_response]
    extract_action = {"post": ["update_user_role"],
                      "get": ["role", "stat", "last_operate_time", "query_user_group", "query_user_list",
                              "get_user_list"]}
    url_name = _resource.__name__

    def _last_operate_time(self, request, resource_id=None):
        """
        用户最后的操作时间
        """
        try:
            user = self._resource.get_by_id(resource_id)
        except:
            return {"msg": f"user {resource_id} not exists"}, 200

        # 获取该用户的所有相关节点的修改时间，并升序排序
        timestamps = sorted([node.gmt_modified for node in user.nodes])
        if not timestamps:
            last_operate_time = None
        else:
            last_operate_time = timestamps[-1]

        res = {
            "last_operate_time": last_operate_time
        }

        return res, 200

    def _stat(self, request, resource_id=None):
        """
        根据用户统计相应的数据
        """
        try:
            user = self._resource.get_by_id(resource_id)
        except:
            return {"msg": f"user {resource_id} not exists"}, 200

        # 获取参数，得到对应的开始和结束时间戳
        data = self.get_request_json(request)
        begin_mill_timestamp, end_mill_timestamp = get_period_mill_timestamp(data.get("date", ""),
                                                                             data.get("scale", ""))
        if begin_mill_timestamp < 0 or end_mill_timestamp < 0:
            return {"msg": f"the format of date or scale error."}, 200

        relative_nodes = user.nodes

        # 时期标注数
        between_date_nodes = [node for node in relative_nodes if
                              begin_mill_timestamp <= node.gmt_modified <= end_mill_timestamp]
        label_nums = len(between_date_nodes)
        # 时期标出率
        label_pass_rate = None

        # 时期被盲审数
        bc_nodes = [node for node in between_date_nodes if node.is_blind_check]
        bc_nums = len(bc_nodes)
        # 时期盲审合格率
        bc_pass_rate = None

        # 计算质检通过率
        has_check_nodes = [node for node in between_date_nodes if node.has_been_check]
        qualified_nodes = [node for node in between_date_nodes if node.checked_label_qualified]
        if not has_check_nodes:
            qc_pass_rate = None
        else:
            qc_pass_rate = len(qualified_nodes) / len(has_check_nodes) * 1.0

        res = {
            "label_nums": label_nums,  # 时期标注数
            "label_pass_rate": label_pass_rate,  # 时期标出率
            "bc_nums": bc_nums,  # 时期被盲审数
            "bc_pass_rate": bc_pass_rate,  # 时期盲审合格率
            "qc_pass_rate": qc_pass_rate,  # 质检通过率
        }

        return res, 200

    def _get_list(self, request):
        ms, limit, offset = self._get_page_params_with_name(request)
        if ms is None:
            return {"msg": "limit or offset must be int"}, 200
        rs = [x.to_dict() for x in ms.order_by(self._resource.id.asc()).limit(limit).offset(offset)]
        total = ms.count()
        return {"total": total, "data": rs}, 200

    def _role(self, request, resource_id):
        role_name = request.args.get("role")
        r = Role.get_or_none(Role.name == role_name)
        users = [x.to_dict() for x in r.users]
        if r is None:
            return {"msg": f"cannot found role named {role_name}"}, 200
        else:
            return {"data": users}, 200

    def _query_user_group(self, request, resource_id):
        """
        查询用户所在用户组列表，根据用户ID查询
        """
        d = request.args
        try:
            limit = int(d.pop("limit", [10])[0])
            offset = int(d.pop("offset", [0])[0])
        except Exception as e:
            logger.info(e)
            return {"msg": "limit or offset must be int"}, 200

        ms = self._relation.simple_search(raw_expressions=d)
        rs = [x.to_dict() for x in ms.order_by(self._relation.id.asc()).limit(limit).offset(offset)]
        total = ms.count()
        return {"total": total, "data": rs}, 200

    def _query_user_list(self, request, resource_id):
        """
        查询用户列表，根据用户名模糊查询用户列表
        """
        ms, limit, offset = self._get_page_params_with_name(request)
        if ms is None:
            return {"msg": "limit or offset must be int"}, 200
        rs = [x.to_dict() for x in ms.order_by(self._resource.id.asc()).limit(limit).offset(offset)]
        total = ms.count()
        return {"total": total, "limit": limit, "data": rs}, 200

    def _update_user_role(self, request, resource_id):
        """
        更新用户角色
        """
        user_data = self.get_request_json(request)
        user_id = user_data.pop("user_id")
        user_info = self._resource.get_or_none(self._resource.id == user_id)
        update_res = user_info.update_instance(user_data)
        if update_res is None:
            return {"msg": " update user role failed"}, 200
        return update_res.to_dict(), 200

    def _get_user_list(self, request, resource_id):
        """
        获取用户列表，根据用户角色查看，超级管理员查看所有，管理员查看除管理员的其他人员，业务方查看业务方，其他角色人员没有查看权限
        """
        user = request.headers["user"]
        role_name = user.role.name
        role_list = {role.name: role.id for role in Role.select()}
        ms, limit, offset = self._get_page_params_with_name(request)
        if ms is None:
            return {"msg": "limit or offset must be int"}, 200
        if role_name == RoleType.ADMIN.value:
            ms = ms.where(self._resource.role_id != role_list.get(role_name))
        elif role_name == RoleType.MANAGER.value:
            ms = ms.where(self._resource.role_id.not_in([role_list.get(RoleType.ADMIN.value), role_list.get(role_name)]))
        elif role_name == RoleType.DEMANDER.value:
            ms = ms.where(self._resource.role_id == role_list.get(role_name))
        else:
            return {"state": " No permission "}, 200
        total = ms.count()
        result = []
        for user_info in ms.order_by(self._resource.id.asc()).limit(limit).offset(offset):
            user_data = user_info.to_dict()
            user_data["role_name"] = user_info.role.name
            result.append(user_data)

        return {"total": total, "limit": limit, "offset": offset, "data": result}, 200


class GroupApi(PeeweeApi):
    _resource = Group
    _instance = User
    _relation = GroupUser
    decorators = [auth.authorized, response_normalize, json_response]
    extract_action = {"post": ["sync_user", "update_group_user", "update_group", "add_group", "add_group_user", "config_group_user"],
                      "get": ["query_group_user", "query_group_list"]}
    url_name = _resource.__name__

    def _sync_user(self, request, resource_id):
        """
        同步用户信息
        如果组不存在，则创建
        """
        data = self.get_request_json(request)
        # 获取用户组名称
        name = data["name"].strip()
        # 获取用户数据
        user_names = data["data"]
        # 获取所有用户
        users = []
        for uname in user_names:
            user = self._instance.get_or_none(self._instance.name == uname)
            if user is None:
                return {"msg": "user not exist"}, 200
            users.append(user)
        # 开始同步
        with db.atomic() as transaction:
            try:
                # 获取或创建组
                cur_time = int(time.time() * 1000)
                group_info = {
                    "name": name,
                    "defaults": {"gmt_create": cur_time, "gmt_modified": cur_time}
                }
                group, flag = self._resource.get_or_create(**group_info)
                # 开始同步用户信息
                group.sync_user(users)
            except Exception as e:
                transaction.rollback()
                logger.info(e)
                return {"msg": str(e)}, 200
        # 记录创建组信息
        if flag:
            logger.info(f"create group: {name}")

        return group.to_dict(), 200

    def _config_group_user(self, request, resource_id):
        """
        配置用户组用户，支持批量添加和删除用户
        """
        group_user_data = self.get_request_json(request)
        group_id = group_user_data.get("group_id")
        user_ids = group_user_data.get("user_ids")
        last_operator_id = request.headers.get("user").id
        group_users = self._relation.select().where((self._relation.group == group_id) & (self._relation.is_deleted == False))
        group_user_ids = [group_user.user.id for group_user in group_users]
        new_user_ids = [uid for uid in user_ids if uid not in group_user_ids]
        delete_user_ids = [uid for uid in group_user_ids if uid not in user_ids]
        add_result = None
        update_res = None
        if new_user_ids:
            add_result = self._add_user(group_id, new_user_ids, last_operator_id)
        if delete_user_ids:
            update_res = self._relation.delete_group_user(group_id, delete_user_ids, last_operator_id)
        if add_result or update_res:
            return {"state": "update group user succeed"}, 200

        return {"msg": "group user update failed"}, 200

    def _add_user(self, group_id, user_ids, last_operator_id):
        """
        增加用户组用户
        """
        # 配置标注人
        with db.atomic() as transaction:
            try:
                for user in user_ids:
                    group_user = self._relation.get_or_none((self._relation.group == group_id) & (
                            self._relation.user == user) & (self._relation.is_deleted==True))
                    if group_user:
                        group_user.update_instance({"is_deleted": 0, "last_operator_id":last_operator_id})
                        continue
                    else:
                        self._relation.create_instance({"group": group_id, "user": user, "last_operator_id":last_operator_id})
            except Exception as e:
                transaction.rollback()
                logger.info(e)
                return False
        return True

    def _query_group_user(self, request, resource_id):
        """
        查询用户组包含用户列表，根据用户组ID查询
        """
        d = request.args
        d["is_deleted"] = 0
        try:
            limit = int(d.pop("limit", [10])[0])
            offset = int(d.pop("offset", [0])[0])
        except Exception as e:
            logger.info(e)
            return {"msg": "limit or offset must be int"}, 200

        ms = self._relation.simple_search(raw_expressions=d)
        rs = []
        group_users = ms.order_by(self._relation.id.desc()).limit(limit).offset(offset)
        for group_user in group_users:
            user_info = group_user.to_dict()
            user_info["user_name"] = group_user.user.name
            rs.append(user_info)
        total = ms.count()
        return {"total": total, "data": rs}, 200

    def _update_group_user(self, request, resource_id):
        """
        更新用户组用户，目前只有删除用户组用户
        """
        update_data = self.get_request_json(request)
        update_data["last_operator_id"] = request.headers.get("user").id
        update_res = self._relation.delete_group_user(**update_data)
        if update_res:
            return {"state": f"successful update group user"}, 200
        else:
            return {"msg": "group user update failed"}, 200

    def _add_group(self, request, resource_id):
        """
        新增用户组，先判断用户组是否已存在，已存在未删除，报错返回，如果已删除，修改删除标记
        """
        group_data = self.get_request_json(request)
        group_info = self._resource.get_or_none(self._resource.name == group_data.get("name"))
        group_data["last_operator_id"] = request.headers.get("user").id
        if group_info:
            if group_info.is_deleted == 1:
                group_data["is_deleted"] = 0
                update_res = group_info.update_instance(data=group_data)
                if update_res:
                    return update_res.to_dict(), 200
                else:
                    return {"msg": "add group failed"}, 200
            else:
                return {"msg": "group name exist"}, 200
        else:
            add_res = self._resource.create_instance(group_data)
            return add_res.to_dict(), 200

    def _update_group(self, request, resource_id):
        """
        更新用户组，更新用户组名称、备注或者删除用户组
        """
        update_data = self.get_request_json(request)
        group_id = update_data.get("id")
        group_name = update_data.get("name")
        # 如果用户组名已经存在
        if group_name and self._check_repeat_group(group_name, group_id):
            return {"state": "group name already exist"}, 200

        group_data = self._resource.get_by_id(group_id)
        update_data["last_operator_id"] = request.headers.get("user").id
        update_res = group_data.update_instance(data=update_data)
        group_id = update_res.id
        if not update_res:
            return {"msg": "group update failed"}, 200
        if update_data.get("is_deleted"):
            # 如果是删除用户组，需要删除对应用户组下所有用户
            delete_res = self._relation.delete_group_user(group_id, [], update_data.get("last_operator_id"))
            # if delete_res:
            #     return {"msg": "group user delete failed"}, 200
        return update_res.to_dict(), 200

    def _check_repeat_group(self, group_name, group_id):
        """
        检查用户组是否重复存在，修改用户组名称时，判断是否已经有相同名称的用户组存在了
        """
        group_info = self._resource.get_or_none(self._resource.name == group_name)
        return False if group_info is None else group_info.id != group_id

    def _query_group_list(self, request, resource_id):
        """
        查询用户所在用户组列表，如果userid为空表示查询所有用户组，否则查询指定用户的用户组
        """
        d = request.args
        ms, limit, offset = self._get_page_params_with_name(request)
        if ms is None:
            return {"msg": "limit or offset must be int"}, 200
        all_group_flag = d.pop("all_group_flag", [None])[0]
        user_id = request.headers.get("user").id
        if all_group_flag is not None:
            group_ids = self._relation.select().where(
                (self._relation.user_id == user_id) & (self._relation.is_deleted == 0))
            # if group_ids is None:
            #     return {"msg": "group user does not exist"}, 200
            group_id = [group_record.group_id for group_record in group_ids] if group_ids is not None else []
            ms = ms.where(self._resource.id.in_(group_id))
        # ms = ms.where(self._resource.is_private==False)
        ms = ms.where(self._resource.is_deleted==False)
        groups = ms.order_by(self._resource.id.desc()).limit(limit).offset(offset)
        result = []
        private_group=GroupUser.get_private_group(user_id)
        for group in groups:
            group_info = group.to_dict()
            group_info["user_num"] = GroupUser.select().where(
                (GroupUser.group == group_info.get("id")) & (GroupUser.is_deleted == False)).count()
            result.append(group_info)

        # rs = [x.to_dict() for x in ms.order_by(self._resource.id.asc()).limit(limit).offset(offset)]
        total = ms.count()
        return {"total": total, "limit": limit, "offset": offset, "data": result, "private_group": private_group}, 200

    def _add_group_user(self, request, resource_id):
        """
        添加用户组用户，需要先查询该用户是否已存在，如果是已删除的用户，需要修改删除标记为未删除
        """
        group_user_data = self.get_request_json(request)
        group_user = self._relation.get_or_none((self._relation.group == group_user_data.get("group_id")) & (
                    self._relation.user == group_user_data.get("user_id")))
        if group_user:
            if group_user.is_deleted:
                group_user.update_instance({"is_deleted": 0})
                return group_user.to_dict, 200
            else:
                return {"state": "group user already exist"}, 200
        else:
            add_res = self._relation.create_instance(group_user_data)
            return add_res.to_dict(), 200
