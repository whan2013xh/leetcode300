from lunar.mio import OssFile
import re
import os
import time
from datetime import timedelta

from lunar.celery.task import oss_instances, excel_instances, \
    append_instances, export_dataset, delete_dataset, merge_dataset, web_file_instances
from lunar.config import config
from lunar.api.base import SetApi, json_response
from lunar.models import DataSet, DataSetType, Group, RoleType, AsyncTask
from lunar import auth
from lunar.utils import response_normalize, find_log_data_by_date, \
    is_validated_dates, generate_dates, to_bool, uuid5_hash, change_excel_data
from lunar.fileio import RequestFile, TmpFile, URLFile
from lunar.logger import logger


# @auth.authorized
def export_data_set(request):
    data, _ = DataSetApi()._export(request, request.args.get("id"))
    if not data:
        return [], "empty"
    if len(data) == 1 and "msg" in data:
        return [], "empty"
    if "instances" not in data:
        return [], "empty"
    return data["instances"], data["name"]


class DataSetApi(SetApi):
    _resource = DataSet
    decorators = [auth.authorized, response_normalize, json_response]
    url_name = _resource.__name__
    # 导出字段
    extract_action = {
        "post": ["excel_input", "log_input", "merge", "oss_input", "append", "web_file_import"],
        "get": ["export", "detailed_list", "tasks", "types"]
    }
    input_date_format = "%Y-%m-%d"
    excel_header = {
        "qa": ["query", "channel_ID", "answer", "language"]
    }

    def _append(self, request, resource_id):
        """
        追加数据集: 通过上传文件追加
        """
        # 判断追加的数据集是否存在
        req_data = self.get_request_form(request)
        data_set = self._resource.get_or_none(self._resource.id == req_data["id"])
        if data_set is None:
            return {"msg": f"data set not exist"}, 200
        # 判断追加文件是否存在
        req_files = self.get_request_files(request)
        append_file = req_files.get("appendFile")
        if append_file is None:
            return {"msg": f"append file not exist"}, 200

        # 获取文件数据
        file_data, err = RequestFile(append_file).read()
        if err is not None:
            return {"msg": err}, 200
        if len(file_data.columns)>=10:
            file_data = change_excel_data(file_data)
        # 将文件写入临时文件
        meta_name, ext = os.path.splitext(append_file.name)
        tmp_file_name = meta_name + "_append_" + str(int(time.time() * 1000)) + ext
        tmp_file = TmpFile(tmp_file_name)
        err = tmp_file.write(file_data, type=ext.replace(".", ""))
        if err is not None:
            return {"msg": err}, 200
        task_name = f"追加数据集【数据集名称：{ data_set.name }】"
        # 异步调用任务
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = task_name + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        result = append_instances.delay(
            tmp_file.file_path, data_set.id,
            req_data.pop("update_tasks", []),
            info=info,
            atid=async_task.id
        )
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})
        return data_set.to_dict(), 200

    def _types(self, request, resource_id=None):
        """
        获取数据集类型和对应的任务类型
        """
        data_set_type = DataSetType.select()
        result = []
        for data_set in data_set_type:
            data_set_result = {
                "id": data_set.id,
                "name": data_set.name,
                "info": data_set.info,
                "taskTypes": []
            }
            if data_set.label_task_types:
                for task_types in data_set.label_task_types:
                    task_info = {
                        "id": task_types.id,
                        "name": task_types.name,
                        "info": task_types.info
                    }
                    data_set_result["taskTypes"].append(task_info)
            result.append(data_set_result)
        return {"data": result}, 200


    async def delete(self, request, resource_id):
        """
        数据集如果存在关联任务，不能删除
        """
        data_set = self._resource.get_or_none(self._resource.id == resource_id)
        if data_set is None:
            return {"msg": "data set not exists"}, 200
        # 判断数据集是否关联任务
        if data_set.exist_task():
            return {"msg": f"data set exist associated task"}, 200
        # 当前用户
        user = request.headers["user"]
        # 当前用户是否属于数据集的拥有者（组）
        is_gu = user.is_group_user(data_set.owner)
        if user.role.name != RoleType.ADMIN.value and \
            (not is_gu or user.role.name == RoleType.OPERATOR.value):
            return {"msg": f"not authorization"}, 200
        
        # 异步删除数据集对应的数据
        task_name = f"删除数据集【数据集名称：{ data_set.name }"
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = task_name + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        result = delete_dataset.delay(data_set.id, info=info,atid=async_task.id)
        # 删除数据集
        data_set.delete_instance()
        logger.info(f"{ user.name } delete data set: name={ data_set.name }")
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})
        return {"async_id": result.id, "name": data_set.name}, 200
    
    def check_data(self, data, user, is_text=True):
        params = {}
        # 添加拥有者
        group_name = data.get("group_name")
        group = user.check_group(group_name)
        if group is None:
            return None, f"group not exist: name={ group_name }"
        params["owner"] = group
        # 数据集类型不能为空
        data_set_type = data.get("data_set_type", "")
        if not isinstance(data_set_type, str) or not data_set_type.strip():
            return None, "data set type is empty"
        # oss 暂时只支持 "image", "voice", "video" 三种类型的数据
        if not is_text and data_set_type not in ["image", "voice", "video"]:
            return None, "data set type not support"
        # 检查数据集类型是否存在
        dst = DataSetType.get_or_none(DataSetType.name == data_set_type)
        if dst is None:
            return None, f"not found data set type named { data_set_type }"
        params["data_set_type"] = dst
        # 数据集名称不能为空
        name = data.get("name", "")
        if not isinstance(name, str) or not name.strip():
            return None, "data set name is empty"
        # 检查数据集名称是否已经存在
        data_set = self._resource.get_or_none(
            (self._resource.name == name) &
            (self._resource.owner == group)
        )
        if data_set is not None:
            return None , f"{ name } has already exists"
        params["name"] = name
        # 数据集说明
        params["info"] = data.get("info", "")

        return params, None

    def _oss_input(self, request, resource_id=None):
        """
        使用 对象存储的方式 导入数据集
        目前这种方式只用于导入 图片和视频 数据集
        """
        # request json
        data = self.get_request_json(request)
        # 存储路径
        storage = data.get("storage")
        if not storage:
            return {"msg": f"storage info not exist"}, 200
        # 检查请求数据
        user = request.headers["user"]
        params, err = self.check_data(data, user, is_text=False)
        if err is not None:
            return {"msg": err}, 200
        bucket = storage["bucket"]
        bucket_path = storage["path"]
        params["minio_path"] = os.path.join(os.path.join("/", bucket, bucket_path))

        # 创建数据集实例
        data_set = self._resource.create_instance(params)
        if data_set.data_set_type.name == "video":
            storage["minio_video_bucket"] = config.get("minio_video_bucket")
        task_name = f"对象存储方式导入数据集【数据集名称：{ data_set.name }"
        # 异步调用任务
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = task_name+"_"+uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        logger.info(storage)

        result = oss_instances.delay(storage, data_set.id, info=info, atid=async_task.id)
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})

        return data_set.to_dict(), 200

    def _tasks(self, request, resource_id):
        """
        数据集关联的任务
        """
        try:
            data_set = self._resource.get_by_id(resource_id)
        except Exception as e:
            logger.info(e)
            return {"msg": f"数据集不存在"}, 200
        tasks = [task.to_dict() for task in data_set.tasks]

        return {"tasks": tasks}, 200
    
    def _detailed_list(self, request, resource_id=None):
        """
        数据集详细信息列表
        """
        user = request.headers["user"]
        # 获取当前用户权限
        role_type = user.role.name
        # 请求数据
        req_args = request.args
        text = req_args.get("text", "")
        # limit
        limit = req_args.get("limit")
        limit = int(limit) if limit and limit.isdigit() else 10
        # offset
        offset = req_args.get("offset")
        offset = int(offset) if offset and offset.isdigit() else 0
        # data_set_type_id
        dst_id = req_args.get("data_set_type_id")
        if dst_id:
            if not dst_id.isdigit():
                return {"msg": "data set type parameter error"}, 200
            dst_id = int(dst_id)


        # 开始构建搜索条件
        expressions = []
        if role_type != RoleType.ADMIN.value and role_type != RoleType.MANAGER.value:
            # 如果是非 admin 和 manager 权限，只能搜索当前用户所在组的数据
            group_ids = [group_user.group.id for group_user in user.group_users]
            expressions.append(self._resource.owner_id.in_(group_ids))
            if text:
                expressions.append(self._resource.name ** f"%{ text }%")
        else:
            if text:
                gms = Group.select().where(Group.name ** f"%{ text }%")
                gids = [x.id for x in gms]
                expressions.append(
                    (self._resource.name ** f"%{ text }%") |
                    (self._resource.owner_id.in_(gids))
                )
        # 添加数据集类型的筛选
        image_data_set = DataSetType.select().where(DataSetType.name.in_(["image", "video"]))
        image_data_sets = [data_set.id for data_set in image_data_set]
        if dst_id:
            expressions.append(self._resource.data_set_type.in_(image_data_sets))
        else:
            expressions.append(self._resource.data_set_type.not_in(image_data_sets))
        
        tms = self._resource.select().where(*expressions)
        total = tms.count()
        ptms = tms.order_by(self._resource.id.desc()).limit(limit).offset(offset)
        data = [x.to_detailed_dict() for x in ptms]

        return {"total": total, "data": data, "limit": limit, "offset": offset}, 200

    def _merge(self, request, resource_id=None):
        """
        merge 多个数据集，构成一个新的数据集
        """
        data = self.get_request_json(request)
        if not data:
            return {"msg": "request data not exist"}, 200
        data_set_ids = data.get("data_set_ids")
        if not data_set_ids:
            return {"msg": f"miss requied field data"}, 200
        
        # 检查data set type
        data_set_type = set()
        for dsid in data_set_ids:
            data_set = self._resource.get_or_none(self._resource.id == dsid)
            if data_set is None:
                return {"msg": "data set not exist"}, 200
            data_set_type.add(data_set.data_set_type)
        # 如果数据集类型不一致，无法合并
        if len(data_set_type) != 1:
            return {"msg": "type of data is not consistent, can not merge"}, 200
        # 增加数据集类型名称
        data["data_set_type"] = data_set_type.pop().name
        # 检查数据
        user = request.headers["user"]
        params, err = self.check_data(data, user)
        if err is not None:
            return {"msg": ""}, 200
        
        # 创建新的数据集
        dataset = self._resource.create_instance(params)
        task_name = f"合并数据集【数据集名称：{data_set.name}"
        # 异步调用任务
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = task_name + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        result = merge_dataset.delay(dataset, data_set_ids, info=info, atid=async_task.id)
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})

        return dataset.to_dict(), 200

    def _export(self, request, resource_id):
        """
        通过 data_set_id 获取数据
        """
        user = request.headers["user"]
        data_set = self._resource.get_or_none(self._resource.id == resource_id)
        if data_set is None:
            return {"msg": "data set not exist"}, 200
        # 异步导出
        file_path = f"lunar/export/{ user.name }/dataset_{ data_set.name }.json"
        # 获取bucket
        bucket = config["minio_bucket"]
        url, err = OssFile.link(bucket, file_path)
        if err is not None:
            return {"msg": err}, 200
        task_name = f"导出数据集【数据集名称：{data_set.name}】, 下载路径: <{ url }>】"
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = task_name + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        result = export_dataset.delay(data_set.id, file_path, info=info, atid=async_task.id)
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})
        return {"path": url, "async_id": result.id, "name": data_set.name}, 200

    def _log_input(self, request, resource_id=None):
        """
        导入 qa 日志数据
        """
        owner = request.headers["user"]
        # 获取开始和结束日期
        input_param = self.get_request_json(request)
        if not input_param:
            return {"msg": f"the parsed_form of request not exist"}, 200
        begin_date_str = input_param.get("begin_date", "")
        end_date_str = input_param.get("end_date", "")
        # 检查日期格式是否合规：1、是否是指定格式的日期字符串；2、结束日期是否大于等于开始日期
        is_valid = is_validated_dates(begin_date_str, end_date_str, self.input_date_format)
        if not is_valid:
            return {"msg": f"the format of date error."}, 200
        # 获取日期列表
        date_str_list = generate_dates(begin_date_str, end_date_str, self.input_date_format, "%Y.%m.%d")
        # 因为es的index是根据日期创建的，所以循环日期列表获取所有数据
        es_data = []
        for date_str in date_str_list:
            # 从es中查询某一天的数据
            od_es_data, od_not_messages = find_log_data_by_date(date_str)
            if not od_es_data:
                continue
            es_data.extend(od_es_data)
            # 将没有解析出结果的 message 输出
            for message in od_not_messages:
                logger.info("the message not exist result in {}: {}".format(date_str, message))
        if not es_data:
            return {"msg": f"the data of {begin_date_str} to {end_date_str} is empty"}, 200

        # 组织存入数据库的数据格式
        data = dict()
        # 传入关键数据
        data["data_instances"] = es_data
        # 如果没有传入 name，则使用生成一个默认name：qa-log-data_20200420-20200430、qa-log-data_20200421
        name = input_param.get("name", "")
        if not name:
            date_gaps = [date.replace("-", "") for date in [begin_date_str, end_date_str]]
            name = "qa-log-data_" + "-".join(sorted(set(date_gaps), key=date_gaps.index))
        data["name"] = name
        data["data_set_type"] = input_param.get("data_set_type", "")

        return self._base_create(owner, data)

    def _post(self, request, resource_id=None):
        owner = request.headers["user"]
        data = self.get_request_json(request)
        return self._base_create(owner, data)

    def _excel_input(self, request, resource_id=None):
        # fields = re.findall("Content-Disposition: form-data; name=\".*?\"", str(request.body))
        # logger.info(f"excel_input request body fields: { fields }")
        # 获取文件
        excel_file = request.files.get("excel_file")
        # 获取其他参数
        data = self.get_request_form(request)
        logger.info(f"excel input form data: { data }")
        if not data:
            return {"msg": f"the form data of request not exist"}, 200
        # 检查请求数据
        user = request.headers["user"]
        params, err = self.check_data(data, user)
        if err is not None:
            return {"msg": err}, 200

        # 获取文件数据
        file_data, err = RequestFile(excel_file).read()
        if err is not None:
            return {"msg": err}, 200
        if len(file_data.columns)>=10:
            file_data = change_excel_data(file_data)
        # 将文件写入临时文件
        meta_name, ext = os.path.splitext(excel_file.name)
        tmp_file_name = meta_name + "_" + str(int(time.time() * 1000)) + ext
        tmp_file = TmpFile(tmp_file_name)
        err = tmp_file.write(file_data, type=ext.replace(".", ""))
        if err is not None:
            return {"msg": err}, 200
        
        # 创建数据集实例
        data_set = self._resource.create_instance(params)
        task_name = f"创建数据集【数据集名称：{data_set.name}】"
        logger.info(request.headers)
        # 异步调用任务
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = task_name + "_" + uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        result = excel_instances.delay(tmp_file.file_path, data_set.id, info=info, atid=async_task.id)
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})
        return data_set.to_dict(), 200

    def _web_file_import(self, request, resource_id=None):
        params = self.get_request_json(request)
        file_path = params.get("data")
        data_set_name = params.get("name")
        # 判断用户组是否存在
        group_name = params.get("owner")
        group = Group.get((Group.name == group_name) & (Group.is_deleted == 0))
        if not group:
            return {"msg": "group not exist"}, 200
        # 获取数据集类型
        data_set_type = DataSetType.get_or_none(DataSetType.name == params.get("dataType"))
        if not data_set_type:
            return {"msg": "data set type not exist"}, 200
        # 读取数据
        url_file = URLFile(file_path)
        if url_file.web_file.status != 200:
            return {"msg": "web file not exist"}, 200

        params["data_set_type"] = data_set_type.id
        params["owner"] = group.id
        task_name = f"web方式创建数据集【数据集名称：{data_set_name}"
        info = {
            "user_id": request.headers.get("jobNo", ""),
            "task_name": task_name
        }
        # 创建异步任务
        cur_time = int(time.time() * 1000)
        async_name = task_name+"_"+uuid5_hash(f"{cur_time}")
        async_task = AsyncTask.create_instance({"name": async_name})
        # 创建数据集实例
        data_set = self._resource.create_instance(params)
        result = web_file_instances.delay(url_file.file_url, params, data_set_id=data_set.id, info=info, atid=async_task.id)
        # 更新异步任务
        async_task.update_instance({"async_id": result.id})

        return {"data": {"id": data_set.id, "async_id": async_task.id, "status": async_task.status,
                         "name": data_set_name,
                         "data_type": params.get("dataType")}}, 200


    def _base_create(self, user, data):
        params, err = self.check_data(data, user)
        if err is not None:
            return {"msg": err}, 200
        # 获取数据
        instances = data.get("data_instances", [])
        # 增加数据量
        params["amount"] = len(instances)

        # execute
        try:
            r = self._resource.create_set_and_instance(params, instances)
            return r.to_dict(), 200
        except Exception as e:
            logger.info(e)
            return {"msg": f"create data_instances failed"}, 200

    def _get_list(self, request):
        """
        在base基础上主要添加根据数据集名称进行模糊搜索的功能
        """
        only = to_bool(request.args.pop("only", [True])[0], strict=True)
        return self._search_data_by_page(request, self._resource.to_dict, only=only)

    def _search_data_by_page(self, request, return_fn, only=True):
        """
        分页搜索数据，并根据不同 return_fn 函数，返回不同的数据
        """
        ms, limit, offset = self._get_page_params_with_name(request)
        if ms is None:
            return {"msg": "limit or offset must be int"}, 200
        
        user = request.headers["user"]
        group_ids = [group_user.group.id for group_user in user.group_users]
        if only:
            ms = ms.where(self._resource.owner_id.in_(group_ids))
        
        rs = [return_fn(x) for x in ms.order_by(self._resource.id.desc()).limit(limit).offset(offset)]
        total = ms.count()
        
        return {"total": total, "data": rs, "limit": limit, "offset": offset}, 200
