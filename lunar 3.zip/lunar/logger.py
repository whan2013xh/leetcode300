from loguru import logger
import logging
import sys
import os
import datetime
from lunar.config import config
# from lunar.fileio import check_dir


def check_dir(base_dir):
    if not os.path.exists(base_dir):
        old_mask = os.umask(0o022)
        os.makedirs(base_dir)
        os.umask(old_mask)

log_dir = config["log_dir"]
check_dir(log_dir)
date = datetime.date.today()

class InterceptHandler(logging.Handler):
    def emit(self, record):
        logger_opt = logger.opt(depth=6, exception=record.exc_info)
        msg = self.format(record)
        logger_opt.log(record.levelno, msg)


logging.basicConfig(handlers=[InterceptHandler()], level=0)
logger.configure(handlers=[{"sink": sys.stderr, "level": 'INFO'}])  # 配置日志到标准输出流
logger.add(
    f"{ log_dir }/{ date }.log", rotation="100 MB", encoding='utf-8', colorize=False, level='INFO'
)  # 配置日志到输出到文件
