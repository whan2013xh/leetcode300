# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-11-11
    FileName   : export.py
    Author     : Mustom
    Descreption: 
"""
import os
import time
from sanic import response
from celery.result import AsyncResult
import urllib

from lunar.celery import celery_backend
from lunar.mio import get_img_object, object2file
from lunar.config import config
from lunar.api.task import stat_task_operator, stat_task
from lunar.api.dataset import export_data_set
from lunar.api.task import export_labeled_data, export_rule, \
    snorkel_file
from lunar.utils import build_file_name_from_request, \
    format_request_data, format_request_data_set
from lunar.fileio import TmpFile
from lunar.app import app
from lunar.nlp.nlp_basic import segment_text, parse_text


# 查看任务状态
@app.route("/asynctask/status", methods=["POST"])
async def asynctask_status(request):
    """
    """
    async_id = request.json.get("async_id")
    ar = AsyncResult(async_id, backend=celery_backend)
    status = ar.status

    return response.json({"async_id": async_id, "status": status, "success": True})


# 请求图片接口
@app.route('/video', methods=['GET'])
@app.route('/img', methods=['GET'])
async def img(request):
    # urllib3.response.HTTPResponse
    # 临时文件夹 images 是否存在，如果不存在，生成
    base_dir = os.path.join(config["data_dir"], config["tmp_dir"])
    if not os.path.exists(base_dir):
        os.mkdir(base_dir)

    request.args["path"] = urllib.parse.unquote(request.query_string.replace("path=", ""))
    path = request.args["path"]

    spills = [spill for spill in path.split("/") if spill.strip()]
    file_name = spills[-1]
    pic_path = os.path.join(base_dir, file_name)
    if not file_name in os.listdir(base_dir):
        data, file_name = get_img_object(request)
        # 生成图片
        object2file(pic_path, data)
    # 返回图片
    request.headers["tmp_file_path"] = pic_path
    return await response.file(pic_path)


# 请求分词接口
@app.route('/tokenize', methods=['GET'])
async def tokenize(request):
    text = request.args.get("text")
    domain = request.args.get("domain", "169")
    if domain in ["common", "iot"]:
        domain = "169"
    tokens = parse_text(text, domain=domain)         # parse 分词 服务
    # tokens = segment_text(text, domain=domain)         # grpc 分词 服务
    return response.json({"tokens": tokens, "text": text, "domain": domain})


# 标出人员一键导出
@app.route('/stat_task_operator', methods=['POST'])
async def file_stat_task_operator(request):
    # 获取并处理数据
    data = stat_task_operator(request)
    # format 数据
    data = format_request_data(data)
    # 获取 file_name
    file_name = build_file_name_from_request(request, attr="json", ext=".xlsx")
    # 临时文件
    tmp_file = TmpFile(file_name)
    tmp_file.write(data, type="xlsx")
    file_path = tmp_file.file_path
    # 返回文件
    request.headers["tmp_file_path"] = file_path
    return await response.file(file_path)


# 标出任务一键导出
@app.route('/stat_task', methods=['POST'])
async def file_stat_task(request):
    # 获取并处理数据
    data = stat_task(request)
    # format 数据
    data = format_request_data(data)
    # 获取 file_name
    file_name = build_file_name_from_request(request, attr="json", ext=".xlsx")
    # 临时文件
    tmp_file = TmpFile(file_name)
    tmp_file.write(data, type="xlsx")
    file_path = tmp_file.file_path
    # 返回文件
    request.headers["tmp_file_path"] = file_path
    return await response.file(file_path)


# 下载数据集
@app.route('/export_data_set', methods=['GET'])
async def file_export_data_set(request):
    # 获取并处理数据
    data, file_name = export_data_set(request)
    # format 数据
    data = format_request_data_set(data)
    # 获取 file_name
    # file_name = build_file_name_from_request(request, attr="json", ext=".xlsx")
    file_name = "data_set_" + file_name + ".xlsx"
    # 临时文件
    tmp_file = TmpFile(file_name)
    tmp_file.write(data, type="xlsx")
    file_path = tmp_file.file_path
    # 返回文件
    request.headers["tmp_file_path"] = file_path
    return await response.file(file_path)


# 下载标注数据
@app.route('/export_labeled_data', methods=['GET'])
async def file_export_labeled_data(request):
    # 获取并处理数据
    data, file_name = export_labeled_data(request)
    # 获取 file_name
    file_name = "labeled_data_" + file_name + ".json"
    # 临时文件
    tmp_file = TmpFile(file_name)
    tmp_file.write(data, type="json")
    file_path = tmp_file.file_path
    # 返回文件
    request.headers["tmp_file_path"] = file_path
    return await response.file(file_path)


# 导出某个任务下的所有规则，返回一个规则文件流
@app.route("/export_task_rule", methods=["GET"])
async def export_task_rule(request):
    data = export_rule(request)
    # file_name
    file_name = "rules_" + str(int(time.time() * 1000)) + ".yml"
    # 临时文件
    tmp_file = TmpFile(file_name)
    tmp_file.write(data, type="yml")
    file_path = tmp_file.file_path
    # 返回文件
    request.headers["tmp_file_path"] = file_path
    return await response.file(file_path)


# 标注 snorkel 文件
@app.route("/snorkel_file", methods=["POST"])
async def snorkel_task_file(request):
    data = snorkel_file(request)
    # file_name
    file_name = "snorkel_labeled_" + str(int(time.time() * 1000)) + ".csv"
    # 临时文件
    tmp_file = TmpFile(file_name)
    tmp_file.write(data, type="csv")
    file_path = tmp_file.file_path
    # 返回文件
    request.headers["tmp_file_path"] = file_path
    return await response.file(file_path)
