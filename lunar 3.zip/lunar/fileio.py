from enum import Enum
import os
from io import StringIO
import json
from urllib import request, parse
import ssl
import requests
from requests.adapters import HTTPAdapter
# from tuya_ai_trace_requests import requests
import cv2
from io import BytesIO
import pandas as pd
from pandas import DataFrame
import yaml
try:
    from yaml import CLoader as Loader, CDumper as Dumper
except ImportError:
    from yaml import Loader, Dumper
from minio import Minio
from lunar.config import config
from lunar.logger import logger
from lunar.mio import OssFile


def check_dir(base_dir):
    if not os.path.exists(base_dir):
        old_mask = os.umask(0o022)
        os.makedirs(base_dir)
        os.umask(old_mask)


def write2mio(minio_video_bucket, dist_file_path, src_file_path):
    oss_file = OssFile()
    content_type = "application/octet-stream"

    err = oss_file.fput_object(minio_video_bucket, dist_file_path, src_file_path, content_type)
    if err is not None:
        logger.info(f"Error: wirte2mio, { err }")
        raise Exception(err)
        return False
    return True


class RequestFile(object):
    """
    request 文件
    """

    def __init__(self, file, schema_type=None):
        self.file = file
        self.name = self.file.name
        self.type = self.file.type
        self.body = self.file.body
        self.schema_type = schema_type
    
    @property
    def file_type(self):
        if self.name.endswith(".yml") or self.name.endswith(".yaml"):
            return FileType.YAML.value
        if self.name.endswith(".csv") or "csv" in self.type:
            return FileType.CSV.value
        if self.name.endswith(".xls") or self.name.endswith(".xlsx") or \
                    "excel" in self.type or self.type.endswith("sheet"):
            return FileType.EXCEL.value
        if self.name.endswith(".json") or "json" in self.type:
            return FileType.JSON.value
        return None
    
    def read(self, keep_default_na=True):
        """
        读取文件内容
        """
        if self.schema_type and self.schema_type != self.file_type:
            return None, f"只支持{ self.schema_type }类型的文件"

        if self.file_type == FileType.YAML.value:
            try:
                return YamlIO.read_str(self.body), None
            except Exception as e:
                return None, e
        
        if self.file_type == FileType.CSV.value:
            try:
                buffer = BytesIO(self.body)
                return CsvIO.read2PD(buffer, header=0), None
            except Exception as e:
                return None, e
        
        if self.file_type == FileType.EXCEL.value:
            try:
                buffer = BytesIO(self.body)
                return pd.read_excel(buffer, keep_default_na=keep_default_na), None
            except Exception as e:
                return None, e
        
        if self.file_type == FileType.JSON.value:
            try:
                return JsonIO.read_str(self.body), None
            except Exception as e:
                return None, e
        
        return None, f"暂不支持的请求文件类型: { self.type }"


class TmpFileMode(Enum):
    WRITE = "write"
    READ = "read"


class FileType(Enum):
    YAML = "yaml"
    YML = "yml"
    JSON = "json"
    CSV = "csv"
    EXCEL = "excel"
    XLSX = "xlsx"
    XLS = "xls"
    VIDEO = "video"

formats = [".mp4",".avi"]

class Video(object):

    def __init__(self, video_file_path):
        video_file = os.path.basename(video_file_path)
        self.video_name, self.extend_name = os.path.splitext(video_file)
        # if extend_name.lower() not in formats:
        #     logger.info(f"video format {extend_name} not support")
        #     self.is_video = False
        # else:
        #     self.is_video = True
        self.video_cap = cv2.VideoCapture(video_file_path)
        self.frame_count = int(self.video_cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.frame_width = int(self.video_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.frame_height = int(self.video_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.fps = int(self.video_cap.get(cv2.CAP_PROP_FPS))

    @staticmethod
    def write2frame(frame_path, frame):
        logger.info(f"start write frame {frame_path}")
        res = cv2.imwrite(frame_path, frame)
        logger.info(f"write frame {frame_path} result {res}")
        return res



class TmpFile(object):
    _default_dir = os.path.join(config["data_dir"], config["tmp_dir"])

    def __init__(self, name, mode=TmpFileMode.WRITE.value, base_dir=None, is_video_pic=False):
        # base dir 配置
        if base_dir is None:
            base_dir = self._default_dir
        check_dir(base_dir)
        self.is_video_pic = is_video_pic
        # 根据 读写 模式，生成 file_path
        if mode == TmpFileMode.WRITE.value:
            self.file_path = os.path.abspath(os.path.join(base_dir, name))
        elif mode == TmpFileMode.READ.value:
            self.file_path = os.path.abspath(name)

    
    @property
    def file_type(self):
        if self.is_video_pic:
            return FileType.VIDEO.value
        if self.file_path.endswith(".yml") or self.file_path.endswith(".yaml"):
            return FileType.YAML.value
        if self.file_path.endswith(".csv"):
            return FileType.CSV.value
        if self.file_path.endswith(".xls") or self.file_path.endswith(".xlsx"):
            return FileType.EXCEL.value
        if self.file_path.endswith(".json"):
            return FileType.JSON.value
        if self.file_path.endswith(".jpg"):
            return FileType.VIDEO.value
        video_file = os.path.basename(self.file_path)
        video_name, extend_name = os.path.splitext(video_file)
        if extend_name.lower() in formats:
            return FileType.VIDEO.value
        return None
    
    def exist(self):
        return os.path.exists(self.file_path)
    
    def remove(self):
        """
        删除临时文件
        """
        if self.exist():
            os.remove(self.file_path)

    @staticmethod
    def remove_pic(pic_path):
        if os.path.exists(pic_path):
            os.remove(pic_path)
    
    def write_json(self, data):
        try:
            JsonIO.write2file(self.file_path, data)
        except Exception as e:
            return e
    
    def write_csv(self, data: DataFrame, sep=",", header=True, index=False):
        """
        将 pandas 的 DataFrame 格式写入 csv 文件
        """
        try:
            if not isinstance(data, DataFrame):
                data = pd.DataFrame(data)
            CsvIO.writeFromPD(self.file_path, data, sep=sep, header=header, index=index)
        except Exception as e:
            return e
    
    def write_excel(self, data: DataFrame):
        """
        将 pandas 的 DataFrame 格式写入 EXCEL 文件
        """
        try:
            if not isinstance(data, DataFrame):
                data = pd.DataFrame(data)
            data.to_excel(self.file_path, index=False)
        except Exception as e:
            return e
    
    def write_yaml(self, data):
        """
        将 pandas 的 DataFrame 格式写入 YAML 文件
        """
        try:
            YamlIO.write2file(self.file_path, data)
        except Exception as e:
            return e

    def write_frame(self, data):
        """
        将 pandas 的 DataFrame 格式写入 YAML 文件
        """
        try:
            logger.info(f"write frame {self.file_path}")
            res = Video.write2frame(self.file_path, data)
        except Exception as e:
            logger.info(e)
            return False
        return res

    def write_video(self, data):
        try:
            with open(self.file_path, 'wb') as wfile:
                wfile.write(data)
        except Exception as e:
            return e
    
    def write(self, data, type=FileType.CSV.value):
        if type == FileType.CSV.value:
            return self.write_csv(data)
        if type == FileType.JSON.value:
            return self.write_json(data)
        if type == FileType.XLSX.value or \
            type == FileType.XLS.value  or type == FileType.EXCEL.value:
            return self.write_excel(data)
        if type == FileType.YAML.value or type == FileType.YML.value:
            return self.write_yaml(data)
        if type == FileType.VIDEO.value:
            return self.write_frame(data)
        return f"暂不支持的请求文件类型: { type }"
    
    def read(self):
        """
        读取文件内容
        """
        if not self.exist():
            return None, "文件不存在"
        
        if self.file_type == FileType.YAML.value:
            try:
                return YamlIO.read_file(self.file_path), None
            except Exception as e:
                return None, e
        
        if self.file_type == FileType.CSV.value:
            try:
                return CsvIO.read2PD(self.file_path, header=0), None
            except Exception as e:
                return None, e
        
        if self.file_type == FileType.EXCEL.value:
            try:
                return pd.read_excel(self.file_path), None
            except Exception as e:
                return None, e
        
        if self.file_type == FileType.JSON.value:
            try:
                return JsonIO.read_file(self.file_path), None
            except Exception as e:
                return None, e
        
        return None, f"暂不支持的请求文件类型: { self.type }"


class YamlIO(object):
    """
    yaml 文件读写
    """
    @staticmethod
    def read_str(st: str):
        """
        读取yaml文件内容
        """
        try:
            return yaml.load(st, Loader=Loader)
        except:
            return None

    @staticmethod
    def read_file(file_path: str):
        """
        读取yaml文件内容
        """
        with open(file_path, "r") as fp:
            return yaml.load(fp, Loader=Loader)

    @staticmethod
    def write2str(obj):
        return yaml.dump(obj, allow_unicode=True,  default_flow_style=False)
    
    @staticmethod
    def write2file(file_path: str, obj):
        """
        向yaml文件写入内容
        """
        with open(file_path, "w", encoding="utf-8") as fp:
            yaml.dump(obj, fp, allow_unicode=True, Dumper=Dumper)


class JsonIO(object):
    """
    json 文件读写
    """
    @staticmethod
    def read_str(st: str):
        """
        读取json文件内容
        """
        return json.loads(st, encoding="utf-8")
    
    @staticmethod
    def write2str(obj):
        """
        读取json文件内容
        """
        return json.dumps(obj, ensure_ascii=False, indent=4)

    @staticmethod
    def read_file(file_path: str):
        """
        读取json文件内容
        """
        with open(file_path, "r") as fp:
            return json.load(fp)
    
    @staticmethod
    def write2file(file_path: str, obj):
        """
        向json文件写入内容
        """
        with open(file_path, "w") as fp:
            json.dump(obj, fp, ensure_ascii=False, indent=4)


class CsvIO(object):
    """
    csv 文件读写
    """

    @staticmethod
    def read2PD(file_path: str, header=None, names=None):
        """
        读取为 pandas 的 DataFrame 格式
        """
        return pd.read_csv(file_path, header=header, names=names, encoding="utf-8")
    
    @staticmethod
    def writeFromPD(file_path: str, pd_dataframe: DataFrame, sep=",", header=True, index=False):
        """
        将 pandas 的 DataFrame 格式写入 csv 文件
        """
        pd_dataframe.to_csv(file_path, sep=sep, header=header, index=index, encoding="utf-8")


class URLFile(object):
    """
    读取web数据文件，支持https传输
    """

    def __init__(self, file_url, schema_type=None):
        self.file_url = file_url
        self.name = self.file_url.split("?")[0].split("/")[-1]
        self.type = self.name.split(".")[-1]
        self.schema_type = schema_type
        self.https_flag = self.file_url.startswith("https")
        self.web_file = URLFile.get_web_file(file_url)


    @property
    def file_type(self):
        if self.name.endswith(".yml") or self.name.endswith(".yaml"):
            return FileType.YAML.value
        if self.name.endswith(".csv") or "csv" in self.type:
            return FileType.CSV.value
        if self.name.endswith(".xls") or self.name.endswith(".xlsx") or \
                "excel" in self.type or self.type.endswith("sheet"):
            return FileType.EXCEL.value
        if self.name.endswith(".json") or "json" in self.type:
            return FileType.JSON.value
        return None

    @classmethod
    def get_web_file(cls, file_url, stream=False):
        # # 如果url里包含中文需要转换
        # # 如果是https请求需要设置ssl
        # context = ssl._create_unverified_context() if self.https_flag else None
        # safe_url = parse.quote(file_url, safe='/:?=.')
        # return request.urlopen(safe_url, context=context)
        res = None
        # 设置重试次数
        try:
            session = requests.Session()
            session.mount('http://', HTTPAdapter(max_retries=3))
            session.mount('https://', HTTPAdapter(max_retries=3))
            res = session.get(file_url, stream=stream)
        except Exception as e:
            logger.info(e)
        return res

    def read(self, keep_default_na=True):
        """
        读取文件内容
        """
        if self.schema_type and self.schema_type != self.file_type:
            return None, f"只支持{self.schema_type}类型的文件"

        file_data = self.web_file.content

        if self.file_type == FileType.YAML.value:
            try:
                return YamlIO.read_str(file_data.decode('utf8')), None
            except Exception as e:
                return None, e

        if self.file_type == FileType.CSV.value:
            try:
                return CsvIO.read2PD(StringIO(file_data.decode()), header=0), None
            except Exception as e:
                return None, e

        if self.file_type == FileType.EXCEL.value:
            try:
                # buffer = BytesIO(self.body)
                return pd.read_excel(file_data, keep_default_na=keep_default_na), None
            except Exception as e:
                return None, e

        if self.file_type == FileType.JSON.value:
            try:
                return JsonIO.read_str(file_data.decode('utf8')), None
            except Exception as e:
                return None, e

        return None, f"暂不支持的请求文件类型: {self.type}"
