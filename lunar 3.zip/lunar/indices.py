# -*- coding: utf-8 -*-
"""
-------------------------------------------------
File Name：      indices
Description :
Author :         Liu Cheng
Date：           2020/4/1
Change Activity: 2020/4/1:
-------------------------------------------------
"""

from elasticsearch import Elasticsearch


class Indices(object):
    def __init__(self, hosts=['localhost'], index="qa", doc_type="_doc"):
        self.index = index
        self.doc_type = doc_type
        self.es = Elasticsearch(hosts, maxsize=25)

    def create(self, body, ignore=400, **kwargs):
        """
        @param body: The configuration for the index (settings and mappings);
        """
        res = self.es.indices.create(index=self.index,
                                     body=body,
                                     ignore=ignore,
                                     **kwargs)

        return res

    def delete(self, **kwargs):
        res = self.es.indices.delete(index=self.index,
                                     **kwargs)

        return res

    def exists(self, index, **kwargs):
        '''
        Return a boolean indicating whether given index exists.
        @param index: A comma-separated list of index names
        @param allow_no_indices: Ignore if a wildcard expression resolves to no concrete indices (default: false)
        @param expand_wildcards: Whether wildcard expressions should get expanded to open or closed
                        indices (default: open), default ‘open’, valid choices are: ‘open’, ‘closed’, ‘none’, ‘all’
        @param flat_settings: Return settings in flat format (default: false)
        @param ignore_unavailable: Ignore unavailable indexes (default: false)
        @param include_defaults: Whether to return all default setting for each of the indices., default False
        @param local: Return local information, do not retrieve the state from master node (default: false)
        '''
        res = self.es.indices.exists(index=index,
                                     **kwargs)

        return res

