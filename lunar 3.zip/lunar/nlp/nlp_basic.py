from lunar.config import config
from lunar.nlp.pre_process import PreProcess, TextParse
from lunar.logger import logger


def segment_texts(texts, domain="common"):
	"""
	切分语料
	"""
	if not texts:
		return []
	pre_process = PreProcess(config["nlp_tokenizer_domain"])
	word_lists = [pre_process.segment(text, domain=domain) for text in texts]
	pre_process.close()
	return word_lists


def segment_text(text, domain="common"):
	"""
	切分语料
	"""
	pre_process = PreProcess(config["nlp_tokenizer_domain"])
	tokens = pre_process.segment(text, domain=domain)
	pre_process.close()
	return tokens


def parse_text(text, domain="169"):
	"""
	"""
	tokens, err = TextParse.tokenize(text, domain=domain)
	logger.info("=====parse_text======")
	logger.info(err)
	if err is not None:
		return [text]
	return [token["word"] for token in tokens]

def parse_texts(texts, domain="169"):
	if not texts:
		return []
	parse_result = []
	for text in texts:
		tokens, err = TextParse.tokenize(text, domain=domain)
		result = [token["word"] for token in tokens] if err is None else [text]
		parse_result.append(result)
	return parse_result

