import copy
from itertools import groupby
from pandas import DataFrame
import pandas as pd

from lunar.nlp.autolabel.rule2func import RulesParser
from lunar.nlp.nlp_basic import segment_texts, parse_texts


def snorkel_test_rules(data, rules, labels, field, use_model=False):
    # 初始化规则解析器，使用model
    rp = RulesParser(rules, labels, field, use_model=use_model)
    # 生成 label function 列表
    lfs = rp.generate_lfs()
    # 将文本数据转化为 pandas DataFrame 类型
    df = pd.DataFrame({field: data})
    # 在数据中运用 label function
    ldf, hit_nums = rp.labeled_df(lfs, df)

    return ldf.tolist()


def snorkel_predict_content(rules, labels, content, train_data=None, train_label=None, field="text", use_model=True):
    """
    预测文本格式数据
    """
    # 初始化规则解析器，使用model
    rp = RulesParser(rules, labels, field, use_model=use_model)
    # 生成 label function 列表
    lfs = rp.generate_lfs()
    # 将文本数据转化为 pandas DataFrame 类型
    df = pd.DataFrame({field: content})
    # 如果存在训练数据，则先对解析器进行训练
    if use_model and train_data and train_label and len(train_data) == len(train_label):
        df_train = pd.DataFrame({field: train_data})
        ldf_train, hit_nums_train = rp.labeled_df(lfs, df_train)
        rp.fit(ldf_train, Y_dev=train_label)
    # 在数据中运用 label function
    ldf, hit_nums = rp.labeled_df(lfs, df, return_hit=True)
    # 预测标签值，并将每个标签值的概率输出
    preds, probs = rp.predict(ldf, return_probs=True)

    return preds, probs, hit_nums

def change_hit_label(hit_nums, priority):
    hits_nums = [{k: [x[1] for x in v] for k, v in groupby(sorted(ld, key=lambda x: x[0]), key=lambda x: x[0])} for ld in hit_nums]
    hit_labels = []
    probs = []
    sort_prioritys=[]
    for hit_num in hits_nums:
        hits = list(hit_num.keys())
        hit_priority = {hit: priority.get(hit, 0) for hit in hits}
        prioritys = list(hit_priority.values())
        sort_priority = dict(sorted(hit_priority.items(), key=lambda x:x[1], reverse=True))
        if prioritys:
            prob = max(prioritys)
            max_index = prioritys.index(prob)
            hit_labels.append(hits[max_index])
        else:
            prob = -1
            hit_labels.append("")
        probs.append(prob)
        sort_prioritys.append(sort_priority)
    return hit_labels, probs, sort_prioritys

def snorkel_predict_pd(rules, labels, df, field="text", train_df=None, use_model=False, prioritys=None):
    """
    预测 pandas dataframe 格式数据
    """
    # 检查 df 格式
    if isinstance(df, list):
        df = pd.DataFrame({field: df})
    # 检查 df 中是否存在 field 字段
    if field not in df:
        raise Exception(f"the field not exist in data: field={field}")
    # 训练数据和训练标签
    if train_df:
        # 检查 train_df 的格式
        if not isinstance(train_df, DataFrame):
            raise Exception(f"the train df data format not support: type(df)={type(train_df)}")
        train_data = train_df["train_data"].tolist() if "train_data" in train_df else []         # 数据集合元素应该为字符串类型
        train_label = train_df["train_label"].tolist() if "train_label" in train_df else []      # 标签集合元素应该为数字类型
    else:
        train_data, train_label = [], []
    # 初始化规则解析器，使用model
    rp = RulesParser(rules, labels, field, use_model=False)
    # 生成 label function 列表
    lfs = rp.generate_lfs()
    # 在数据中运用 label function
    ldf, hits = rp.labeled_df(lfs, df, return_hit=True)
    # 如果存在训练数据，则先对解析器进行训练
    if use_model and train_data and train_label and len(train_data) == len(train_label):
        df_train = pd.DataFrame({field: train_data})
        ldf_train, hit_nums_train = rp.labeled_df(lfs, df_train)
        rp.fit(ldf_train, Y_dev=train_label)
    # 预测标签值，并将每个标签值的概率输出
    preds, probs = [], []
    if prioritys:
        preds, probs, _ = change_hit_label(hits, prioritys)
    else:
        for line in ldf:
            pred, prob = rp.predict(line.reshape(1, len(line)), return_probs=True, flush=True)
            preds.append(pred[0])
            probs.append(prob[0])


    # preds, probs = rp.predict(ldf, return_probs=True)

    # 分词
    # seg_list = segment_texts(df[field].tolist())
    seg_list = parse_texts(df[field].tolist())
    return preds, probs, seg_list, hits
