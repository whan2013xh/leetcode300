import copy
import re
from textblob import TextBlob
from snownlp import SnowNLP
from snorkel.preprocess import preprocessor
from snownlp import SnowNLP
from snorkel.labeling import LabelingFunction, PandasLFApplier, filter_unlabeled_dataframe, LFAnalysis
from snorkel.labeling.lf.nlp import NLPLabelingFunction
from snorkel.labeling.model import LabelModel, MajorityLabelVoter

# 弃权标签
ABSTAIN = -1


def pop_match_label(rule):
    match_label = rule.get("matchLabel", None)
    if match_label is not None:
        return match_label
    return rule.pop("match_label", None)


def pop_not_match_label(rule):
    match_label = rule.pop("notMatchLabel", None)
    if match_label is not None:
        return match_label
    return rule.pop("not_match_label", None)


class Rule2LabelFunction(object):
    """
    """
    _RULE_TYPE_ = ["keyword", "regular", "heuristic", "ner", "textblob", "snownlp"]
    _HEURISTIC_PARAMS_ = ["word_num"]
    _NER_PARAMS_ = ["doc_length"]

    def __init__(self, rule: dict, label2num: dict, field="text"):
        self.num = rule.pop("num", 0)
        self.label2num = label2num
        self.type = self._check_type(rule.pop("type", ""))                                # 必须传入规则类型
        self.match_label = self.label2num.get(pop_match_label(rule), ABSTAIN)             # 匹配规则的标签值
        self.not_match_label = self.label2num.get(pop_not_match_label(rule), ABSTAIN)     # 不匹配规则的标签值
        self.field = field                                              # 默认在 text 字段进行
        self.params = rule.pop("params", rule)                          # 排除必须的几个字段之后的参数
    
    def _check_type(self, typ):
        """
        检查规则类型是否合规
        """
        if isinstance(typ, dict):
            typ = typ.get("name")
        if typ in self._RULE_TYPE_:
            return typ
        raise Exception(f"the type of rule not exist: { typ }")
    
    def _contain_keywords(self, x, keywords):
        """
        包含所有关键词
        """
        if all(word in getattr(x, self.field).lower() for word in keywords):
            return True
        return False
    
    def _whether_keywords(self, x, keywords):
        """
        包含任意一个关键词
        """
        if not keywords or any(word in getattr(x, self.field).lower() for word in keywords):
            return True
        return False
    
    def _exclude_keywords(self, x, keywords):
        """
        不包含所有关键词
        """
        if not keywords:
            return True
        return not self._contain_keywords(x, keywords)
    
    def _keyword(self, x, contain, whether, exclude):
        """
        关键词判断
        """
        if self._contain_keywords(x, contain) and \
            self._whether_keywords(x, whether) and \
            self._exclude_keywords(x, exclude):
            return self.match_label
        return self.not_match_label
    
    def _keyword2function(self):
        """
        关键词转 label function
        """
        self._contain = self.params.get("contain", [])
        self._whether = self.params.get("whether", [])
        self._exclude = self.params.get("exclude", [])
        return LabelingFunction(
            name=f"keyword_{self.num}",
            f=self._keyword,
            resources=dict(
                contain=self._contain, 
                whether=self._whether, 
                exclude=self._exclude
            )
        )
    
    def _contain_patterns(self, x, patterns):
        """
        包含所有正则
        """
        if all(pattern.search(getattr(x, self.field).lower()) for pattern in patterns):
            return True
        return False
    
    def _whether_patterns(self, x, patterns):
        """
        包含所有正则
        """
        if not patterns or any(pattern.search(getattr(x, self.field).lower()) for pattern in patterns):
            return True
        return False
    
    def _exclude_patterns(self, x, patterns):
        """
        不包含所有正则
        """
        if not patterns:
            return True
        return not self._contain_patterns(x, patterns)
    
    def _regular(self, x, contain, whether, exclude):
        """
        正则表达式判断
        满足
        """
        if self._contain_patterns(x, contain) and \
            self._whether_patterns(x, whether) and \
            self._exclude_patterns(x, exclude):
            return self.match_label
        return self.not_match_label
    
    def _compile_patterns(self, patterns):
        """
        将字符串类型的正则编译为 re.compile类型
        """
        return [re.compile(pattern) for pattern in patterns]
    
    def _regular2function(self):
        """
        规则转 label function
        """
        self._contain = self._compile_patterns(self.params.get("contain", []))
        self._whether = self._compile_patterns(self.params.get("whether", []))
        self._exclude = self._compile_patterns(self.params.get("exclude", []))
        return LabelingFunction(
            name=f"regular_{self.num}",
            f=self._regular,
            resources=dict(
                contain=self._contain,
                whether=self._whether,
                exclude=self._exclude)
        )
    
    def _textblob_polarity(self, x, polarity):
        """
        textblob 情感值极性判断
        """
        if not polarity:
            return True
        return bool(eval(polarity.format(x.polarity)))
    
    def _textblob_subjectivity(self, x, subjectivity):
        """
        textblob 主观性判断
        """
        if not subjectivity:
            return True
        return bool(eval(subjectivity.format(x.subjectivity)))
    
    def _textblob(self, x, polarity, subjectivity):
        """
        第三方模型，textblob 判断
        """
        self._add_textblob_sentiment(x)
        if self._textblob_polarity(x, polarity) and self._textblob_subjectivity(x, subjectivity):
            return self.match_label
        return self.not_match_label
    
    # @preprocessor(memoize=True)
    def _add_textblob_sentiment(self, x):
        """
        向数据中添加 polarity（情感极性）、subjectivity（主观性） 属性
        """
        scores = TextBlob(getattr(x, self.field))
        x.polarity = scores.sentiment.polarity
        x.subjectivity = scores.sentiment.subjectivity
    
    def _textblob2function(self):
        """
        第三方模型，textblob 转 label function（只适用于英文）
        """
        self._polarity = self.params.get("polarity", "")
        self._subjectivity = self.params.get("subjectivity", "")
        return LabelingFunction(
            name=f"textblob_{self.num}",
            f=self._textblob,
            resources=dict(polarity=self._polarity, subjectivity=self._subjectivity),
            # pre=[self.textblob_sentiment]
        )
    
    def _word_num(self, x, expression):
        """
        根据句子的单词个数进行判断
        """
        sentence = str(getattr(x, self.field))
        words = sentence.split()
        expression = expression.format(len(words))
        return bool(eval(expression))
    
    def _heuristic(self, x, params):
        """
        启发式经验判断
        """
        # 如果没有参数直接返回预设标签
        if not params:
            return self.match_label
        res = []
        for f_key in self._HEURISTIC_PARAMS_:
            expression = params.get(f_key, "")
            res.append(getattr(self, "_" + f_key)(x, expression))
        if all(res):
            return self.match_label
        return self.not_match_label
    
    def _heuristic2function(self):
        """
        启发式经验 转 label function
        """
        return LabelingFunction(
            name=f"heuristic_{self.num}",
            f=self._heuristic,
            resources=dict(params=self.params)
        )
    
    def _doc_length(self, x, expression):
        """
        """
        if not expression:
            return True
        doc_length = len(x.doc)
        expression = expression.format(doc_length)
        return bool(eval(expression))
    
    def _ner_params_judge(self, x, params):
        """
        命名实体识别的参数判断
        """
        if not params:
            return True
        res = []
        for f_key in self._NER_PARAMS_:
            expression = params.get(f_key, "")
            res.append(getattr(self, "_" + f_key)(x, expression))
        if all(res):
            return True
        return False
    
    def _contain_ner(self, x, contain):
        """
        包含所有命名实体
        """
        if all([ent.label_ in contain for ent in x.doc.ents]):
            return True
        return False
    
    def _exclude_ner(self, x, exclude):
        """
        不包含任意命名实体
        """
        if not exclude:
            return True
        return not self._contain_ner(x, exclude)
    
    def _ner(self, x, contain, exclude, params):
        """
        命名实体识别判断
        """
        a = self._contain_ner(x, contain)
        b = self._exclude_ner(x, exclude)
        c = self._ner_params_judge(x, params)
        if a and b and c:
            return self.match_label
        return self.not_match_label
    
    def _ner2function(self):
        """
        命名实体识别 转 label function
        """
        self.entities = self.params.get("entity", [])
        self._contain = self.params.get("contain", [])
        self._exclude = self.params.get("exclude", [])
        return NLPLabelingFunction(
            name=f"ner_{self.num}",
            f=self._ner,
            resources=dict(contain=self._contain, exclude=self._exclude, params=self.params),
            text_field=self.field,
            doc_field="doc"
        )
    
    def _snownlp_sentiment_judge(self, x, sentiment):
        """
        第三方模型，snownlp 的情感判断
        """
        if not sentiment:
            return True
        return bool(eval(sentiment.format(x.sentiment)))

    def _add_snownlp_sentiment(self, x):
        """
        向数据中添加 polarity（情感极性）、subjectivity（主观性） 属性
        """
        sp = SnowNLP(getattr(x, self.field))
        x.sentiment = sp.sentiments

    def _snownlp(self, x, sentiment):
        """
        第三方模型，snownlp 判断
        """
        # 在执行这一步之前调用
        self._add_snownlp_sentiment(x)
        if self._snownlp_sentiment_judge(x, sentiment):
            return self.match_label
        return self.not_match_label
    
    def _snownlp2function(self):
        """
        第三方模型，snownlp 转 label function（只适用于中文）
        """
        self._sentiment = self.params.get("sentiment", "")
        return LabelingFunction(
            name=f"snownlp_{self.num}",
            f=self._snownlp,
            resources=dict(sentiment=self._sentiment),
            # pre=[self.textblob_sentiment]
        )
    
    def to_function(self):
        """
        生成 label function
        """
        if self.type == "keyword":
            return self._keyword2function()
        if self.type == "regular":
            return self._regular2function()
        if self.type == "textblob":             # textblob 为第三方模型，用于情感分析（只适用于英文）
            return self._textblob2function()
        if self.type == "snownlp":              # snownlp 为第三方模型，用于情感分析（只适用于中文），且处理文本为 unicode
            return self._snownlp2function()
        if self.type == "heuristic":
            return self._heuristic2function()
        if self.type == "ner":
            return self._ner2function()
        raise Exception(f"the label function way not support: {self.type}")
    
    def __call__(self):
        return self.to_function()

    
@preprocessor(memoize=True)
def textblob_sentiment(x):
    """
    向数据中添加 polarity（情感极性）、subjectivity（主观性） 属性
    """
    scores = TextBlob(getattr(x, "text"))
    x.polarity = scores.sentiment.polarity
    x.subjectivity = scores.sentiment.subjectivity
    return x


class RulesParser(object):
    """
    规则解析器
    """

    def __init__(self, rules: list, labels, field="text", use_model=False):
        """
        初始化解析器
        @parms rules: 规则，是一个字典
        """
        self.rules = rules                                             # 所有规则
        self.label2num = self.check_labels(labels)                     # key：标签，value：数字
        self.num2label = {v: k for k, v in self.label2num.items()}     # key：数字，value：标签
        self.field = field                                             # 作用字段
        self.applier = PandasLFApplier                                 # applier 默认为 PandasLFApplier，用于后面的标注函数
        self.cardinality = len(labels)                                 # 标签（类型）个数
        self.use_model = use_model                                     # 是否使用 LabelModel
        # 根据参数选择模型
        if self.use_model:
            self.label_model = LabelModel(cardinality=self.cardinality, verbose=True)
        else:
            self.label_model = MajorityLabelVoter(cardinality=self.cardinality, verbose=True)
        self.had_fit = False
    
    def check_labels(self, labels):
        """
        """
        if not labels:
            raise Exception("labels not exist.")
        if not isinstance(labels, list):
            raise Exception("labels type error, required list.")
        if len(labels) < 2:
            raise Exception("labels length can't lt 2.")
        return {k: i for i, k in enumerate(labels)}
    
    def generate_lfs(self):
        """
        生成 LabelFunction 列表
        """
        lsf = []
        for rule in self.rules:
            lsf.append(Rule2LabelFunction(copy.deepcopy(rule), self.label2num, self.field).to_function())
        return lsf
    
    def get_lfs_num(self, lfs):
        """
        按顺序返回规则编号
        """
        return [l.name.split("_")[-1] for l in lfs]
    
    def labeled_df(self, lfs, df, progress_bar=False, return_meta=False, return_hit=False):
        """
        使用 label function 标注数据
        """
        # 调用 labeled_df 方法时，将该参数置为 False
        self.had_fit = False
        # 标注
        applier = self.applier(lfs=lfs)
        labeled_df = applier.apply(df=df, progress_bar=progress_bar, return_meta=return_meta)

        if return_hit:
            nums = self.get_lfs_num(lfs)
            ldf = labeled_df[0] if return_meta else labeled_df
            hits = [[(self.num2label[l], nums[j]) for j, l in enumerate(ld) if l != -1] for ld in ldf]
        else:
            hits = []

        return labeled_df, hits
    
    def fit(self, ldf, Y_dev=None, n_epochs=500, log_freq=100, seed=123):
        """
        训练标签模型
        """
        # self.label_model.fit(L_train=ldf, Y_dev=Y_dev, n_epochs=n_epochs, log_freq=log_freq, seed=seed)
        self.label_model.fit(L_train=ldf, Y_dev=Y_dev, log_freq=log_freq, seed=seed)
        self.had_fit = True
    
    def predict(self, ldf, return_probs=False, flush=False):
        """
        预测
        """
        # 如果使用label model，调用 predict 之前，必须 fit
        if self.use_model:
            if not self.had_fit or flush:
                self.fit(ldf)
        pp = self.label_model.predict(L=ldf, return_probs=return_probs)
        if return_probs:
            pred, prob = pp
            pred = [self.num2label.get(ln, "") for ln in pred.tolist()]
            return pred, prob.tolist()
        else:
            pp = [self.num2label.get(ln, "") for ln in pp.tolist()]
            return pp
    
    def score(self, ldf, Y, tie_break_policy="random"):
        """
        模型得分
        """
        if not self.had_fit:
            raise Exception("the model not fit.")
        return self.label_model.score(L=ldf, Y=Y, tie_break_policy=tie_break_policy)
    
    def get_labeled_dataframe(self, X, y, L):
        """
        过滤没有被 label function 覆盖的数据
        """
        return filter_unlabeled_dataframe(X, y, L)
    
    def lf_summary(self, lt, lfs):
        """
        LF 统计分析
        """
        return LFAnalysis(L=lt, lfs=lfs).lf_summary()
