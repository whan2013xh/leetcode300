import grpc
import json
import time
import requests
# from tuya_ai_trace_requests import requests

from .protos import NLPBasicServerStub, Request, TokenRequest, CharNormRequest
from ..config import config
from ..logger import logger


class PreProcess(object):
	def __init__(self, ip_port):
		"""

		:param ip_port: ai-nlp-basic ip:port
		"""
		self.channel = grpc.insecure_channel(ip_port)
		self.stub = NLPBasicServerStub(self.channel)
	
	def segment(self, text, domain="common", norm=False, postag=False):
		"""
		切词
		"""
		request = TokenRequest(trace_id="", text=text, channel=domain, norm=norm, postag=postag)
		response = self.stub.tokenize(request)
		
		return list(response.tokens)
	
	def char_norm(self, text, lang="zh", filter_stop=False):
		"""
		大小写转换，全角转半角
		:param stub: grpc client
		:param text:
		:return:
		"""
		request = CharNormRequest(trace_id="", text=text, lang=lang, filter_stop=filter_stop)
		response = self.stub.char_norm(request)
		
		return response.result

	def close(self):
		self.channel.close()


class TextParse(object):
	"""
	"""
	_endpoint = config["text_parser_endpoint"]
	_token = config["text_parser_token"]
	_url = f"{ _endpoint }/ner"
	_headers = {
		"authorization": f"Bearer { _token }"
	}

	@classmethod
	def tokenize(cls, text, domain="169"):
		payload = {
			"text": text,
			"message_id": text,
			"backend": "chatbot",
			"service_id": f"chatbot_{ domain }",
			"extension": {}
		}
		start = time.time()
		response = requests.post(cls._url, json=payload, headers=cls._headers)
		logger.info(f"response: { round((time.time() - start) * 1000, 2) }ms")
		logger.info(response)
		logger.info(response.text)
		status_code = response.status_code
		if status_code != 200:
			return None, response.text

		result = response.text
		try:
			result = json.loads(result)
			success = result["success"]
			if not success:
				return None, f"parse text failure: text [{ text }]"

			return result["result"][0]["tokens"], None
		except Exception as e:
			return None, str(e)
