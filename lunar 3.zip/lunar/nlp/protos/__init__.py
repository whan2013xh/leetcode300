from .nlp_basic_pb2 import Request, TokenRequest, CharNormRequest
from .nlp_basic_pb2_grpc import NLPBasicServerStub