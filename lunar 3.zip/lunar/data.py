# -*- coding: utf-8 -*-
"""
    CreatedDate: 2020-11-06
    FileName   : data.py
    Author     : Mustom
    Descreption: 
"""
import re
from enum import Enum

import numpy as np

from lunar.mio import get_json_object
from lunar.nlp.autolabel.label_data import snorkel_predict_content, change_hit_label
from lunar.nlp.nlp_basic import segment_texts


class DataType(Enum):
    TEXT = "text"
    IMAGE = "image"
    VOICE = "voice"
    VIDEO = "video"
    QATOP10 = "qa-top10"


class PreLabelData(object):
    """
    预标注数据
    """

    def __init__(self, task_type, rules=None, labels=None, use_model=False, priority=None):
        self.task_type = task_type
        self.rules = rules
        self.labels = labels
        self.use_model = use_model
        self.priority = priority

    def get_image_data(self, task_data):
        """
        """
        path = task_data["path"]
        path = re.sub("\.[a-z]{2,4}$", f"_{str(self.task_type)}.json", path)
        try:
            obj = get_json_object(path)
            if isinstance(obj, list):
                return obj, None
            elif isinstance(obj, dict):
                return [obj], None
            else:
                return None, "预标注数据格式错误"
        except Exception as e:
            return None, repr(e)

    def get_text_datas(self, task_datas):
        """
        """
        if not self.rules:
            return None, "规则不存在"
        if self.rules.count() < 3:
            return None, "规则数量少于3"
        if not self.labels:
            return None, "标签不存在"
        rules = [x.to_dict() for x in self.rules]
        texts = [td["text"] for td in task_datas]
        preds, probs, hit_nums = snorkel_predict_content(rules, self.labels, texts, use_model=self.use_model)
        hit_nums_label = list([list(set([label[0] for label in hit])) for hit in hit_nums])
        labels = np.array(self.labels)
        result= []
        priority = self.priority
        sorted_hit_label = []
        if priority is not None:
            label, score, sorted_hits = change_hit_label(hit_nums, priority)

            for sorted_hit in sorted_hits:
                sorted_hit = list(sorted_hit.keys())
                sorted_label = sorted_hit + list(set(self.labels)-set(sorted_hit))
                sorted_hit_label.append(sorted_label)

        for i in range(len(preds)):
            sort_label = []
            hit_label = list(set(np.array(hit_nums[i])[:, 0].tolist())) if hit_nums[i] else []
            if not sorted_hit_label:
                hit_labels = []
                not_hit_labels = []
                for label in list(labels[np.argsort(probs[i])[::-1]]):
                    if label in hit_label:
                        hit_labels.append(label)
                    else:
                        not_hit_labels.append(label)
                sort_label = hit_labels+not_hit_labels

                # list(sorted_hits[i].keys())+list(set(list(labels[np.argsort(probs[i])[::-1]]))-set(list(sorted_hits[i].keys())))
            pre_result = {
                "label": hit_label,
                "score": score[i] if sorted_hit_label else max(probs[i]),
                "sorted_label": sorted_hit_label[i] if sorted_hit_label else sort_label,
                "hit_flag": len(hit_nums[i]) >= 1
            }
            result.append(pre_result)
        return result, None
        # return [[{"label": preds[i] if preds[i] in self.labels else None, "score": max(probs[i]), "sorted_label":list(labels[np.argsort(probs[i])[::-1]]), "hit_flag":len(hit_nums[i])>=1}] for i in range(len(preds))], None

    def get_text_data(self, task_data):
        """
        """
        if not self.rules:
            return None, "规则不存在"
        if self.rules.count() < 3:
            return None, "规则数量少于3"
        if not self.labels:
            return None, "标签不存在"
        rules = [x.to_file() for x in self.rules]
        text = task_data["text"]
        preds, probs, hit_nums = snorkel_predict_content(rules, self.labels, [text], use_model=self.use_model)
        labels = np.array(self.labels)
        result = []
        priority = self.priority
        sorted_hit_label = []
        if priority is not None or priority:
            label, score, sorted_hits = change_hit_label(hit_nums, priority)

            for sorted_hit in sorted_hits:
                sorted_hit_label = list(sorted_hit.keys())
                sorted_label = sorted_hit_label + list(set(self.labels) - set(sorted_hit_label))
                sorted_hit_label.append(sorted_label)

        for i in range(len(preds)):
            pre_result = {
                "label": list(set(np.array(hit_nums[i])[:, 0].tolist())) if hit_nums[i] else [],
                "score": score[i] if sorted_hit_label else max(probs[i]),
                "sorted_label": sorted_hit_label[i] if sorted_hit_label else list(labels[np.argsort(probs[i])[::-1]]),
                "hit_flag": len(hit_nums[i]) >= 1
            }
            result.append(pre_result)
        return result, None

    def get_data(self, data_type, task_data):
        if data_type == DataType.TEXT.value:
            return self.get_text_data(task_data)
        if data_type == DataType.IMAGE.value:
            return self.get_image_data(task_data)
        return None, "暂不支持的数据类型"


def get_pre_label_data(task, task_datas, use_pre_label=True, use_model=False):
    """
    获取预标注数据
    """
    # 如果不使用预标注数据，直接返回空字符串
    if not use_pre_label:
        return [[] for _ in task_datas], None

    task_type = task.task_type.name
    task_data_type = task.data_set.data_set_type.name


    if task_data_type == DataType.IMAGE.value:
        pd = PreLabelData(task_type)
        res = []
        for data in task_datas:
            data, err = pd.get_image_data(data)
            res.append(data if err is None else [])
        return res, None
    if task_data_type == DataType.TEXT.value:
        rules = task.get_rules()
        # labels = task.get_rules()
        # 获取标签
        labels = task.get_labels()
        priority = task.get_priority()
        # priority = None
        if not labels:
            return {"msg": "task labels not exist"}, 200
        if not isinstance(labels, list):
            return {"msg": "task labels format error"}, 200
        # label_list = [label for label in labels]
        pd = PreLabelData(task_type, rules=rules, labels=labels, use_model=use_model, priority=priority)
        data, err = pd.get_text_datas(task_datas)
        return data if err is None else [[] for _ in task_datas], None

    return None, "暂不支持的数据类型"


def segement(task_datas, domain, data_type, task_type):
    """
    分词
    """
    # 如果数据类型不为文本，则不需要分词
    if data_type != "text":
        return task_datas
    if task_type not in ["reapu", "text_sequence"]:
        return task_datas

    texts = [data["text"] for data in task_datas]
    seg_texts = segment_texts(texts, domain=domain)

    return [{"text": " ".join(ele)} for ele in seg_texts]
