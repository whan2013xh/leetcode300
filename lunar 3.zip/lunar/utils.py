import math
import re
import os
import json
import uuid
import numpy as np

from sanic import response
from collections import defaultdict
import pandas as pd
from functools import wraps
import sanic
from io import BytesIO
import time
from datetime import datetime
from dateutil.relativedelta import relativedelta

from lunar.db import es_hosts, es_index_prefix, es_type
from lunar.esrecorder import ESRecorder
from lunar.mio import OssFile
from lunar.fileio import TmpFile
from lunar.logger import logger


def connect_db(db):
    if db.is_closed():
        db.connect()


def close_db(db):
    if not db.is_closed():
        db.close()


def handle_exception(request, e):
    message = repr(e)

    return response.json({"msg": message, "success": False})


def response_normalize(f):
    """
    对API接口返回标准化
    """

    @wraps(f)
    async def decorated_function(request, *args, **kwargs):
        data, code = await f(request, *args, **kwargs)
        # if code < 300:
        if len(data) == 1 and "msg" in data:
            data["success"] = False

        else:
            data["success"] = True
        return data, code

    return decorated_function


def sanic_excel_file_read(excel_file: sanic.request.File):
    body_bytes = excel_file.body
    buffer = BytesIO(body_bytes)
    df = pd.read_excel(buffer)
    return df


def is_validated_dates(begin_date: str, end_date: str, input_format: str):
    """
    检查开始和结束日期的有效性
    """
    try:
        begin_date = time.strptime(begin_date, input_format)
        end_date = time.strptime(end_date, input_format)
        if begin_date > end_date:
            return False
        return True
    except:
        return False


def normalized_es_data(es_data):
    """
    标准化从es中获取的数据
    """
    data, not_messages = [], []
    if not es_data:
        return data, not_messages

    # 处理通过search方式获取的 es 数据
    hits = es_data["hits"]["hits"]
    if not hits:
        return data, not_messages
    es_data = hits

    for q in es_data:
        source = q["_source"]
        message_str = source["message"]
        message = parse_message(message_str)
        if not message or message.get("success", False):
            not_messages.append(message_str)
            continue

        question = message["query"]
        answer_list = message.get("answerList", [])
        similars = message.get("similars", [])

        before_top = [a["question"] for a in answer_list]
        behind_top = [s["question"] for s in similars]

        data.append({"data": {"question": question, "top-10": before_top + behind_top}})

    return data, not_messages


parse_message_pattern = re.compile("result:(?P<message>{.+})cost_time")


def parse_message(message):
    """
    解析 message 字符串，将需要的内容转换成字典
    """
    res = {}

    message = re.sub("\s", "", message)
    match = parse_message_pattern.search(message)
    if not match:
        return res
    message = match.group("message")
    try:
        res = json.loads(message, encoding="utf-8")
    except:
        pass
    return res


def generate_dates(begin_date_str, end_date_str, input_format="%Y-%m-%d", output_format="%Y-%m-%d"):
    """
    根据开始和结束日期字符串，生成对应格式的日期列表
    """
    begin_date = datetime.strptime(begin_date_str, input_format)
    end_date = datetime.strptime(end_date_str, input_format)

    res_dates = []
    while begin_date <= end_date:
        res_dates.append(datetime.strftime(begin_date, output_format))
        begin_date += relativedelta(days=1)

    return res_dates


def find_log_data_by_date(date_str):
    """
    根据日期查询 qa 日志数据
    """
    data, not_messages = [], []

    es_index = es_index_prefix + "-" + date_str
    # 创建 ESRecorder 对象
    esr = ESRecorder(es_hosts, es_index, es_type)
    # 每次返回条目的大小
    size = 10000
    # 查询语句
    body = {
        "from": 0,
        "size": size,
        # "_source": ["query", "answerList", "similars"],
        "_source": ["message"],
        "query": {"match_all": {}}
    }
    # 第一次查询
    es_data = esr.search(body=body)
    # 将第一次查询的结果标准化后存储起来
    op_normal_data, op_not_messages = normalized_es_data(es_data)
    data.extend(op_normal_data)
    not_messages.extend(op_not_messages)
    # 获取满足条件的总 doc 数据
    total = es_data['hits']['total']
    # 如果总条数大于当前返回条目数，则循环将所有数据取出并存储
    if total > size:
        pages = math.ceil(total / size)
        for i in range(1, pages):
            body['from'] = i
            page_data = esr.search(body=body)
            page_normal_data, page_not_messages = normalized_es_data(page_data)
            data.extend(page_normal_data)
            not_messages.extend(page_not_messages)
    # 返回 存储对象
    return data, not_messages


def get_labeled_data_from_node(label_node, export_fields, export_instance_fields):
    """
    获取已标注的数据
    """
    if not label_node or not label_node.is_labeled or label_node.data_disqualified:
        return {}
    instance = {f: getattr(label_node, f) for f in export_fields}
    # 添加 label_node_id
    instance["label_node_id"] = instance["id"]
    # 将原来的 LabelNode id 变为 DataInstance id
    instance["id"] = instance["data_id"]
    del instance["data_id"]

    # 获取 DataInstance 数据信息
    res = {f: getattr(instance["data"], f) for f in export_instance_fields}

    # # 将 DataSet id 字段名从 "data_set_id" 变为 "id"
    # res["id"] = res["data_set_id"]
    # del res["data_set_id"]

    # 添加数据类型
    instance["data_set_type"] = res["data_set"].data_set_type.name
    del res["data_set"]

    # 将 res 中的 data 数据放入 instance，该 data 是一个 DataInstance 包含的数据
    instance["data"] = res["data"]
    del res["data"]

    # 添加当前 LabelNode
    res["instances"] = [instance]

    return res


def rebuild_image_result(tmp_res, task_type):
    """
    重构 结果
    """
    instances = tmp_res.get("instances")
    if not instances:
        return tmp_res

    instance = instances[0]

    # 2D_rect（矩形框）、key_point（关键点）、image_attr（属性）、semantic_seg（多边形）
    # 新的结构
    if instance["data_set_type"] == "image":
        source_data = instance["data"]
        label_data = instance["label_data"]
        field_data = label_data["data"]
        label_node_id = instance["label_node_id"]

        base = {
            "filename": os.path.basename(source_data["path"]),
            "label_node_id": label_node_id
        }

        tmp = []
        if task_type == "2D_rect":
            for item in field_data:
                data = {}
                data.update(base)
                bbox = item.pop("bbox")
                data["bbox"] = {"left": bbox[0][0], "top": bbox[0][1],
                                "right": bbox[1][0], "bottom": bbox[1][1]}
                data["segmentation"] = item.pop("segmentation", []) \
                    if item.pop("segmentation", []) else []
                data["point"] = item.pop("point", []) if item.pop("point", []) else []
                item.pop("raw", [])
                data.update(item)

                tmp.append(data)
        elif task_type == "semantic_seg":
            for item in field_data:
                data = {}
                data.update(base)
                data["segmentation"] = sum(item.pop("segmentation"), [])
                data["point"] = item.pop("point", []) if item.pop("point", []) else []
                data["bbox"] = item.pop("bbox", {}) if item.pop("bbox", {}) else {}
                data.update(item)

                tmp.append(data)
        elif task_type == "key_point":
            data = {}
            data.update(base)
            data["point"] = field_data
            data["segmentation"] = label_data.pop("segmentation", []) \
                if label_data.pop("segmentation", []) else []
            data["bbox"] = label_data.pop("bbox", {}) \
                if label_data.pop("bbox", {}) else {}
            label_data.pop("data", [])
            data.update(label_data)

            tmp.append(data)
        elif task_type == "image_attr":
            for item in field_data:
                item.update(base)
                tmp.append(item)
            # [item.update(base) for item in field_data]
            # tmp = field_data
        else:
            tmp = [instance]

        tmp_res["instances"] = tmp


def format_mill_timestamp(mill_timestamp, format_str):
    """
    格式化毫秒级时间戳
    """
    lt = time.localtime(mill_timestamp / 1000)
    return time.strftime(format_str, lt)


def cal_begin_and_end_timestamp(date_str):
    """
    计算一个日期字符串的开始和结束的秒级时间戳
    日期字符串格式：yyyy-mm-dd
    """
    # 检查格式是否正确
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
    except:
        return -1, -1
    # 计算开始时间戳
    begin_timestamp = int(time.mktime(time.strptime(date_str, '%Y-%m-%d')))
    # 计算结束时间戳
    end_timestamp = begin_timestamp + 86400

    return begin_timestamp, end_timestamp


def cal_begin_and_end_mill_timestamp(date_str):
    """
    计算一个日期字符串的开始和结束的毫秒级时间戳
    """
    bts, ets = cal_begin_and_end_timestamp(date_str)
    if bts < 0 or ets < 0:
        return bts, ets

    return bts * 1000, ets * 1000


def get_current_begin_mill_timestamp():
    """
    获取当前时间戳(毫秒级)
    """
    date_str = datetime.strftime(datetime.today(), "%Y-%m-%d")
    return int(time.mktime(time.strptime(date_str, '%Y-%m-%d'))) * 1000


def get_period_mill_timestamp(date_str, scale):
    """
    通过 timestamp 和 scale 计算开始和结束的时间戳
    """
    try:
        end_date = datetime.strptime(date_str, "%Y-%m-%d")
    except:
        return -1, -1
    if scale == "day":
        begin_date = end_date - relativedelta(days=1) + relativedelta(days=1)
    elif scale == "week":
        begin_date = end_date - relativedelta(weeks=1) + relativedelta(days=1)
    elif scale == "month":
        begin_date = end_date - relativedelta(months=1) + relativedelta(days=1)
    elif scale == "year":
        begin_date = end_date - relativedelta(years=1) + relativedelta(days=1)
    else:
        # 错误的时间 scale
        return -1, -1

    # 计算 begin_date 的开始时间戳
    begin_date_str = datetime.strftime(begin_date, "%Y-%m-%d")  # 转化为字符串
    bdst, _ = cal_begin_and_end_timestamp(begin_date_str)
    # 计算 end_date 的结束时间戳
    _, edet = cal_begin_and_end_timestamp(date_str)

    return bdst * 1000, edet * 1000


def build_dict_default_name(data):
    limit = str(data.get("limit", 10)).strip()
    offset = str(data.get("offset", 0)).strip()
    begin_date = str(data.get("begin_date", datetime.now().strftime("%Y-%m-%d"))).strip()
    end_date = str(data.get("end_date", datetime.now().strftime("%Y-%m-%d"))).strip()
    name = str(data.get("name", "")).strip()
    return "".join(sorted([limit, offset, begin_date, end_date, name]))


def build_file_name_from_request(request, attr, ext=""):
    data = getattr(request, attr)
    if isinstance(data, dict):
        sorted_values = sorted([str(v).strip() for v in list(data.values())])
        prefix = "".join(sorted_values)
        if not prefix:
            prefix = build_dict_default_name(data)
    elif isinstance(data, list):
        sorted_values = sorted([str(v).strip() for v in data])
        prefix = "".join(sorted_values)
    else:
        prefix = str(data)
    if prefix:
        return prefix + ext
    return prefix


def format_request_labeled_data(data: list):
    if not data:
        return {}
    res = defaultdict(list)
    keys = sorted(list(data[0].keys()))
    for row in data:
        for key in keys:
            res[key].append(row[key])
    return res


def format_request_data_set(data: list):
    if not data:
        return {}
    res = defaultdict(list)
    keys = sorted(list(data[0]["data"].keys()))
    for row in data:
        for key in keys:
            res[key].append(row["data"][key])
    return res


def format_request_data(data: list):
    if not data:
        return {}
    res = defaultdict(list)
    keys = sorted(list(data[0].keys()))
    for row in data:
        for key in keys:
            res[key].append(row[key])
    return res


def remove_file(file_path):
    if os.path.exists(file_path):
        os.remove(file_path)


def push_instances2minIO(data, flag_name):
    """
    """
    instances = data["instances"]
    task_type = data["task_type"]
    for instance in instances:
        # 存储桶
        file_path = instance["data"].get("path")
        if not file_path:
            continue
        file_path = file_path if file_path.startswith("/") else "/" + file_path
        spills = file_path.split("/")
        bucket = spills[1]
        path_dir = "/".join(spills[2:-1])
        name, ext = os.path.splitext(spills[-1])
        object_name = os.path.join(path_dir, name + "_" + task_type + ".json")
        # 写入临时文件
        tmp_name = name + "_" + flag_name + "_" + str(int(time.time() * 1000)) + ".json"
        tmp_file = TmpFile(tmp_name)
        tmp_file.write_json(instance)
        tmp_file_path = tmp_file.file_path

        err = OssFile().fput_object(
            bucket, object_name, tmp_file_path,
            content_type="text/json"
        )

        remove_file(tmp_file_path)


_BOOL_ = {"False": False, "false": False, "True": True, "true": True}


def to_bool(data, strict=False):
    """
    """
    if strict:
        return _BOOL_.get(str(data), False)
    return bool(data)


def pop_match_label(rule, default=None):
    match_label = rule.get("matchLabel", default)
    if match_label is not None:
        return match_label
    return rule.pop("match_label", default)


def pop_not_match_label(rule, default=None):
    match_label = rule.pop("notMatchLabel", default)
    if match_label is not None:
        return match_label
    return rule.pop("not_match_label", default)


def build_rules(task, data, labels, types, max_num=0):
    """
    构建规则
    """
    rules = []
    if not data:
        return None, "rule data not exist"
    for orule in data:
        if not orule:
            continue
        # 判断 type
        type = orule.pop("type", "")
        if type not in types:
            return None, f"rule type error: {type}"
        # 判断 match_label
        match_label = pop_match_label(orule, default=None)
        if match_label and match_label not in labels:
            return None, f"match label not exist in task: {match_label}"
        # 判断 not_match_label
        not_match_label = pop_not_match_label(orule, default=None)
        if not_match_label and not_match_label not in labels:
            return None, f"not match label not exist in task: {not_match_label}"
        # 判断是否存在 num
        num = orule.pop("num", -1)
        if not isinstance(num, int):
            return None, f"rule num must be digit: {num}"
        # 如果 num 大于 max_num，max_num 重新赋值为 num，反之 max_num 加 1
        max_num = num if num > max_num else max_num + 1

        # 保存
        rules.append({
            "task": task,
            "type": type,
            "match_label": match_label,
            "not_match_label": not_match_label,
            "params": orule,
            "num": num,
            "contain": orule.get("contain")
        })

    return rules, ""


def build_temp_rule(rule_data, labels, rule_types, edit=False):
    """
    构建 临时 规则（一个）
    """
    temp_rule = {}
    # 获取 规则类型
    rule_type = rule_data.pop("type", None)
    if rule_type not in rule_types:
        return None, f"type 不存在或不支持：type={rule_type}"
    temp_rule["type"] = rule_type
    # 获取 匹配到规则后的标签
    match_label = rule_data.pop("matchLabel", "")
    if match_label != "" and match_label not in labels:
        return None, f"matchLabel 不存在或不支持：matchLabel={match_label}"
    temp_rule["match_label"] = match_label
    # 获取 没有匹配到规则后的标签
    not_match_label = rule_data.pop("notMatchLabel", "")
    if not_match_label != "" and not_match_label not in labels:
        return None, f"notMatchLabel 不存在或不支持：notMatchLabel={not_match_label}"
    temp_rule["not_match_label"] = not_match_label
    temp_rule["contain"] = rule_data.get("contain")
    # 获取编号
    if not edit:
        temp_rule["num"] = 0
    # 剩下的都是参数
    temp_rule["params"] = rule_data

    return temp_rule, None


def build_temp_rules(rule_data, labels, rule_types):
    """
    构建 临时 规则（一个）
    """
    max_num = 0
    rules = []
    for orule in rule_data:
        temp_rule = {}
        # 获取 规则类型
        rule_type = orule.pop("type", None)
        if rule_type not in rule_types:
            return None, f"type 不存在或不支持：type={rule_type}"
        temp_rule["type"] = rule_type
        # 获取 匹配到规则后的标签
        match_label = orule.pop("matchLabel", "")
        if match_label != "" and match_label not in labels:
            return None, f"matchLabel 不存在或不支持：matchLabel={match_label}"
        temp_rule["match_label"] = match_label
        # 获取 没有匹配到规则后的标签
        not_match_label = orule.pop("notMatchLabel", "")
        if not_match_label != "" and not_match_label not in labels:
            return None, f"notMatchLabel 不存在或不支持：notMatchLabel={not_match_label}"
        temp_rule["not_match_label"] = not_match_label
        # 获取编号
        temp_rule["num"] = max_num
        temp_rule["contain"] = rule_data.get("contain")
        max_num += 1
        # 剩下的都是参数
        temp_rule["params"] = orule

        rules.append(temp_rule)

    return rules, None


def uuid5_hash(text: str, namespace=uuid.NAMESPACE_DNS):
    """
    使用 uuid5 生成 NAMESPACE_DNS 命名空间的唯一值
    """
    uid = uuid.uuid5(namespace, text)
    return str(uid).replace("-", "")


def execute_time(func):
    # 定义嵌套函数，用来打印出装饰的函数的执行时间
    def wrapper(*args, **kwargs):
        # 定义开始时间和结束时间，将func夹在中间执行，取得其返回值
        start = time.time()
        func_return = func(*args, **kwargs)
        end = time.time()
        # 打印方法名称和其执行时间
        logger.info(f'{func.__name__}() execute time: {end - start}s')
        # 返回func的返回值
        return func_return

    # 返回嵌套的函数
    return wrapper


def change_excel_data(source_data):
    query = source_data[source_data.columns[6]]
    sim_query = source_data[source_data.columns[10]]
    for i in range(len(query)):
        sim_data = "无答案" if sim_query[i] is np.nan else sim_query[i]
        query[i] = query[i] + "|" + sim_data
        # query[i] = str(time.time()) + "_" + query[i] + "|" + sim_data
    query.name = "text"
    return query.to_frame()
